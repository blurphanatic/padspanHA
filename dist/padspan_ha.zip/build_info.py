# PadSpan HA — BLE Room-Presence Tracking for Home Assistant
# Copyright (C) 2026 Garry Broeckling
# Licensed under the GNU General Public License v3.0
# See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
"""Generated at build time. Used to prove what version is actually installed."""

BUILD_VERSION = "0.6.48"
BUILD_ID = "20260304T181119Z"

# Backwards/for convenience
VERSION = BUILD_VERSION
