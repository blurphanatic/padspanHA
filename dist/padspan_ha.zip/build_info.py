# PadSpan HA — BLE Room-Presence Tracking for Home Assistant
# Copyright (C) 2026 Garry Broeckling
# Licensed under the GNU General Public License v3.0
# See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
"""Generated at build time. Used to prove what version is actually installed."""

BUILD_VERSION = "0.14.14"
BUILD_ID = "20260316T194708Z"
CHANNEL = "beta"

# Backwards/for convenience
VERSION = BUILD_VERSION
