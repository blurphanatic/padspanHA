"""Generated at build time. Used to prove what version is actually installed."""

BUILD_VERSION = "0.5.12"
BUILD_ID = "20260225T200235Z"

# Backwards/for convenience
VERSION = BUILD_VERSION
