"""Generated at build time. Used to prove what version is actually installed."""

BUILD_VERSION = "0.4.58"
BUILD_ID = "20260224T163745Z"

# Backwards/for convenience
VERSION = BUILD_VERSION
