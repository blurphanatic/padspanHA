"""
PadSpan HA — Area Sensors
===========================
Creates sensor.{label}_area entities for every BLE device the user has labelled
(i.e. given a user_label via the Objects tab).  State = current room name, or
"unknown" when the device is detected but not yet assigned to a room, or
"unavailable" when the device hasn't been seen for 5 minutes.

Entity ID example:  sensor.padspan_car_keys_area
Automation example: trigger when sensor.padspan_wallet_area changes to "Kitchen"
"""
from __future__ import annotations

import logging
from typing import Any

from homeassistant.components.sensor import SensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .presence_coordinator import PresenceCoordinator

_LOGGER = logging.getLogger(__name__)

# Devices not seen for longer than this (seconds) become unavailable
_AWAY_TIMEOUT_S = 300


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    coordinator: PresenceCoordinator | None = hass.data.get(DOMAIN, {}).get("presence_coordinator")
    if not coordinator:
        return

    created: set[str] = set()

    @callback
    def _check_new() -> None:
        if not coordinator.data:
            return
        new: list[PadSpanAreaSensor] = []
        for key, obj in coordinator.data.items():
            if key in created or not _should_track(obj):
                continue
            new.append(PadSpanAreaSensor(coordinator, key))
            created.add(key)
        if new:
            _LOGGER.debug("Adding %d new PadSpan area sensor(s)", len(new))
            async_add_entities(new)

    _check_new()
    entry.async_on_unload(coordinator.async_add_listener(_check_new))


def _should_track(obj: dict[str, Any]) -> bool:
    """Only create entities for BLE objects the user has explicitly labelled."""
    return obj.get("kind") == "ble" and bool(obj.get("user_label"))


def _device_uid(obj: dict[str, Any]) -> str:
    return obj.get("address") or obj.get("entity_id") or obj.get("key", "")


class PadSpanAreaSensor(CoordinatorEntity[PresenceCoordinator], SensorEntity):
    """Reports the current room for a labelled BLE device."""

    _attr_icon = "mdi:map-marker"
    _attr_has_entity_name = True

    def __init__(self, coordinator: PresenceCoordinator, key: str) -> None:
        super().__init__(coordinator)
        self._key = key

    # ── internal helpers ─────────────────────────────────────────────────────

    @property
    def _obj(self) -> dict[str, Any]:
        return (self.coordinator.data or {}).get(self._key, {})

    def _label(self) -> str:
        obj = self._obj
        return str(obj.get("user_label") or obj.get("name") or self._key)

    # ── HA entity identity ────────────────────────────────────────────────────

    @property
    def unique_id(self) -> str:
        safe = self._key.replace(":", "_").replace(" ", "_").replace("/", "_")
        return f"padspan_ha__{safe}__area"

    @property
    def name(self) -> str:
        # With has_entity_name=True this renders as "{device name} Area"
        return "Area"

    @property
    def device_info(self) -> dict[str, Any]:
        return {
            "identifiers": {(DOMAIN, _device_uid(self._obj))},
            "name": self._label(),
            "manufacturer": "PadSpan HA",
            "model": "BLE Presence Tracker",
        }

    # ── state ─────────────────────────────────────────────────────────────────

    @property
    def native_value(self) -> str:
        return self._obj.get("room") or "unknown"

    @property
    def available(self) -> bool:
        if not self.coordinator.last_update_success or not self.coordinator.data:
            return False
        obj = self._obj
        if not obj:
            return False
        age = obj.get("age_s")
        return not (isinstance(age, (int, float)) and age > _AWAY_TIMEOUT_S)

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        obj = self._obj
        return {
            "address": obj.get("address"),
            "rssi": obj.get("rssi"),
            "age_s": obj.get("age_s"),
            "sources": obj.get("sources"),
        }
