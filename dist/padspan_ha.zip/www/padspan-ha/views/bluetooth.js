// PadSpan HA — BLE Room-Presence Tracking for Home Assistant
// Copyright (C) 2026 Garry Broeckling
// Licensed under the GNU General Public License v3.0
// See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
// PadSpan HA – Bluetooth view
// A pragmatic clone of HA's Bluetooth page: scanners/adapters + advertisement monitor + simple visualization.

export function render(ctx) {
  const { el, esc } = ctx.helpers;

  const snap = (ctx.state.live && ctx.state.live.snapshot) || null;
  const isLive = ctx.state.dataMode === "live";
  const ble = snap && snap.ble ? snap.ble : { radios: [], advertisements: [], diag: { ok: true, errors: [] } };

  // Build an address→object index from the same objects model used by the Objects view,
  // so identified/unidentified status is consistent across both views.
  const objModel = snap && snap.objects ? snap.objects : null;
  const objIndex = new Map();
  if (objModel && Array.isArray(objModel.list)) {
    for (const o of objModel.list) {
      if (o && o.address) objIndex.set(String(o.address).toUpperCase(), o);
    }
  }

  // View state (stored on ctx.state so it survives re-renders)
  if (!ctx.state.btTab) ctx.state.btTab = "visualization"; // visualization | monitor | scanners
  if (ctx.state.btFilter == null) ctx.state.btFilter = "";
  if (!ctx.state.btSource) ctx.state.btSource = "all"; // all | <scanner source>
  if (!ctx.state.btMax) ctx.state.btMax = 60;

  const radios = Array.isArray(ble.radios) ? ble.radios : [];
  const adsAll = Array.isArray(ble.advertisements) ? ble.advertisements : [];
  const diag = ble.diag || { ok: true, errors: [] };

  // Derived
  const filter = String(ctx.state.btFilter || "").trim().toLowerCase();
  const sourceSel = ctx.state.btSource || "all";
  const maxItems = Math.max(10, Math.min(400, Number(ctx.state.btMax || 60)));

  const ads = adsAll
    .filter(a => {
      if (!a) return false;
      if (sourceSel !== "all" && String(a.source || "") !== sourceSel) return false;
      if (!filter) return true;
      const hay = `${a.name || ""} ${a.address || ""} ${(a.source || "")}`.toLowerCase();
      return hay.includes(filter);
    })
    .slice(0, maxItems);

  const sources = ["all", ...Array.from(new Set(radios.map(r => String(r.source || "")).filter(Boolean))).sort()];

  const tabButton = (id, label) =>
    el(
      "button",
      {
        class: "tab" + (ctx.state.btTab === id ? " active" : ""),
        onclick: () => {
          ctx.state.btTab = id;
          ctx.actions.renderRooms();
        },
      },
      label
    );

  const header = el("div", { class: "row" }, [
    el("div", { class: "grow" }, [
      el("div", { class: "h1" }, "Bluetooth"),
      el(
        "div",
        { class: "muted" },
        "Scanners/adapters and recently seen advertisements (modeled after Home Assistant Settings → Bluetooth)."
      ),
    ]),
    el("div", { class: "bt-kpis" }, [
      el("div", { class: "kpi" }, [el("div", { class: "kpi-num" }, String(radios.length)), el("div", { class: "kpi-lbl" }, "Scanners")]),
      el("div", { class: "kpi" }, [el("div", { class: "kpi-num" }, String(adsAll.length)), el("div", { class: "kpi-lbl" }, "Recent ads")]),
    ]),
  ]);

  const diagCard =
    diag && (diag.ok === false || (diag.errors && diag.errors.length))
      ? el("div", { class: "card warn" }, [
          el("div", { style: "font-weight:700;margin-bottom:6px" }, "Bluetooth feed looks unhealthy"),
          el(
            "div",
            { class: "muted", style: "margin-bottom:8px" },
            "This usually means the HA Bluetooth integration isn't enabled, or the scanner API callback failed. The page will still render, but data may be empty."
          ),
          el("pre", { class: "pre" }, esc(JSON.stringify(diag, null, 2))),
        ])
      : null;

  const tabs = el("div", { class: "tabs" }, [tabButton("visualization", "Visualization"), tabButton("monitor", "Advertisement monitor"), tabButton("scanners", "Scanners")]);

  const controls = el("div", { class: "bt-controls", style: "display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;margin-bottom:12px" }, [
    el("div", { class: "field", style: "flex:2;min-width:160px" }, [
      el("div", { class: "label" }, "Search"),
      el("input", {
        class: "input",
        placeholder: "Name, address, or source…",
        value: ctx.state.btFilter,
        oninput: e => {
          ctx.state.btFilter = e.target.value;
          ctx.actions.renderRooms();
        },
      }),
    ]),
    el("div", { class: "field", style: "flex:1;min-width:140px" }, [
      el("div", { class: "label" }, "Source"),
      el(
        "select",
        {
          class: "select",
          onchange: e => {
            ctx.state.btSource = e.target.value;
            ctx.actions.renderRooms();
          },
        },
        sources.map(s => el("option", { value: s, ...(s === sourceSel ? { selected: "selected" } : {}) }, s === "all" ? "All scanners" : s))
      ),
    ]),
    el("div", { class: "field", style: "flex:0 0 90px" }, [
      el("div", { class: "label" }, "Max rows"),
      el("input", {
        class: "input",
        type: "number",
        min: 10,
        max: 400,
        value: String(ctx.state.btMax),
        oninput: e => {
          ctx.state.btMax = e.target.value;
          ctx.actions.renderRooms();
        },
      }),
    ]),
  ]);

  let body = null;
  if (ctx.state.btTab === "scanners") {
    body = renderScanners(ctx, radios, sources);
  } else if (ctx.state.btTab === "monitor") {
    body = renderMonitor(ctx, ads, radios, objIndex);
  } else {
    body = renderVisualization(ctx, radios, ads, objIndex);
  }

  const out = el("div", { id: "bluetooth" }, [header, diagCard, tabs, controls, body]);
  return out;
}

function renderScanners(ctx, radios, sources) {
  const { el, radioShortId } = ctx.helpers;
  const snap = (ctx.state.live && ctx.state.live.snapshot) || null;
  const scannerOffsets = (snap && snap.scanner_offsets) || (ctx.state.settings && ctx.state.settings.scanner_offsets) || {};

  if (!radios.length) {
    return el("div", { class: "card" }, [
      el("div", { style: "font-weight:700" }, "No scanners reported"),
      el("div", { class: "muted" }, "If you expect scanners here, verify Settings → Devices & services → Bluetooth is enabled in Home Assistant."),
    ]);
  }

  const row = r => {
    const src  = String(r.source || "");
    const name = String(r.name || "");
    const sid  = radioShortId ? radioShortId(src) : "";
    const meta = [];
    if (r.adapter) meta.push(`adapter: ${r.adapter}`);
    if (r.scanning != null) meta.push(`scanning: ${r.scanning ? "yes" : "no"}`);
    if (r.connectable != null) meta.push(`connectable: ${r.connectable ? "yes" : "no"}`);

    const nameRow = el("div", { style: "display:flex;align-items:center;gap:6px;flex-wrap:wrap" }, [
      sid ? el("span", { class: "pill", style: "font-family:monospace;font-weight:700;font-size:11px;padding:1px 6px" }, sid) : null,
      el("div", { class: "bt-scanner-name" }, name || src || "Scanner"),
      r.lost     ? el("span", { class: "badge warn", style: "font-size:10px;background:rgba(245,158,11,.18);color:#f59e0b" }, "⚠ Lost") : null,
      r.disabled ? el("span", { class: "badge warn", style: "font-size:10px;background:rgba(148,100,220,.18);color:#c084fc" }, "⊘ Disabled") : null,
    ].filter(Boolean));

    // Per-scanner RSSI offset control
    const currentOffset = Number(scannerOffsets[src] || 0);
    const offsetInput = el("input", {
      type: "number", min: "-30", max: "30", step: "1",
      value: String(currentOffset),
      title: "RSSI offset in dBm — positive = scanner reads weaker than reality; negative = reads stronger",
      style: "width:48px;text-align:center;background:#0a150e;border:1px solid #2d5a3d;border-radius:4px;color:#e2e8f0;padding:2px 4px;font-size:11px",
    });
    const offsetSaveBtn = el("button", { class: "btn tiny" }, "Set");
    offsetSaveBtn.addEventListener("click", async (ev) => {
      ev.stopPropagation();
      const v = Math.max(-30, Math.min(30, parseFloat(offsetInput.value) || 0));
      try {
        await ctx.actions.scannerOffsetSet(src, v);
        ctx.toast(`Offset for ${name || src}: ${v > 0 ? "+" : ""}${v} dBm`);
      } catch(e) { ctx.toast("Failed to save offset", true); }
    });
    const offsetRow = el("div", { style: "display:flex;align-items:center;gap:4px;margin-top:3px" }, [
      el("span", { class: "muted", style: "font-size:10px" }, "RSSI offset:"),
      offsetInput,
      el("span", { class: "muted", style: "font-size:10px" }, "dBm"),
      offsetSaveBtn,
      currentOffset !== 0 ? el("span", { class: "badge", style: "font-size:10px;background:#1a3a2a;color:#52b788" }, `${currentOffset > 0 ? "+" : ""}${currentOffset} dBm active`) : null,
    ].filter(Boolean));

    // Reset radio button — two-step confirmation
    const resetWrap = document.createElement("div");
    resetWrap.style.cssText = "display:flex;align-items:center;gap:4px;margin-top:3px";
    const makeResetBtn = () => {
      resetWrap.innerHTML = "";
      const rb = document.createElement("button");
      rb.className = "btn tiny";
      rb.style.cssText = "font-size:10px;padding:1px 8px;color:#f87171;border-color:#f8717140";
      rb.textContent = "Reset radio";
      rb.title = "Clear all stored data for this radio (calibration, placement, offsets, fingerprints)";
      rb.addEventListener("click", (ev) => {
        ev.stopPropagation();
        resetWrap.innerHTML = "";
        const lbl2 = document.createElement("span");
        lbl2.style.cssText = "font-size:10px;color:#f87171";
        lbl2.textContent = "Erase all data?";
        const yesBtn = document.createElement("button");
        yesBtn.className = "btn tiny";
        yesBtn.style.cssText = "font-size:10px;padding:1px 8px;background:#7f1d1d;border-color:#dc2626;color:#fca5a5";
        yesBtn.textContent = "Yes, reset";
        const noBtn = document.createElement("button");
        noBtn.className = "btn tiny";
        noBtn.style.cssText = "font-size:10px;padding:1px 8px;color:#94a3b8;border-color:#94a3b840";
        noBtn.textContent = "No";
        yesBtn.addEventListener("click", async (ev2) => {
          ev2.stopPropagation();
          resetWrap.innerHTML = "";
          const spin = document.createElement("span");
          spin.style.cssText = "font-size:10px;color:#94a3b8";
          spin.textContent = "Resetting…";
          resetWrap.appendChild(spin);
          try {
            const res = await ctx.actions.radioReset(src);
            const sm = res?.summary || {};
            const parts = [];
            if (sm.maps?.receivers_removed) parts.push(`${sm.maps.receivers_removed} placement(s)`);
            if (sm.calibration?.readings_removed) parts.push(`${sm.calibration.readings_removed} cal reading(s)`);
            if (sm.adaptive?.room_pairs_removed) parts.push(`${sm.adaptive.room_pairs_removed} fingerprint(s)`);
            if (sm.settings?.offset_cleared) parts.push("offset cleared");
            const detail = parts.length ? ": " + parts.join(", ") : "";
            ctx.toast(`Radio reset${detail}`);
            ctx.actions.renderRooms();
          } catch (e) {
            ctx.toast("Reset failed: " + String(e), true);
            makeResetBtn();
          }
        });
        noBtn.addEventListener("click", (ev2) => {
          ev2.stopPropagation();
          makeResetBtn();
        });
        resetWrap.appendChild(lbl2);
        resetWrap.appendChild(yesBtn);
        resetWrap.appendChild(noBtn);
      });
      resetWrap.appendChild(rb);
    };
    makeResetBtn();

    const subParts = [
      r.area_name ? el("span", { class: "pill", style: "font-size:10px" }, r.area_name) : el("span", { class: "muted", style: "font-size:10px" }, "no room"),
      el("div", { class: "bt-scanner-src", style: "font-size:10px" }, src || "—"),
      r.ip ? el("span", { class: "muted", style: "font-family:monospace;font-size:10px" }, r.ip) : null,
      r.ssid ? el("span", { class: "muted", style: "font-size:10px" }, r.ssid) : null,
      (!r.ssid && r.connection_type) ? el("span", { class: "muted", style: "font-size:10px" }, r.connection_type) : null,
      r.wifi_signal != null ? el("span", { class: "muted", style: "font-size:10px" }, `WiFi ${r.wifi_signal} dBm`) : null,
    ].filter(Boolean);
    const subRow = el("div", { style: "display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:2px" }, subParts);

    const div = el("div", { class: "bt-scanner-row" + (r.lost || r.disabled ? " warn" : "") }, [
      el("div", { class: "bt-scanner-main" }, [ nameRow, subRow, offsetRow, resetWrap ]),
      el("div", { class: "bt-scanner-meta" }, meta.join(" • ") || "—"),
    ]);
    if(r.lost || r.disabled) div.style.opacity = "0.7";
    div.style.cursor = "pointer";
    div.title = "Click for scanner details";
    div.addEventListener("click", (ev) => { if(ev.target.tagName === "BUTTON" || ev.target.tagName === "INPUT") return; ctx.actions.showScannerDetail(r); });
    return div;
  };

  return el("div", { class: "grid-2" }, [
    el("div", { class: "card" }, [el("div", { class: "h2" }, "Scanners"), el("div", { class: "muted" }, "All currently registered scanners/adapters."), el("div", { class: "bt-list" }, radios.map(row))]),
    el("div", { class: "card" }, [
      el("div", { class: "h2" }, "Sources"),
      el("div", { class: "muted" }, "Unique scanner source IDs."),

      el("div", { class: "bt-pills" }, sources.filter(s => s !== "all").map(s => el("span", { class: "pill" }, s))),
    ]),
  ]);
}

function renderMonitor(ctx, ads, radios, objIndex) {
  const { el, esc } = ctx.helpers;

  const selected = ctx.state.btSelectedAddr || null;

  if (!ads.length) {
    return el("div", { class: "card" }, [
      el("div", { style: "font-weight:700" }, "No advertisements in the window"),
      el("div", { class: "muted" }, "Try widening Max rows, clearing filters, or wait a moment for advertisements to arrive."),
    ]);
  }

  const rssiPill = rssi => {
    const v = Number(rssi);
    if (!isFinite(v)) return el("span", { class: "pill" }, "RSSI ?");
    let cls = "pill";
    if (v >= -60) cls += " good";
    else if (v >= -80) cls += " ok";
    else cls += " bad";
    return el("span", { class: cls }, `RSSI ${v}`);
  };

  const statusPill = (addr) => {
    const o = addr ? objIndex.get(String(addr).toUpperCase()) : null;
    if (!o) return null;
    const cls = o.identified ? "badge" : "badge warn";
    const lbl = o.identified ? "identified" : "unidentified";
    return el("span", { class: cls }, lbl);
  };

  const ageText = age_s => {
    const s = Number(age_s);
    if (!isFinite(s)) return "—";
    if (s < 1) return "<1s";
    if (s < 60) return `${Math.round(s)}s`;
    const m = Math.floor(s / 60);
    const rs = Math.round(s - m * 60);
    return `${m}m ${rs}s`;
  };

  const row = a => {
    const name = a.name || "";
    const addr = a.address || "";
    const src = a.source || "";
    const services = Array.isArray(a.service_uuids) ? a.service_uuids.length : 0;
    const obj = addr ? objIndex.get(String(addr).toUpperCase()) : null;
    const userLabel = (obj && obj.user_label) ? obj.user_label : "";
    const displayName = userLabel || name || addr || "Unknown";

    const tagBtn = el("button", { class: "btn tiny" }, userLabel ? "Relabel" : "Tag");
    tagBtn.addEventListener("click", e => {
      e.stopPropagation();
      ctx.actions.tagObjectPrompt(addr, userLabel);
    });

    return el(
      "div",
      {
        class: "bt-adv-row" + (selected === addr ? " active" : ""),
        onclick: () => {
          ctx.state.btSelectedAddr = selected === addr ? null : addr;
          ctx.actions.renderRooms();
        },
      },
      [
        el("div", { class: "bt-adv-main" }, [
          el("div", { class: "bt-adv-name" }, displayName),
          el("div", { class: "bt-adv-sub" }, addr ? `${addr} • ${src || "—"}` : src || "—"),
        ]),
        el("div", { class: "bt-adv-right" }, [
          statusPill(addr),
          rssiPill(a.rssi),
          el("span", { class: "muted" }, ageText(a.age_s)),
          el("span", { class: "muted" }, services ? `${services} svc` : ""),
          tagBtn,
        ]),
      ]
    );
  };

  const details = (() => {
    if (!selected) return null;
    const a = ads.find(x => x && String(x.address || "") === selected) || null;
    if (!a) return null;
    const snap = ctx.state.live?.snapshot;
    const matchedObj = (snap?.objects?.list||[]).find(o =>
      o.address && o.address.toUpperCase() === selected.toUpperCase()
    );
    const card = el("div", { class: "card" }, [
      el("div", { class: "h2" }, "Details"),
      el("div", { class: "muted", style: "margin-bottom:8px" }, "Raw advertisement record (trimmed to JSON-safe values)."),
      el("pre", { class: "pre" }, esc(JSON.stringify(a, null, 2))),
    ]);
    if(matchedObj){
      card.appendChild(el("button", {class:"btn inline", style:"margin-top:8px",
        onclick:()=> ctx.actions.showObjectDetail(matchedObj)
      }, "Full object details"));
    }
    return card;
  })();

  return el("div", { class: "grid-2" }, [
    el("div", { class: "card" }, [
      el("div", { class: "h2" }, "Advertisement monitor"),
      el("div", { class: "muted" }, "Click a row to inspect details."),
      el("div", { class: "bt-list bt-adv-list" }, ads.map(row)),
    ]),
    details || el("div", { class: "card" }, [el("div", { class: "h2" }, "Details"), el("div", { class: "muted" }, "Select an advertisement on the left.")]),
  ]);
}

function renderVisualization(ctx, radios, ads, objIndex) {
  const { el } = ctx.helpers;

  if (!radios.length && !ads.length) {
    return el("div", { class: "card" }, [
      el("div", { style: "font-weight:700" }, "Nothing to visualize yet"),
      el("div", { class: "muted" }, "Waiting for scanner list + advertisements. If this stays empty, check the Diagnostics panel for BLE errors."),
    ]);
  }

  // Layout: labels on the outer edges, nodes in the middle, lines between nodes.
  //   [Scanner labels →]  (o)----line----(o)  [← Device labels]
  const w = 920;
  const pad = 24;
  const scannerLabelX = pad + 10;          // labels start here (left-aligned)
  const scannerNodeX = pad + 300;          // scanner circles — more room for labels
  const deviceNodeX = w - pad - 300;       // device circles — more room for labels
  const deviceLabelX = w - pad - 10;       // device labels end here

  const srcs = Array.from(new Set(radios.map(r => String(r.source || "")).filter(Boolean))).sort();
  const srcIndex = new Map(srcs.map((s, i) => [s, i]));

  // Group devices by source
  const bySrc = {};
  for (const a of ads) {
    const src = String(a.source || "");
    if (!bySrc[src]) bySrc[src] = [];
    bySrc[src].push(a);
  }

  // Dynamic height: 16px per device row, minimum 460, plus room for titles
  const DEV_ROW_H = 16;
  const totalDevCount = Object.values(bySrc).reduce((sum, arr) => sum + Math.min(arr.length, 24), 0);
  const h = Math.max(460, totalDevCount * DEV_ROW_H + pad * 3 + 30);

  // Place scanners evenly along the left (initial pass, repositioned after devices)
  const scannerNodes = srcs.map((src, i) => {
    const y = pad + 20 + (i + 1) * ((h - pad * 2 - 20) / (srcs.length + 1));
    return { id: src, label: (radios.find(r => String(r.source || "") === src)?.name || src), x: scannerNodeX, y };
  });

  // Place devices near their source scanner, then resolve overlaps
  const deviceNodes = [];
  for (const src of Object.keys(bySrc)) {
    const sIdx = srcIndex.has(src) ? srcIndex.get(src) : -1;
    const base = scannerNodes[Math.max(0, sIdx)] || { x: scannerNodeX, y: h / 2 };
    const list = bySrc[src].slice(0, 24);
    const blockH = list.length * DEV_ROW_H;
    const startY = base.y - blockH / 2;
    for (let i = 0; i < list.length; i++) {
      const a = list[i];
      deviceNodes.push({
        id: String(a.address || a.name || `${src}-${i}`),
        label: String(a.name || a.address || "Unknown"),
        x: deviceNodeX,
        y: startY + i * DEV_ROW_H,
        src,
        rssi: a.rssi,
      });
    }
  }

  // Resolve vertical overlaps: sort by Y, push apart if too close
  deviceNodes.sort((a, b) => a.y - b.y);
  const MIN_GAP = DEV_ROW_H;
  for (let i = 1; i < deviceNodes.length; i++) {
    const gap = deviceNodes[i].y - deviceNodes[i - 1].y;
    if (gap < MIN_GAP) deviceNodes[i].y = deviceNodes[i - 1].y + MIN_GAP;
  }
  // Clamp all nodes within canvas bounds
  for (const d of deviceNodes) {
    d.y = Math.max(pad + 20, Math.min(h - pad - 10, d.y));
  }

  // Reposition each scanner to the vertical center of its device cluster
  for (const sn of scannerNodes) {
    const myDevs = deviceNodes.filter(d => d.src === sn.id);
    if (myDevs.length) {
      const minY = Math.min(...myDevs.map(d => d.y));
      const maxY = Math.max(...myDevs.map(d => d.y));
      sn.y = (minY + maxY) / 2;
    }
  }
  // Resolve scanner overlaps too (minimum 30px apart)
  scannerNodes.sort((a, b) => a.y - b.y);
  for (let i = 1; i < scannerNodes.length; i++) {
    if (scannerNodes[i].y - scannerNodes[i - 1].y < 30) {
      scannerNodes[i].y = scannerNodes[i - 1].y + 30;
    }
  }
  for (const sn of scannerNodes) {
    sn.y = Math.max(pad + 20, Math.min(h - pad - 10, sn.y));
  }

  const rssiClass = rssi => {
    const v = Number(rssi);
    if (!isFinite(v)) return "rssi-unk";
    if (v >= -60) return "rssi-good";
    if (v >= -80) return "rssi-ok";
    return "rssi-bad";
  };

  // Build SVG as an HTML string — avoids the HTML-namespace issue that makes
  // document.createElement("circle") / ("line") render as invisible elements.
  let s = `<svg class="bt-viz" viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg">`;

  // Lines first (back layer) — connect between the node circles only
  for (const d of deviceNodes) {
    const sn = scannerNodes.find(n => n.id === d.src);
    if (!sn) continue;
    const rc = rssiClass(d.rssi);
    s += `<line x1="${sn.x + 10}" y1="${sn.y}" x2="${d.x - 10}" y2="${d.y}" class="bt-viz-line ${rc}"/>`;
  }

  // Truncate helper — keeps SVG text from overflowing
  const MAX_LABEL = 38;
  const trunc = (s) => s.length > MAX_LABEL ? s.slice(0, MAX_LABEL - 1) + "…" : s;

  // Scanner nodes + labels (left-aligned, growing rightward toward node)
  for (const sn of scannerNodes) {
    s += `<circle cx="${sn.x}" cy="${sn.y}" r="7" class="bt-viz-node scanner"/>`;
    s += `<text x="${scannerLabelX}" y="${sn.y}" class="bt-viz-label" text-anchor="start" dominant-baseline="middle">${_escSvg(trunc(sn.label))}</text>`;
  }

  // Device nodes + labels (left-aligned, growing rightward from node)
  for (const d of deviceNodes) {
    const rc = rssiClass(d.rssi);
    s += `<circle cx="${d.x}" cy="${d.y}" r="5" class="bt-viz-node device ${rc}"/>`;
    s += `<text x="${d.x + 10}" y="${d.y}" class="bt-viz-label" font-size="11" text-anchor="start" dominant-baseline="middle">${_escSvg(trunc(d.label))}</text>`;
  }

  // Titles on top
  s += `<text x="${scannerLabelX}" y="${pad}" class="bt-viz-title" text-anchor="start" dominant-baseline="middle">Scanners</text>`;
  s += `<text x="${deviceNodeX + 10}" y="${pad}" class="bt-viz-title" text-anchor="start" dominant-baseline="middle">Devices</text>`;

  s += `</svg>`;

  const svgWrap = document.createElement("div");
  svgWrap.innerHTML = s;

  return el("div", { class: "card" }, [
    el("div", { class: "h2" }, "Visualization"),
    el("div", { class: "muted", style: "margin-bottom:10px" }, "A simple scanner→device graph, grouped by the scanner source that reported the advertisement."),
    svgWrap,
    el("div", { class: "muted", style: "margin-top:10px" }, "Tip: use Source + Search filters above to narrow the graph."),
  ]);
}

function _escSvg(s) {
  return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
