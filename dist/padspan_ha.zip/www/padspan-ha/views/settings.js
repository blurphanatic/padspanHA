export function render(ctx){
  const { el, roomColor, helpBtn } = ctx.helpers;
  const isBasic = ctx.state.complexity === "basic";
  const root = el("section",{id:"settings"});
  root.className = ctx.state.view==="settings" ? "" : "hidden";

  // Draft model (so users can edit and hit Save)
  if(!ctx.state._settingsDraft || ctx.state._settingsDraftBuild !== ctx.state.buildId){
    ctx.state._settingsDraft = JSON.parse(JSON.stringify(ctx.state.model || {floors:[], room_meta:{}}));

  // Ensure a stable default "main" floor exists.
  if(!ctx.state._settingsDraft.floors || !ctx.state._settingsDraft.floors.length) ctx.state._settingsDraft.floors = [{id:"main", name:"Main"}];
  if(!ctx.state._settingsDraft.floors.find(f=>f.id==="main")) ctx.state._settingsDraft.floors.unshift({id:"main", name:"Main"});

    ctx.state._settingsDraftBuild = ctx.state.buildId;
  }
  const draft = ctx.state._settingsDraft;

  const haFloors = (ctx.state.model && Array.isArray(ctx.state.model.floors)) ? ctx.state.model.floors : [];
  const haAreas  = (ctx.state.model && Array.isArray(ctx.state.model.areas))  ? ctx.state.model.areas  : [];

  // In basic mode: no tabs, just render appearance content
  if(isBasic){
    root.appendChild(_settingsAppearance(ctx, el, helpBtn, draft, haFloors, haAreas, roomColor, isBasic));
    return root;
  }

  // Advanced mode: tabs
  if(!ctx.state.settingsTab) ctx.state.settingsTab = "appearance";
  const activeTab = ctx.state.settingsTab;
  const setTab = (t) => { ctx.state.settingsTab = t; ctx.actions.renderRooms(); };

  const tabs = el("div", {class:"tabs", style:"margin-bottom:12px"}, [
    el("button", {class:"tab"+(activeTab==="appearance"?" active":""), onclick:()=>setTab("appearance")}, "Appearance"),
    el("button", {class:"tab"+(activeTab==="manage"?" active":""), onclick:()=>setTab("manage")}, "Manage"),
  ]);
  root.appendChild(tabs);

  if(activeTab === "manage"){
    root.appendChild(_settingsManage(ctx, el));
  } else {
    root.appendChild(_settingsAppearance(ctx, el, helpBtn, draft, haFloors, haAreas, roomColor, isBasic));
  }

  return root;
}

function _settingsAppearance(ctx, el, helpBtn, draft, haFloors, haAreas, roomColor, isBasic){
  const wrap = el("div",{});

  const floorsCard = el("div",{class:"card"});
  floorsCard.appendChild(el("div",{style:"font-weight:700"},"Floors"));
  floorsCard.appendChild(el("div",{class:"muted", style:"font-size:12px;margin-top:4px"},
    "Floors are read from HA. Manage them in HA Settings → Areas & Zones."
  ));
  const floorPills = el("div",{style:"display:flex;flex-wrap:wrap;gap:8px;margin-top:10px"});
  if(haFloors.length){
    for(const f of haFloors) floorPills.appendChild(el("span",{class:"pill"}, f.name || f.id));
  } else {
    floorPills.appendChild(el("span",{class:"muted", style:"font-size:12px"}, "No floors found in HA."));
  }
  floorsCard.appendChild(floorPills);

  const roomsCard = el("div",{class:"card", style:"margin-top:12px"});
  roomsCard.appendChild(el("div",{class:"card-head"},[
    el("div",{style:"font-weight:700"}, isBasic ? "Room colours" : "Rooms"),
    helpBtn("settings_colors"),
  ]));
  roomsCard.appendChild(el("div",{class:"muted", style:"font-size:12px;margin-top:6px"},
    isBasic
      ? "Pick a colour for each room — this colour shows up on the Follow map and Overview."
      : "Assign each room to a floor and pick a color for sidebar + map overlays."
  ));

  const snap = (ctx.state.live && ctx.state.live.snapshot) || null;
  const rooms = (() => {
    const disc = snap && snap.rooms_discovered;
    if (disc && disc.length) return [...disc].sort((a,b) => a.localeCompare(b));
    return Object.keys(ctx.state.roomTagMap||{}).sort((a,b) => a.localeCompare(b));
  })();

  const table = el("div",{style:"margin-top:10px;display:flex;flex-direction:column;gap:8px"});
  for(const room of rooms){
    if(!draft.room_meta) draft.room_meta = {};
    if(!draft.room_meta[room]) draft.room_meta[room] = { floor_id: "main", color: _toHex(roomColor(room)) };

    const meta = draft.room_meta[room];

    const haArea = haAreas.find(a => a.name === room);
    const haFloorId = haArea?.floor_id || "";
    if(haFloorId) meta.floor_id = haFloorId;
    const haFloor = haFloors.find(f => f.id === meta.floor_id);
    const floorLabel = haFloor ? (haFloor.name || haFloor.id) : (meta.floor_id || "—");

    const row = el("div",{style:"display:grid;grid-template-columns: 1fr 140px 90px;gap:10px;align-items:center;border:1px solid #1b3526;border-radius:12px;padding:10px;background:#0a150e"});
    row.appendChild(el("div",{style:"display:flex;align-items:center;gap:10px;flex-wrap:wrap"},[
      el("span",{class:"dot", style:`background:${meta.color || roomColor(room)};`}),
      el("div",{style:"font-weight:600"}, room),
    ]));

    row.appendChild(el("div",{style:"display:flex;flex-direction:column;gap:2px"},[
      el("div",{class:"muted", style:"font-size:10px"}, "Floor (HA)"),
      el("div",{style:"font-size:12px;font-weight:600;color:#94a3b8"}, floorLabel),
    ]));

    const col = document.createElement("input");
    col.type = "color";
    col.value = _toHex(meta.color || roomColor(room));
    col.addEventListener("input", ()=>{ meta.color = col.value; });
    row.appendChild(col);

    table.appendChild(row);
  }
  roomsCard.appendChild(table);

  const saveCard = el("div",{class:"card", style:"margin-top:12px"});
  const saveBtn = el("button",{class:"btn primary", onclick:async ()=>{
    await ctx.actions.modelUpdate({floors: draft.floors || [], room_meta: draft.room_meta || {}});
    alert("Saved ✔");
  }}, "Save floors & room settings");

  saveCard.appendChild(el("div",{class:"muted"},"These settings are stored locally in Home Assistant storage."));
  saveCard.appendChild(el("div",{style:"margin-top:10px"}, saveBtn));

  if(!isBasic) wrap.appendChild(floorsCard);
  wrap.appendChild(roomsCard);
  wrap.appendChild(saveCard);
  return wrap;
}

function _settingsManage(ctx, el){
  const snap = (ctx.state.live && ctx.state.live.snapshot) || null;
  const haAreas = (ctx.state.model && Array.isArray(ctx.state.model.areas)) ? ctx.state.model.areas : [];
  const haFloors = (ctx.state.model && Array.isArray(ctx.state.model.floors)) ? ctx.state.model.floors : [];

  const wrap = el("div", {style:"display:flex;flex-direction:column;gap:14px"});

  // ── Section 1: BLE Tags ─────────────────────────────────────────────────────
  const allObjs = (snap?.objects?.list||[]);
  const taggedObjs = allObjs.filter(o => o.kind === "ble" && o.user_label);

  const tagsCard = el("div", {class:"card"});
  tagsCard.appendChild(el("div", {class:"card-head"}, [
    el("div", {style:"font-weight:700"}, "BLE Tags"),
    el("span", {class:"badge", style:"margin-left:8px"}, String(taggedObjs.length)),
  ]));
  tagsCard.appendChild(el("div", {class:"muted", style:"font-size:12px;margin-top:4px;margin-bottom:10px"},
    "Remove a label to untag a BLE device. The device will still be detected, just no longer identified."
  ));

  if(taggedObjs.length){
    const tbody = el("tbody");
    for(const o of taggedObjs){
      const addr = o.address || "";
      const ageTxt = o.age_s != null ? `${Math.round(o.age_s)}s ago` : "—";
      const untagBtn = el("button", {class:"btn tiny"}, "Untag");
      untagBtn.addEventListener("click", async ()=>{
        if(!confirm(`Remove label "${o.user_label}" from ${addr}?`)) return;
        try {
          await ctx.actions.objectLabelDelete(addr);
          await ctx.actions.refreshSnapshot();
          ctx.actions.renderRooms();
          ctx.toast("Label removed.");
        } catch(e){ ctx.toast("Failed to remove label.", true); }
      });
      tbody.appendChild(el("tr", {}, [
        el("td", {style:"font-family:monospace;font-size:11px"}, addr),
        el("td", {style:"font-weight:600"}, o.user_label),
        el("td", {class:"muted", style:"font-size:11px"}, ageTxt),
        el("td", {}, untagBtn),
      ]));
    }
    tagsCard.appendChild(el("table", {class:"table"}, [
      el("thead", {}, el("tr", {}, [
        el("th",{}, "Address"), el("th",{}, "Label"), el("th",{}, "Last seen"), el("th",{}, ""),
      ])),
      tbody,
    ]));
  } else {
    tagsCard.appendChild(el("div", {class:"muted", style:"font-size:12px"}, "No BLE devices have been tagged yet."));
  }
  wrap.appendChild(tagsCard);

  // ── Section 2: Rooms / HA Areas ────────────────────────────────────────────
  const areasCard = el("div", {class:"card"});
  areasCard.appendChild(el("div", {class:"card-head"}, [
    el("div", {style:"font-weight:700"}, "Rooms (HA Areas)"),
  ]));
  areasCard.appendChild(el("div", {class:"muted warn", style:"font-size:12px;margin-top:4px;margin-bottom:10px"},
    "Deleting removes the area from Home Assistant entirely. This cannot be undone."
  ));

  if(haAreas.length){
    const tbody = el("tbody");
    for(const area of haAreas){
      const floor = haFloors.find(f => f.id === area.floor_id);
      const floorLabel = floor ? floor.name : (area.floor_id || "—");
      const delBtn = el("button", {class:"btn tiny"}, "Delete");
      delBtn.addEventListener("click", async ()=>{
        if(!confirm(`Delete area "${area.name}"? This cannot be undone.`)) return;
        try {
          await ctx.actions.areaDelete(area.id);
          await ctx.actions.modelRefresh();
          ctx.toast(`Area "${area.name}" deleted.`);
        } catch(e){ ctx.toast("Failed to delete area: " + String(e), true); }
      });
      tbody.appendChild(el("tr", {}, [
        el("td", {style:"font-weight:600"}, area.name),
        el("td", {class:"muted"}, floorLabel),
        el("td", {}, delBtn),
      ]));
    }
    areasCard.appendChild(el("table", {class:"table"}, [
      el("thead", {}, el("tr", {}, [el("th",{}, "Room"), el("th",{}, "Floor"), el("th",{}, "")])),
      tbody,
    ]));
  } else {
    areasCard.appendChild(el("div", {class:"muted", style:"font-size:12px"}, "No areas found. Add areas in HA Settings → Areas & Zones."));
  }
  wrap.appendChild(areasCard);

  return wrap;
}

function _slug(s){
  return String(s||"").trim().toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/-+/g,"-").replace(/^-|-$/g,"") || "floor";
}

function _toHex(c){
  const s = String(c||"").trim();
  if(/^#[0-9a-f]{6}$/i.test(s)) return s;
  const tmp = document.createElement("div");
  tmp.style.color = s;
  document.body.appendChild(tmp);
  const rgb = getComputedStyle(tmp).color;
  tmp.remove();
  const m = rgb.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
  if(!m) return "#888888";
  const r = Number(m[1])|0, g=Number(m[2])|0, b=Number(m[3])|0;
  return "#" + [r,g,b].map(x=>x.toString(16).padStart(2,"0")).join("");
}
