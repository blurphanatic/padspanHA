// PadSpan HA — BLE Room-Presence Tracking for Home Assistant
// Copyright (C) 2026 Garry Broeckling
// Licensed under the GNU General Public License v3.0
// See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
/**
 * Traceback — NVR-style playback of object movement history on the 3D iso map.
 * Extracted from overview.js into its own dedicated tab.
 */

export function render(ctx) {
  const { el, esc: _esc } = ctx.helpers;
  const roomColorFn = ctx.helpers.roomColor;
  const liveSnap = ctx.state.live?.snapshot || null;
  const radios = (liveSnap?.ble?.radios) || [];

  const outer = document.createElement("div");
  outer.style.cssText = "padding:0";

  // ── 3D Iso map setup (mirrors overview) ────────────────────────────────
  const maps_list = (ctx.state.maps?.list) || [];
  if (!maps_list.length) {
    const msg = document.createElement("div");
    msg.className = "card";
    msg.style.cssText = "text-align:center;padding:30px;color:#94a3b8";
    msg.textContent = "No maps uploaded yet. Go to Maps to add floor plans, then use Traceback to replay object movement.";
    outer.appendChild(msg);
    return outer;
  }

  const TILE = 220, CX = 380, CY = 590, W = 760, BASE_H = 940;
  const LAYER_PAL = ["#52b788","#f59e0b","#60a5fa","#e879f9","#fb923c","#34d399","#f87171","#a78bfa"];

  if(ctx.state._overviewFloorGap===undefined) ctx.state._overviewFloorGap = ctx.state.settings?.overview_iso_floor_gap ?? 150;
  if(ctx.state._overviewHorizGap===undefined) ctx.state._overviewHorizGap = ctx.state.settings?.overview_iso_horiz_gap ?? 0;
  let _ovFG = ctx.state._overviewFloorGap, _ovHG = ctx.state._overviewHorizGap;

  const iso = (wx, wy, wz) => [CX + (wx - wy) * TILE * 0.866 + wz * _ovHG, CY + (wx + wy) * TILE * 0.5 - wz * _ovFG];
  const pt  = c => `${Math.round(c[0])},${Math.round(c[1])}`;
  const pts = cs => cs.map(pt).join(" ");

  // Filter hidden maps
  const hiddenIds = ctx.state.maps._hiddenMapIds || new Set();
  const sorted = [...maps_list].filter(m => !hiddenIds.has(m.id)).sort((a, b) => (a.stack?.z_level || 0) - (b.stack?.z_level || 0));

  // Group maps by z_level
  const byLevel = new Map();
  for (const m of sorted) {
    const z = m.stack?.z_level ?? 0;
    if (!byLevel.has(z)) byLevel.set(z, []);
    byLevel.get(z).push(m);
  }
  const sortedIsoLevels = [...byLevel.keys()].sort((a, b) => a - b);
  const levelColor = (z) => LAYER_PAL[sortedIsoLevels.indexOf(z) % LAYER_PAL.length];
  const LEGEND_H = 30;  // single-row compact legend (matches overview)

  // Build room centroid iso positions (rebuilt when sliders change)
  const roomIsoPos = {};
  function _rebuildRoomPositions() {
    for (const k of Object.keys(roomIsoPos)) delete roomIsoPos[k];
    for (const m of sorted) {
      const stk = m.stack || {}, z = stk.z_level || 0, ox = stk.x_offset || 0, oy_ = stk.y_offset || 0, sc = stk.scale || 1.0;
      const ar = (m.image?.height || 600) / (m.image?.width || 800);
      for (const [room, b] of Object.entries(m.room_bounds || {})) {
        if (!b || b.type !== "poly" || !Array.isArray(b.points) || b.points.length < 3) continue;
        const cx = b.points.reduce((a, p) => a + p[0], 0) / b.points.length;
        const cy = b.points.reduce((a, p) => a + p[1], 0) / b.points.length;
        roomIsoPos[room] = iso(ox + cx * sc, oy_ + cy * sc * ar, z);
      }
    }
  }
  _rebuildRoomPositions();

  // Slider positions for floor focus
  const _isoPos = [null];
  for (let i = 0; i < sortedIsoLevels.length; i++) {
    _isoPos.push(sortedIsoLevels[i]);
    if (i < sortedIsoLevels.length - 1) _isoPos.push([sortedIsoLevels[i], sortedIsoLevels[i + 1]]);
  }
  if(ctx.state._overviewIsoFocusIdx === undefined)
    ctx.state._overviewIsoFocusIdx = Math.max(0, Math.min(ctx.state.settings?.overview_iso_focus ?? 0, _isoPos.length-1));
  let focusZ = _isoPos[Math.max(0, Math.min(ctx.state._overviewIsoFocusIdx, _isoPos.length - 1))];

  function _getFocusLbl(idx) {
    const fz = _isoPos[Math.max(0, Math.min(idx, _isoPos.length-1))];
    if (fz === null) return "All floors";
    if (Array.isArray(fz)) return `Floors ${sortedIsoLevels.indexOf(fz[0])+1}–${sortedIsoLevels.indexOf(fz[1])+1}`;
    return `Floor ${sortedIsoLevels.indexOf(fz)+1}`;
  }

  // ── Traceback state ────────────────────────────────────────────────────
  if (!ctx.state._traceback) ctx.state._traceback = {
    mode: "playback",     // "playback" | "discovery"
    playing: false,
    playDurationS: 300,   // how long full playback takes (1 min to 1 hr slider)
    frameIdx: 0,
    frames: [],
    range: null,
    objKeys: [],
    filterKey: null,
    filterName: "All objects",
    rangePreset: 300,
    startTs: null,
    endTs: null,
    _animTimer: null,
    // Discovery mode state
    discoFromMin: 60,     // search from X minutes ago
    discoToMin: 0,        // search to Y minutes ago (0 = now)
    discoResults: [],     // filtered objects
    discoSelected: null,  // selected object key for highlighting
  };
  if (!ctx.state._traceback.mode) ctx.state._traceback.mode = "playback";
  const tb = ctx.state._traceback;

  function _fmtTime(ts) {
    if (!ts) return "--";
    return new Date(ts * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  }
  function _fmtDate(ts) {
    if (!ts) return "--";
    const d = new Date(ts * 1000);
    return d.toLocaleDateString([], { month: "short", day: "numeric" }) + " " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }
  function _fmtDuration(sec) {
    if (sec < 60) return `${Math.round(sec)}s`;
    if (sec < 3600) return `${Math.round(sec / 60)}m`;
    if (sec < 86400) return `${(sec / 3600).toFixed(1)}h`;
    return `${(sec / 86400).toFixed(1)}d`;
  }

  // ── Data loading ───────────────────────────────────────────────────────
  async function _loadTracebackData() {
    try {
      const now = Date.now() / 1000;
      const startTs = tb.startTs || (now - tb.rangePreset);
      const endTs = tb.endTs || now;
      const res = await ctx.actions.wsCall("padspan_ha/traceback_get", {
        start_ts: startTs,
        end_ts: endTs,
        obj_key: tb.filterKey || undefined,
        max_frames: 4000,
      });
      tb.frames = res.frames || [];
      tb.range = res.range || { start: 0, end: 0, count: 0 };
      tb.frameIdx = 0;
      tb._staticKeys = null;  // recompute on next render

      // If filtering by object and no frames found, auto-expand to full data range
      if (tb.filterKey && !tb.frames.length && tb.range && tb.range.start > 0) {
        const fullRes = await ctx.actions.wsCall("padspan_ha/traceback_get", {
          start_ts: tb.range.start,
          end_ts: tb.range.end || now,
          obj_key: tb.filterKey,
          max_frames: 4000,
        });
        tb.frames = fullRes.frames || [];
        tb._staticKeys = null;  // recompute on next render
        if (tb.frames.length) {
          tb._autoExpanded = true;
        }
      } else {
        tb._autoExpanded = false;
      }

      const objRes = await ctx.actions.wsCall("padspan_ha/traceback_objects", {});
      tb.objKeys = objRes.objects || [];
      tb.range = objRes.range || tb.range;
    } catch (e) {
      console.error("Traceback load error:", e);
      tb.frames = [];
    }
  }

  // ── SVG builder ────────────────────────────────────────────────────────
  function _buildTracebackSVG(frameIdx) {
    const maxIsoZ = sortedIsoLevels.length ? sortedIsoLevels[sortedIsoLevels.length - 1] : 0;
    const viewY = Math.min(0, CY - maxIsoZ * _ovFG - 50);
    const HTOTAL = BASE_H + LEGEND_H - viewY;
    let s = `<svg viewBox="0 ${viewY} ${W} ${HTOTAL}" xmlns="http://www.w3.org/2000/svg" width="100%" style="max-height:${HTOTAL}px;display:block;font-family:system-ui,sans-serif">`;
    s += `<rect x="0" y="${viewY}" width="${W}" height="${HTOTAL}" fill="#071008"/>`;

    // Defs — floor surface patterns (matches overview)
    s += `<defs>`;
    sortedIsoLevels.forEach((z2, li) => {
      const c2 = levelColor(z2);
      if(li === 0){
        s += `<pattern id="tbpat_${li}" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">`;
        s += `<path d="M12,2 C16,2 19,6 19,11 C19,16 16,21 12,22 C8,21 5,16 5,11 C5,6 8,2 12,2 Z" fill="none" stroke="${c2}" stroke-width="0.7" opacity="0.14"/>`;
        s += `<path d="M12,2 C13.5,0 15.5,0.5 14.5,2.5 C13.5,1.5 12,2 12,2 Z" fill="${c2}" opacity="0.11"/>`;
        s += `<circle cx="12" cy="15" r="1.4" fill="${c2}" opacity="0.1"/>`;
        s += `</pattern>`;
      } else if(li === 1){
        s += `<pattern id="tbpat_${li}" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">`;
        s += `<rect x="2" y="2" width="7" height="16" rx="1" fill="none" stroke="${c2}" stroke-width="0.5" opacity="0.13"/>`;
        s += `<rect x="11" y="2" width="7" height="16" rx="1" fill="none" stroke="${c2}" stroke-width="0.5" opacity="0.13"/>`;
        s += `</pattern>`;
      } else if(li === 2){
        s += `<pattern id="tbpat_${li}" x="0" y="0" width="12" height="12" patternUnits="userSpaceOnUse">`;
        s += `<line x1="0" y1="12" x2="12" y2="0" stroke="${c2}" stroke-width="0.6" opacity="0.18"/>`;
        s += `</pattern>`;
      } else {
        s += `<pattern id="tbpat_${li}" x="0" y="0" width="16" height="16" patternUnits="userSpaceOnUse">`;
        s += `<circle cx="8" cy="8" r="2" fill="none" stroke="${c2}" stroke-width="0.5" opacity="0.15"/>`;
        s += `</pattern>`;
      }
    });
    s += `</defs>`;

    // Floor slabs + room polygons + receivers (dim)
    for (const [z, group] of [...byLevel.entries()].sort((a, b) => a[0] - b[0])) {
      const isFocused = focusZ === null || (Array.isArray(focusZ) ? focusZ.includes(z) : focusZ === z);
      const go = isFocused ? 0.7 : 0.08;
      const lyrColor = levelColor(z);
      const lidx = sortedIsoLevels.indexOf(z);

      let x0 = Infinity, y0_ = Infinity, x1 = -Infinity, y1_ = -Infinity;
      for (const m of group) {
        const stk = m.stack || {}, ox = stk.x_offset || 0, oy_ = stk.y_offset || 0, sc = stk.scale || 1.0;
        const ar = (m.image?.height || 600) / (m.image?.width || 800);
        const arRef = stk.ref_ar || ar, sxAdj = stk.scale_x_adj || 1.0;
        const rot = (stk.rotation || 0) * Math.PI / 180;
        const bbPt = (px, py) => { const dx = (px - 0.5) * sc * sxAdj, dy = (py - 0.5) * sc * arRef; return [(0.5 + ox) + dx * Math.cos(rot) - dy * Math.sin(rot), arRef * (0.5 + oy_) + dx * Math.sin(rot) + dy * Math.cos(rot)]; };
        for (const [cx, cy] of [[0, 0], [1, 0], [1, 1], [0, 1]]) { const [wx, wy] = bbPt(cx, cy); x0 = Math.min(x0, wx); y0_ = Math.min(y0_, wy); x1 = Math.max(x1, wx); y1_ = Math.max(y1_, wy); }
      }
      if (!isFinite(x0)) { x0 = 0; y0_ = 0; x1 = 1; y1_ = 0.75; }
      const TL = iso(x0, y0_, z), TR = iso(x1, y0_, z), BR = iso(x1, y1_, z), BL = iso(x0, y1_, z);
      s += `<g opacity="${go}">`;
      s += `<polygon points="${pts([TL, TR, BR, BL])}" fill="url(#tbpat_${lidx})" stroke="${lyrColor}" stroke-width="1.2" stroke-dasharray="10,5" opacity="0.5"/>`;

      // Room polygons
      for (const m of group) {
        const stk = m.stack || {}, ox = stk.x_offset || 0, oy_ = stk.y_offset || 0, sc = stk.scale || 1.0;
        const ar = (m.image?.height || 600) / (m.image?.width || 800);
        const arRef = stk.ref_ar || ar, sxAdj = stk.scale_x_adj || 1.0;
        const rotRad = (stk.rotation || 0) * Math.PI / 180;
        const mapPt = (px, py) => { const dx = (px - 0.5) * sc * sxAdj, dy = (py - 0.5) * sc * arRef, rx = dx * Math.cos(rotRad) - dy * Math.sin(rotRad), ry = dx * Math.sin(rotRad) + dy * Math.cos(rotRad); return [(0.5 + ox) + rx, arRef * (0.5 + oy_) + ry]; };
        for (const [room, b] of Object.entries(m.room_bounds || {})) {
          if (!b || b.type !== "poly" || !Array.isArray(b.points) || b.points.length < 3) continue;
          const color = roomColorFn(room);
          const pp = b.points.map(p => { const [wx, wy] = mapPt(p[0], p[1]); return pt(iso(wx, wy, z)); }).join(" ");
          s += `<polygon points="${pp}" fill="${color}" fill-opacity="0.18" stroke="${color}" stroke-width="1.2" opacity="0.85"/>`;
          const cx2 = b.points.reduce((a, p) => a + p[0], 0) / b.points.length;
          const cy2 = b.points.reduce((a, p) => a + p[1], 0) / b.points.length;
          const [lwx, lwy] = mapPt(cx2, cy2);
          const [lix, liy] = iso(lwx, lwy, z);
          s += `<text x="${Math.round(lix)}" y="${Math.round(liy)}" text-anchor="middle" dominant-baseline="middle" fill="${color}" font-size="9" font-weight="600" opacity="0.85">${_esc(room)}</text>`;
        }
        // Receivers
        for (const r of (m.receivers || [])) {
          const [wx, wy] = mapPt(r.x || 0, r.y || 0);
          const [px2, py2] = iso(wx, wy, z);
          s += `<circle cx="${Math.round(px2)}" cy="${Math.round(py2)}" r="4" fill="#52b788" opacity="0.3"/>`;
        }
      }
      // Layer index
      s += `<circle cx="${Math.round(BL[0])}" cy="${Math.round(BL[1])}" r="12" fill="${lyrColor}" opacity="0.7"/>`;
      s += `<text x="${Math.round(BL[0])}" y="${Math.round(BL[1]) + 5}" text-anchor="middle" fill="#071008" font-size="11" font-weight="700">${lidx + 1}</text>`;
      s += `</g>`;
    }

    // Overlay: playback objects at this frame
    if (tb.frames.length && frameIdx >= 0 && frameIdx < tb.frames.length) {
      const frame = tb.frames[frameIdx];
      const _scannerSrcSet = new Set(((ctx.state.live?.snapshot?.ble?.radios) || []).map(r => String(r.source || "").toUpperCase()).filter(Boolean));
      // Also match scanner names (source key might not match traceback object key)
      for (const r of ((ctx.state.live?.snapshot?.ble?.radios) || [])) {
        if (r.name) _scannerSrcSet.add(String(r.name).toUpperCase());
      }
      // Build set of objects that never change rooms (static — useless in movement playback).
      // Only compute once and cache on tb.
      if (!tb._staticKeys) {
        const _roomByKey = {};
        for (const f of tb.frames) {
          for (const o of (f.o || [])) {
            if (!o.k || !o.r) continue;
            if (!_roomByKey[o.k]) _roomByKey[o.k] = new Set();
            _roomByKey[o.k].add(o.r);
          }
        }
        tb._staticKeys = new Set();
        for (const [k, rooms] of Object.entries(_roomByKey)) {
          if (rooms.size <= 1) tb._staticKeys.add(k);
        }
      }
      const objs = (frame.o || []).filter(o => {
        const ku = String(o.k || "").toUpperCase();
        if (_scannerSrcSet.has(ku)) return false;
        // Keep the specifically filtered object even if static
        if (tb.filterKey && o.k === tb.filterKey) return true;
        // Hide objects that never move throughout the entire playback
        if (tb._staticKeys.has(o.k)) return false;
        return true;
      });
      const _roomCount = {};
      const TB_COLORS = ["#fbbf24", "#60a5fa", "#f87171", "#34d399", "#c4b5fd", "#fb923c", "#5eead4", "#f472b6", "#a3e635", "#818cf8"];
      const _colorMap = {};
      let _ci = 0;
      for (const o of objs) {
        if (!_colorMap[o.k]) { _colorMap[o.k] = TB_COLORS[_ci % TB_COLORS.length]; _ci++; }
      }

      // Trail from prev frames
      const trailLen = Math.min(8, frameIdx);
      for (let ti = Math.max(0, frameIdx - trailLen); ti < frameIdx; ti++) {
        const trailFrame = tb.frames[ti];
        const fade = 0.08 + 0.12 * ((ti - (frameIdx - trailLen)) / trailLen);
        for (const to of (trailFrame.o || [])) {
          if (_scannerSrcSet.has(String(to.k || "").toUpperCase())) continue;
          if (tb._staticKeys && tb._staticKeys.has(to.k) && to.k !== tb.filterKey) continue;
          if (!to.r || !roomIsoPos[to.r]) continue;
          const tpos = roomIsoPos[to.r];
          const col = _colorMap[to.k] || "#fbbf24";
          s += `<circle cx="${Math.round(tpos[0])}" cy="${Math.round(tpos[1])}" r="3" fill="${col}" opacity="${fade.toFixed(2)}"/>`;
        }
      }

      // Current frame objects
      for (const o of objs) {
        if (!o.r || !roomIsoPos[o.r]) continue;
        const pos = roomIsoPos[o.r];
        const idx = (_roomCount[o.r] || 0);
        _roomCount[o.r] = idx + 1;
        const angle = idx * 2.4;
        const radius = 6 + idx * 5;
        const offX = Math.cos(angle) * Math.min(radius, 35);
        const offY = Math.sin(angle) * Math.min(radius, 22);
        const px = Math.round(pos[0] + offX);
        const py = Math.round(pos[1] + offY);
        const col = _colorMap[o.k] || "#fbbf24";
        const lbl = (o.n || o.k || "?").substring(0, 12);
        const tip = `${lbl} | Room: ${o.r}${o.rssi ? " | RSSI: " + o.rssi + " dBm" : ""}`;

        s += `<g data-tip="${_esc(tip)}">`;
        s += `<circle cx="${px}" cy="${py}" r="16" fill="${col}" opacity="0.1"/>`;
        s += `<circle cx="${px}" cy="${py}" r="9" fill="${col}" stroke="#071008" stroke-width="1.5" opacity="0.95"/>`;
        s += `<circle cx="${px}" cy="${py}" r="3" fill="#071008" opacity="0.6"/>`;
        const lblW = Math.min(lbl.length * 6 + 8, 90);
        s += `<rect x="${px - lblW / 2}" y="${py - 24}" width="${lblW}" height="13" rx="3" fill="#071008" opacity="0.8"/>`;
        s += `<text x="${px}" y="${py - 14}" text-anchor="middle" fill="${col}" font-size="9" font-weight="700">${_esc(lbl)}</text>`;
        s += `</g>`;
      }
    }

    // Timestamp overlay
    if (tb.frames.length && frameIdx >= 0 && frameIdx < tb.frames.length) {
      const ts = tb.frames[frameIdx].ts;
      const timeStr = _fmtDate(ts);
      s += `<rect x="${W - 200}" y="${viewY + 4}" width="196" height="22" rx="4" fill="#071008" opacity="0.85"/>`;
      s += `<text x="${W - 102}" y="${viewY + 19}" text-anchor="middle" fill="#fbbf24" font-size="13" font-weight="700">${_esc(timeStr)}</text>`;
    }

    // Legend — compact single row (matches overview)
    s += `<line x1="10" y1="${BASE_H + 4}" x2="${W - 10}" y2="${BASE_H + 4}" stroke="#1b3526" stroke-width="0.8"/>`;
    {
      const ly = BASE_H + 10;
      let lx = 12;
      sortedIsoLevels.forEach((z, i) => {
        const color = levelColor(z);
        const groupLabel = byLevel.get(z).map(m => m.name || m.id).join("+");
        s += `<circle cx="${lx+7}" cy="${ly+7}" r="7" fill="${color}" opacity="0.9"/>`;
        s += `<text x="${lx+7}" y="${ly+10}" text-anchor="middle" fill="#071008" font-size="9" font-weight="700">${i+1}</text>`;
        s += `<text x="${lx+18}" y="${ly+10}" fill="${color}" font-size="11" font-weight="500">${_esc(groupLabel)}</text>`;
        lx += 22 + groupLabel.length * 6;
        if (i < sortedIsoLevels.length - 1) {
          s += `<text x="${lx}" y="${ly+10}" fill="#4a6052" font-size="10">\u00B7</text>`;
          lx += 10;
        }
      });
    }

    s += `</svg>`;
    return s;
  }

  // ── Discovery SVG builder ──────────────────────────────────────────────
  // Renders the same iso map but plots discovered objects instead of playback frames.
  // Each object gets a data-disco attribute for click handling.
  function _buildDiscoverySVG(results) {
    const maxIsoZ = sortedIsoLevels.length ? sortedIsoLevels[sortedIsoLevels.length - 1] : 0;
    const viewY = Math.min(0, CY - maxIsoZ * _ovFG - 50);
    const HTOTAL = BASE_H + LEGEND_H - viewY;
    let s = `<svg viewBox="0 ${viewY} ${W} ${HTOTAL}" xmlns="http://www.w3.org/2000/svg" width="100%" style="max-height:${HTOTAL}px;display:block;font-family:system-ui,sans-serif">`;
    s += `<rect x="0" y="${viewY}" width="${W}" height="${HTOTAL}" fill="#071008"/>`;

    // Defs — reuse same patterns
    s += `<defs>`;
    sortedIsoLevels.forEach((z2, li) => {
      const c2 = levelColor(z2);
      if(li === 0){
        s += `<pattern id="dpat_${li}" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">`;
        s += `<path d="M12,2 C16,2 19,6 19,11 C19,16 16,21 12,22 C8,21 5,16 5,11 C5,6 8,2 12,2 Z" fill="none" stroke="${c2}" stroke-width="0.7" opacity="0.14"/>`;
        s += `<circle cx="12" cy="15" r="1.4" fill="${c2}" opacity="0.1"/>`;
        s += `</pattern>`;
      } else if(li === 1){
        s += `<pattern id="dpat_${li}" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">`;
        s += `<rect x="2" y="2" width="7" height="16" rx="1" fill="none" stroke="${c2}" stroke-width="0.5" opacity="0.13"/>`;
        s += `<rect x="11" y="2" width="7" height="16" rx="1" fill="none" stroke="${c2}" stroke-width="0.5" opacity="0.13"/>`;
        s += `</pattern>`;
      } else if(li === 2){
        s += `<pattern id="dpat_${li}" x="0" y="0" width="12" height="12" patternUnits="userSpaceOnUse">`;
        s += `<line x1="0" y1="12" x2="12" y2="0" stroke="${c2}" stroke-width="0.6" opacity="0.18"/>`;
        s += `</pattern>`;
      } else {
        s += `<pattern id="dpat_${li}" x="0" y="0" width="16" height="16" patternUnits="userSpaceOnUse">`;
        s += `<circle cx="8" cy="8" r="2" fill="none" stroke="${c2}" stroke-width="0.5" opacity="0.15"/>`;
        s += `</pattern>`;
      }
    });
    s += `</defs>`;

    // Floor slabs + room polygons (same as playback)
    for (const [z, group] of [...byLevel.entries()].sort((a, b) => a[0] - b[0])) {
      const isFocused = focusZ === null || (Array.isArray(focusZ) ? focusZ.includes(z) : focusZ === z);
      const go = isFocused ? 0.7 : 0.08;
      const lyrColor = levelColor(z);
      const lidx = sortedIsoLevels.indexOf(z);

      let x0 = Infinity, y0_ = Infinity, x1 = -Infinity, y1_ = -Infinity;
      for (const m of group) {
        const stk = m.stack || {}, ox = stk.x_offset || 0, oy_ = stk.y_offset || 0, sc = stk.scale || 1.0;
        const ar = (m.image?.height || 600) / (m.image?.width || 800);
        const arRef = stk.ref_ar || ar, sxAdj = stk.scale_x_adj || 1.0;
        const rot = (stk.rotation || 0) * Math.PI / 180;
        const bbPt = (px, py) => { const dx = (px - 0.5) * sc * sxAdj, dy = (py - 0.5) * sc * arRef; return [(0.5 + ox) + dx * Math.cos(rot) - dy * Math.sin(rot), arRef * (0.5 + oy_) + dx * Math.sin(rot) + dy * Math.cos(rot)]; };
        for (const [cx2, cy2] of [[0, 0], [1, 0], [1, 1], [0, 1]]) { const [wx, wy] = bbPt(cx2, cy2); x0 = Math.min(x0, wx); y0_ = Math.min(y0_, wy); x1 = Math.max(x1, wx); y1_ = Math.max(y1_, wy); }
      }
      if (!isFinite(x0)) { x0 = 0; y0_ = 0; x1 = 1; y1_ = 0.75; }
      const TL = iso(x0, y0_, z), TR = iso(x1, y0_, z), BR = iso(x1, y1_, z), BL = iso(x0, y1_, z);
      s += `<g opacity="${go}">`;
      s += `<polygon points="${pts([TL, TR, BR, BL])}" fill="url(#dpat_${lidx})" stroke="${lyrColor}" stroke-width="1.2" stroke-dasharray="10,5" opacity="0.5"/>`;

      for (const m of group) {
        const stk = m.stack || {}, ox = stk.x_offset || 0, oy_ = stk.y_offset || 0, sc = stk.scale || 1.0;
        const ar = (m.image?.height || 600) / (m.image?.width || 800);
        const arRef = stk.ref_ar || ar, sxAdj = stk.scale_x_adj || 1.0;
        const rotRad = (stk.rotation || 0) * Math.PI / 180;
        const mapPt = (px, py) => { const dx = (px - 0.5) * sc * sxAdj, dy = (py - 0.5) * sc * arRef, rx = dx * Math.cos(rotRad) - dy * Math.sin(rotRad), ry = dx * Math.sin(rotRad) + dy * Math.cos(rotRad); return [(0.5 + ox) + rx, arRef * (0.5 + oy_) + ry]; };
        for (const [room, b] of Object.entries(m.room_bounds || {})) {
          if (!b || b.type !== "poly" || !Array.isArray(b.points) || b.points.length < 3) continue;
          const color = roomColorFn(room);
          const pp = b.points.map(p => { const [wx, wy] = mapPt(p[0], p[1]); return pt(iso(wx, wy, z)); }).join(" ");
          s += `<polygon points="${pp}" fill="${color}" fill-opacity="0.18" stroke="${color}" stroke-width="1.2" opacity="0.85"/>`;
          const ccx = b.points.reduce((a, p) => a + p[0], 0) / b.points.length;
          const ccy = b.points.reduce((a, p) => a + p[1], 0) / b.points.length;
          const [lwx, lwy] = mapPt(ccx, ccy);
          const [lix, liy] = iso(lwx, lwy, z);
          s += `<text x="${Math.round(lix)}" y="${Math.round(liy)}" text-anchor="middle" dominant-baseline="middle" fill="${color}" font-size="9" font-weight="600" opacity="0.85">${_esc(room)}</text>`;
        }
      }
      s += `<circle cx="${Math.round(BL[0])}" cy="${Math.round(BL[1])}" r="12" fill="${lyrColor}" opacity="0.7"/>`;
      s += `<text x="${Math.round(BL[0])}" y="${Math.round(BL[1]) + 5}" text-anchor="middle" fill="#071008" font-size="11" font-weight="700">${lidx + 1}</text>`;
      s += `</g>`;
    }

    // Overlay: discovered objects at their room positions
    // Objects with a valid room go to that room's iso position.
    // Objects without a room (common for new/unidentified BLE) go to an
    // "unplaced" floating cluster so they're still visible on the map.
    const DISCO_COLORS = ["#e879f9", "#60a5fa", "#f87171", "#34d399", "#fbbf24", "#fb923c", "#5eead4", "#f472b6", "#a3e635", "#818cf8"];
    const _roomCount = {};
    let unplacedCount = 0;

    // Try to resolve room from source scanner's area if obj.room is missing
    const _radioAreaMap = {};
    for (const r of ((liveSnap?.ble?.radios) || [])) {
      if (r.source && r.area_name) _radioAreaMap[r.source] = r.area_name;
      if (r.name && r.area_name) _radioAreaMap[r.name] = r.area_name;
    }

    const _resolveRoom = (obj) => {
      // 1. Direct room field
      if (obj.room && obj.room !== "unknown" && obj.room !== "not_home") return obj.room;
      // 2. Try to get room from strongest source scanner
      const sources = obj.sources || [];
      for (const src of sources) {
        const srcName = typeof src === "string" ? src : (src.source || "");
        if (srcName && _radioAreaMap[srcName]) return _radioAreaMap[srcName];
      }
      if (obj.source && _radioAreaMap[obj.source]) return _radioAreaMap[obj.source];
      return null;
    };

    // Unplaced cluster position — above the top-left of the map
    const unplacedBaseX = 80;
    const unplacedBaseY = viewY + 50;

    for (let di = 0; di < results.length; di++) {
      const obj = results[di];
      const room = _resolveRoom(obj);
      let px, py;

      if (room && roomIsoPos[room]) {
        const pos = roomIsoPos[room];
        const idx = (_roomCount[room] || 0);
        _roomCount[room] = idx + 1;
        const angle = idx * 2.4;
        const radius = 6 + idx * 5;
        px = Math.round(pos[0] + Math.cos(angle) * Math.min(radius, 35));
        py = Math.round(pos[1] + Math.sin(angle) * Math.min(radius, 22));
      } else {
        // Unplaced: arrange in a grid cluster
        const col2 = unplacedCount % 6;
        const row2 = Math.floor(unplacedCount / 6);
        px = unplacedBaseX + col2 * 80;
        py = unplacedBaseY + row2 * 40;
        unplacedCount++;
      }

      const col = DISCO_COLORS[di % DISCO_COLORS.length];
      const isSelected = tb.discoSelected === (obj.key || obj.address);
      const lbl = (obj.user_label || obj.name || obj.address || "?").substring(0, 14);
      const kindBadge = obj.kind === "ibeacon" ? "iB" : obj.kind === "private_ble" ? "pBLE" : obj.kind === "entity" ? "ent" : "BLE";

      // Glow ring for selected
      if (isSelected) {
        s += `<circle cx="${px}" cy="${py}" r="22" fill="none" stroke="${col}" stroke-width="2" opacity="0.6">`;
        s += `<animate attributeName="r" values="18;24;18" dur="1.5s" repeatCount="indefinite"/>`;
        s += `</circle>`;
      }
      s += `<g data-disco="${di}" style="cursor:pointer">`;
      s += `<circle cx="${px}" cy="${py}" r="18" fill="${col}" opacity="0.12" pointer-events="all"/>`;
      s += `<circle cx="${px}" cy="${py}" r="10" fill="${col}" stroke="#071008" stroke-width="1.5" opacity="0.95" pointer-events="all"/>`;
      s += `<text x="${px}" y="${py + 3}" text-anchor="middle" fill="#071008" font-size="6" font-weight="700" pointer-events="none">${kindBadge}</text>`;
      const lblW = Math.min(lbl.length * 5.5 + 10, 100);
      s += `<rect x="${px - lblW / 2}" y="${py - 26}" width="${lblW}" height="14" rx="3" fill="#071008" opacity="0.85" pointer-events="all"/>`;
      s += `<text x="${px}" y="${py - 16}" text-anchor="middle" fill="${col}" font-size="9" font-weight="700" pointer-events="none">${_esc(lbl)}</text>`;
      s += `</g>`;
    }

    // Unplaced label
    if (unplacedCount > 0) {
      s += `<text x="${unplacedBaseX}" y="${unplacedBaseY - 14}" fill="#94a3b8" font-size="10" font-weight="600">Unplaced (${unplacedCount})</text>`;
    }

    // Count badge
    const placedCount = results.length - unplacedCount;
    if (results.length) {
      const badgeW = 240;
      s += `<rect x="6" y="${viewY + 4}" width="${badgeW}" height="22" rx="4" fill="#071008" opacity="0.85"/>`;
      const badgeTxt = placedCount === results.length
        ? `${results.length} new object${results.length !== 1 ? "s" : ""} discovered`
        : `${results.length} discovered (${placedCount} placed, ${unplacedCount} unplaced)`;
      s += `<text x="${badgeW / 2 + 6}" y="${viewY + 19}" text-anchor="middle" fill="#e879f9" font-size="11" font-weight="700">${badgeTxt}</text>`;
    }

    // Legend
    s += `<line x1="10" y1="${BASE_H + 4}" x2="${W - 10}" y2="${BASE_H + 4}" stroke="#1b3526" stroke-width="0.8"/>`;
    {
      const ly = BASE_H + 10;
      let lx = 12;
      sortedIsoLevels.forEach((z, i) => {
        const color = levelColor(z);
        const groupLabel = byLevel.get(z).map(m => m.name || m.id).join("+");
        s += `<circle cx="${lx+7}" cy="${ly+7}" r="7" fill="${color}" opacity="0.9"/>`;
        s += `<text x="${lx+7}" y="${ly+10}" text-anchor="middle" fill="#071008" font-size="9" font-weight="700">${i+1}</text>`;
        s += `<text x="${lx+18}" y="${ly+10}" fill="${color}" font-size="11" font-weight="500">${_esc(groupLabel)}</text>`;
        lx += 22 + groupLabel.length * 6;
        if (i < sortedIsoLevels.length - 1) {
          s += `<text x="${lx}" y="${ly+10}" fill="#4a6052" font-size="10">\u00B7</text>`;
          lx += 10;
        }
      });
    }
    s += `</svg>`;
    return s;
  }

  // ── Discovery search ────────────────────────────────────────────────────
  function _runDiscoverySearch() {
    const nowTs = Date.now() / 1000;
    const fromMin = Math.max(tb.discoFromMin, tb.discoToMin);
    const toMin = Math.min(tb.discoFromMin, tb.discoToMin);
    const startTs = nowTs - (fromMin * 60);
    const endTs = nowTs - (toMin * 60);

    const allObjs = liveSnap?.objects?.list || [];
    const results = allObjs.filter(o => {
      if (!o.first_seen) return false;
      const fs = new Date(o.first_seen).getTime() / 1000;
      return fs >= startTs && fs <= endTs;
    });
    // Sort newest first
    results.sort((a, b) => {
      const fa = new Date(a.first_seen).getTime();
      const fb = new Date(b.first_seen).getTime();
      return fb - fa;
    });
    tb.discoResults = results;
    tb.discoSelected = null;
  }

  // ── Map display div ────────────────────────────────────────────────────
  const mapDiv = document.createElement("div");
  mapDiv.style.cssText = "overflow:auto;border-radius:8px;background:#071008;padding:8px;margin-bottom:10px";

  // ── Playback helpers ───────────────────────────────────────────────────
  function _renderFrame() {
    if (!tb.frames.length) return;
    mapDiv.innerHTML = _buildTracebackSVG(tb.frameIdx);
  }

  function _updateScrubber() {
    const scrubber = ctrlCard.querySelector('#tb-scrubber');
    if (scrubber) scrubber.value = String(tb.frameIdx);
    _updateTimeLbl();
  }

  function _updateTimeLbl() {
    const timeLbl = ctrlCard.querySelector("#tb-time-lbl");
    if (timeLbl && tb.frames[tb.frameIdx]) {
      timeLbl.textContent = _fmtDate(tb.frames[tb.frameIdx].ts);
    }
    const progLbl = ctrlCard.querySelector("#tb-progress-lbl");
    if (progLbl) progLbl.textContent = `${tb.frameIdx + 1} / ${tb.frames.length}`;
  }

  function _startPlayback() {
    if (tb._animTimer) clearInterval(tb._animTimer);
    tb.playing = true;
    // Compute interval: total run time / remaining frames
    const remaining = Math.max(1, tb.frames.length - 1 - tb.frameIdx);
    const totalMs = tb.playDurationS * 1000;
    const interval = Math.max(16, Math.round(totalMs / tb.frames.length));
    tb._animTimer = setInterval(() => {
      if (tb.frameIdx >= tb.frames.length - 1) {
        _stopPlayback();
        _buildControls();
        return;
      }
      tb.frameIdx++;
      _renderFrame();
      _updateScrubber();
    }, interval);
  }

  function _stopPlayback() {
    tb.playing = false;
    if (tb._animTimer) { clearInterval(tb._animTimer); tb._animTimer = null; }
  }

  // ── Controls card ──────────────────────────────────────────────────────
  const ctrlCard = document.createElement("div");
  ctrlCard.className = "card";
  ctrlCard.style.cssText = "border-color:#92400e;background:#0f0a00";

  function _buildControls() {
    ctrlCard.innerHTML = "";

    // Header
    const hdr = document.createElement("div");
    hdr.style.cssText = "display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap";
    const title = document.createElement("span");
    title.style.cssText = "font-weight:700;font-size:15px;color:#fbbf24";
    title.textContent = "Traceback Playback";
    hdr.appendChild(title);
    ctrlCard.appendChild(hdr);

    // Range preset buttons
    const rangeRow = document.createElement("div");
    rangeRow.style.cssText = "display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:10px";
    const rangeLbl = document.createElement("span");
    rangeLbl.style.cssText = "font-size:12px;color:#94a3b8";
    rangeLbl.textContent = "Time range:";
    rangeRow.appendChild(rangeLbl);

    const presets = [
      { label: "5 min", s: 300 }, { label: "15 min", s: 900 }, { label: "30 min", s: 1800 },
      { label: "1 hr", s: 3600 }, { label: "4 hr", s: 14400 }, { label: "12 hr", s: 43200 },
      { label: "1 day", s: 86400 }, { label: "3 days", s: 259200 }, { label: "7 days", s: 604800 },
    ];
    for (const p of presets) {
      const btn = document.createElement("button");
      btn.className = "btn inline";
      const isActive = tb.rangePreset === p.s;
      btn.style.cssText = isActive
        ? "font-size:11px;padding:2px 8px;background:#92400e;color:#fbbf24;border-color:#fbbf24;font-weight:700"
        : "font-size:11px;padding:2px 8px;color:#94a3b8";
      btn.textContent = p.label;
      btn.addEventListener("click", async () => {
        _stopPlayback();
        tb.rangePreset = p.s;
        tb.startTs = null;
        tb.endTs = null;
        await _loadTracebackData();
        _buildControls();
        _renderFrame();
      });
      rangeRow.appendChild(btn);
    }
    ctrlCard.appendChild(rangeRow);

    // Object filter
    const filterRow = document.createElement("div");
    filterRow.style.cssText = "display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px";
    const filterLbl = document.createElement("span");
    filterLbl.style.cssText = "font-size:12px;color:#94a3b8";
    filterLbl.textContent = "Object:";
    filterRow.appendChild(filterLbl);

    const filterSelect = document.createElement("select");
    filterSelect.style.cssText = "background:#071008;color:#e2e8f0;border:1px solid #2d6a4f;border-radius:4px;padding:3px 8px;font-size:12px;max-width:280px";
    const allOpt = document.createElement("option");
    allOpt.value = "";
    allOpt.textContent = "All objects";
    if (!tb.filterKey) allOpt.selected = true;
    filterSelect.appendChild(allOpt);

    const _tbScannerSet = new Set(((ctx.state.live?.snapshot?.ble?.radios) || []).map(r => String(r.source || "").toUpperCase()).filter(Boolean));
    const byKind = {};
    for (const obj of tb.objKeys) {
      // Hide scanners — they're infrastructure, not trackable devices
      if (_tbScannerSet.has(String(obj.key || "").toUpperCase())) continue;
      const kind = obj.kind || "other";
      if (!byKind[kind]) byKind[kind] = [];
      byKind[kind].push(obj);
    }
    for (const [kind, items] of Object.entries(byKind).sort()) {
      const grp = document.createElement("optgroup");
      grp.label = kind;
      for (const item of items.sort((a, b) => (a.name || "").localeCompare(b.name || ""))) {
        const opt = document.createElement("option");
        opt.value = item.key;
        opt.textContent = item.name || item.key;
        if (tb.filterKey === item.key) opt.selected = true;
        grp.appendChild(opt);
      }
      filterSelect.appendChild(grp);
    }
    filterSelect.addEventListener("change", async () => {
      _stopPlayback();
      tb.filterKey = filterSelect.value || null;
      tb.filterName = filterSelect.options[filterSelect.selectedIndex]?.textContent || "All objects";
      await _loadTracebackData();
      _buildControls();
      _renderFrame();
    });
    filterRow.appendChild(filterSelect);

    const infoLbl = document.createElement("span");
    infoLbl.style.cssText = "font-size:11px;color:#64748b;margin-left:auto";
    if (tb.frames.length) {
      const rangeNote = tb._autoExpanded ? "auto-expanded to full range" : `${_fmtDuration(tb.rangePreset)} window`;
      infoLbl.textContent = `${tb.frames.length} frames | ${rangeNote}`;
    } else {
      infoLbl.textContent = tb.filterKey ? "No data for this object" : "No data in range";
    }
    filterRow.appendChild(infoLbl);
    ctrlCard.appendChild(filterRow);

    if (!tb.frames.length) {
      const empty = document.createElement("div");
      empty.style.cssText = "text-align:center;padding:20px;color:#64748b;font-size:13px";
      if (tb.filterKey) {
        empty.textContent = `No traceback data found for "${tb.filterName}". This object may not have been seen recently or may not be identified/followed. Only identified and followed objects are recorded.`;
      } else {
        empty.textContent = "No traceback data in this time range. Only identified and followed objects are recorded (~10s intervals). Try a longer time range or check back after some time.";
      }
      ctrlCard.appendChild(empty);
      return;
    }

    // Transport controls
    const transport = document.createElement("div");
    transport.style.cssText = "display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap";

    // Rewind
    const rewBtn = document.createElement("button");
    rewBtn.className = "btn inline";
    rewBtn.style.cssText = "font-size:14px;padding:2px 8px;color:#fbbf24";
    rewBtn.innerHTML = "&#9198;";
    rewBtn.title = "Jump to start";
    rewBtn.addEventListener("click", () => { tb.frameIdx = 0; _renderFrame(); _updateScrubber(); });
    transport.appendChild(rewBtn);

    // Step back
    const stepBackBtn = document.createElement("button");
    stepBackBtn.className = "btn inline";
    stepBackBtn.style.cssText = "font-size:14px;padding:2px 8px;color:#fbbf24";
    stepBackBtn.innerHTML = "&#9664;";
    stepBackBtn.title = "Previous frame";
    stepBackBtn.addEventListener("click", () => {
      if (tb.frameIdx > 0) { tb.frameIdx--; _renderFrame(); _updateScrubber(); }
    });
    transport.appendChild(stepBackBtn);

    // Play/Pause
    const playBtn = document.createElement("button");
    playBtn.className = "btn inline";
    playBtn.style.cssText = tb.playing
      ? "font-size:16px;padding:3px 12px;background:#92400e;color:#fbbf24;border-color:#fbbf24;font-weight:700"
      : "font-size:16px;padding:3px 12px;color:#fbbf24;border-color:#92400e";
    playBtn.innerHTML = tb.playing ? "&#9646;&#9646;" : "&#9654;";
    playBtn.title = tb.playing ? "Pause" : "Play";
    playBtn.addEventListener("click", () => {
      if (tb.playing) { _stopPlayback(); } else { _startPlayback(); }
      _buildControls();
    });
    transport.appendChild(playBtn);

    // Step forward
    const stepFwdBtn = document.createElement("button");
    stepFwdBtn.className = "btn inline";
    stepFwdBtn.style.cssText = "font-size:14px;padding:2px 8px;color:#fbbf24";
    stepFwdBtn.innerHTML = "&#9654;";
    stepFwdBtn.title = "Next frame";
    stepFwdBtn.addEventListener("click", () => {
      if (tb.frameIdx < tb.frames.length - 1) { tb.frameIdx++; _renderFrame(); _updateScrubber(); }
    });
    transport.appendChild(stepFwdBtn);

    // Jump to end
    const endBtn = document.createElement("button");
    endBtn.className = "btn inline";
    endBtn.style.cssText = "font-size:14px;padding:2px 8px;color:#fbbf24";
    endBtn.innerHTML = "&#9197;";
    endBtn.title = "Jump to end";
    endBtn.addEventListener("click", () => { tb.frameIdx = tb.frames.length - 1; _renderFrame(); _updateScrubber(); });
    transport.appendChild(endBtn);

    // Run time slider (1 min to 60 min)
    const rtWrap = document.createElement("span");
    rtWrap.style.cssText = "display:flex;align-items:center;gap:6px;margin-left:8px";
    const rtLbl = document.createElement("span");
    rtLbl.style.cssText = "font-size:11px;color:#94a3b8;white-space:nowrap";
    rtLbl.textContent = "Run time:";
    rtWrap.appendChild(rtLbl);

    const rtSlider = document.createElement("input");
    rtSlider.type = "range";
    rtSlider.min = "60";
    rtSlider.max = "3600";
    rtSlider.step = "30";
    rtSlider.value = String(tb.playDurationS);
    rtSlider.style.cssText = "width:100px;accent-color:#fbbf24;cursor:pointer;height:20px";
    rtSlider.title = "How long the full playback takes";

    const rtValLbl = document.createElement("span");
    rtValLbl.style.cssText = "font-size:11px;color:#fbbf24;font-weight:600;min-width:36px;font-family:monospace";
    rtValLbl.textContent = _fmtDuration(tb.playDurationS);

    rtSlider.addEventListener("input", () => {
      tb.playDurationS = parseInt(rtSlider.value, 10);
      rtValLbl.textContent = _fmtDuration(tb.playDurationS);
      if (tb.playing) { _stopPlayback(); _startPlayback(); }
    });
    rtWrap.appendChild(rtSlider);
    rtWrap.appendChild(rtValLbl);
    transport.appendChild(rtWrap);

    // Current time display
    const timeLbl = document.createElement("span");
    timeLbl.id = "tb-time-lbl";
    timeLbl.style.cssText = "font-size:12px;color:#fbbf24;font-weight:600;margin-left:auto;font-family:monospace";
    const curTs = tb.frames[tb.frameIdx]?.ts;
    timeLbl.textContent = curTs ? _fmtDate(curTs) : "--";
    transport.appendChild(timeLbl);

    ctrlCard.appendChild(transport);

    // Timeline scrubber
    const scrubberWrap = document.createElement("div");
    scrubberWrap.style.cssText = "position:relative;margin-bottom:6px";

    const scrubber = document.createElement("input");
    scrubber.id = "tb-scrubber";
    scrubber.type = "range";
    scrubber.min = "0";
    scrubber.max = String(Math.max(0, tb.frames.length - 1));
    scrubber.value = String(tb.frameIdx);
    scrubber.style.cssText = "width:100%;accent-color:#fbbf24;cursor:pointer;height:24px";
    scrubber.addEventListener("input", () => {
      tb.frameIdx = parseInt(scrubber.value, 10);
      _renderFrame();
      _updateTimeLbl();
    });
    scrubberWrap.appendChild(scrubber);

    // Time markers
    const markerRow = document.createElement("div");
    markerRow.style.cssText = "display:flex;justify-content:space-between;font-size:10px;color:#64748b;padding:0 2px";
    const startStr = tb.frames.length ? _fmtDate(tb.frames[0].ts) : "--";
    const endStr = tb.frames.length ? _fmtDate(tb.frames[tb.frames.length - 1].ts) : "--";
    markerRow.appendChild(document.createTextNode(startStr));
    const progLbl = document.createElement("span");
    progLbl.id = "tb-progress-lbl";
    progLbl.style.cssText = "color:#94a3b8";
    progLbl.textContent = `${tb.frameIdx + 1} / ${tb.frames.length}`;
    markerRow.appendChild(progLbl);
    markerRow.appendChild(document.createTextNode(endStr));
    scrubberWrap.appendChild(markerRow);

    ctrlCard.appendChild(scrubberWrap);
  }

  // ── Iso controls (Floor / Spacing / L/R / Save / Reset) ────────────────
  const isoCtrlRow = document.createElement("div");
  isoCtrlRow.style.cssText = "display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:8px";

  // Floor focus slider
  const floorLbl = document.createElement("span");
  floorLbl.style.cssText = "font-size:12px;color:#94a3b8";
  floorLbl.textContent = "Floor:";
  isoCtrlRow.appendChild(floorLbl);

  const focusLbl = document.createElement("span");
  focusLbl.style.cssText = "font-size:12px;color:#94a3b8;min-width:80px;display:inline-block";
  focusLbl.textContent = _getFocusLbl(ctx.state._overviewIsoFocusIdx);

  const focusSlider = document.createElement("input");
  focusSlider.type = "range"; focusSlider.min = "0"; focusSlider.max = String(_isoPos.length-1);
  focusSlider.style.cssText = "width:130px;accent-color:#52b788;vertical-align:middle;cursor:pointer";
  focusSlider.value = String(ctx.state._overviewIsoFocusIdx);
  focusSlider.addEventListener("input", ()=>{
    ctx.state._overviewIsoFocusIdx = parseInt(focusSlider.value, 10);
    focusZ = _isoPos[Math.max(0, Math.min(ctx.state._overviewIsoFocusIdx, _isoPos.length-1))];
    focusLbl.textContent = _getFocusLbl(ctx.state._overviewIsoFocusIdx);
    _rebuildRoomPositions();
    _renderFrame();
  });
  isoCtrlRow.appendChild(focusSlider);
  isoCtrlRow.appendChild(focusLbl);

  // Spacing slider
  const ovSpacingLbl = document.createElement("span");
  ovSpacingLbl.style.cssText = "font-size:12px;color:#94a3b8;margin-left:8px";
  ovSpacingLbl.textContent = "Spacing:";
  isoCtrlRow.appendChild(ovSpacingLbl);

  const ovGapLbl = document.createElement("span");
  ovGapLbl.style.cssText = "font-size:12px;color:#94a3b8;min-width:36px;display:inline-block;text-align:right";
  ovGapLbl.textContent = String(ctx.state._overviewFloorGap);
  const ovGapSlider = document.createElement("input");
  ovGapSlider.type="range"; ovGapSlider.min="60"; ovGapSlider.max="340"; ovGapSlider.step="10";
  ovGapSlider.style.cssText = "width:110px;accent-color:#52b788;vertical-align:middle;cursor:pointer";
  ovGapSlider.value = String(ctx.state._overviewFloorGap);
  ovGapSlider.addEventListener("input",()=>{
    ctx.state._overviewFloorGap = parseInt(ovGapSlider.value, 10);
    _ovFG = ctx.state._overviewFloorGap;
    ovGapLbl.textContent = String(ctx.state._overviewFloorGap);
    _rebuildRoomPositions();
    _renderFrame();
  });
  isoCtrlRow.appendChild(ovGapSlider);
  isoCtrlRow.appendChild(ovGapLbl);

  // L/R horizontal offset slider
  const ovLRLbl = document.createElement("span");
  ovLRLbl.style.cssText = "font-size:12px;color:#94a3b8;margin-left:8px";
  ovLRLbl.textContent = "L/R:";
  isoCtrlRow.appendChild(ovLRLbl);

  const ovHorizLbl = document.createElement("span");
  ovHorizLbl.style.cssText = "font-size:12px;color:#94a3b8;min-width:36px;display:inline-block;text-align:right";
  ovHorizLbl.textContent = String(ctx.state._overviewHorizGap);
  const ovHorizSlider = document.createElement("input");
  ovHorizSlider.type="range"; ovHorizSlider.min="-120"; ovHorizSlider.max="120"; ovHorizSlider.step="10";
  ovHorizSlider.style.cssText = "width:110px;accent-color:#52b788;vertical-align:middle;cursor:pointer";
  ovHorizSlider.value = String(ctx.state._overviewHorizGap);
  ovHorizSlider.addEventListener("input",()=>{
    ctx.state._overviewHorizGap = parseInt(ovHorizSlider.value, 10);
    _ovHG = ctx.state._overviewHorizGap;
    ovHorizLbl.textContent = String(ctx.state._overviewHorizGap);
    _rebuildRoomPositions();
    _renderFrame();
  });
  isoCtrlRow.appendChild(ovHorizSlider);
  isoCtrlRow.appendChild(ovHorizLbl);

  // Save button
  const ovSaveLbl = document.createElement("span");
  ovSaveLbl.style.cssText = "font-size:11px;color:#94a3b8;min-width:50px";
  const ovSaveBtn = document.createElement("button");
  ovSaveBtn.className = "btn inline";
  ovSaveBtn.style.cssText = "padding:2px 10px;font-size:12px";
  ovSaveBtn.title = "Save these slider positions so both Overview and Traceback use the same layout";
  ovSaveBtn.textContent = "Save";
  ovSaveBtn.addEventListener("click", async ()=>{
    ovSaveBtn.disabled = true;
    try{
      await ctx.actions.settingsSet({
        overview_iso_floor_gap: ctx.state._overviewFloorGap,
        overview_iso_horiz_gap: ctx.state._overviewHorizGap,
        overview_iso_focus:     ctx.state._overviewIsoFocusIdx,
      });
      ovSaveLbl.textContent = "Saved \u2713";
      setTimeout(()=>{ ovSaveLbl.textContent = ""; }, 2000);
    }catch(e){ ovSaveLbl.textContent = "Error"; }
    ovSaveBtn.disabled = false;
  });

  // Reset button
  const ovResetBtn = document.createElement("button");
  ovResetBtn.className = "btn inline";
  ovResetBtn.style.cssText = "padding:2px 10px;font-size:12px";
  ovResetBtn.title = "Reset sliders to default values";
  ovResetBtn.textContent = "Reset";
  ovResetBtn.addEventListener("click", async ()=>{
    ctx.state._overviewFloorGap = 150; _ovFG = 150;
    ctx.state._overviewHorizGap = 0;   _ovHG = 0;
    ctx.state._overviewIsoFocusIdx = 0;
    focusZ = _isoPos[0];
    ovGapSlider.value   = "150"; ovGapLbl.textContent   = "150";
    ovHorizSlider.value = "0";   ovHorizLbl.textContent = "0";
    focusSlider.value   = "0";   focusLbl.textContent   = "All floors";
    _rebuildRoomPositions();
    _renderFrame();
    ovResetBtn.disabled = true;
    try{
      await ctx.actions.settingsSet({ overview_iso_floor_gap:150, overview_iso_horiz_gap:0, overview_iso_focus:0 });
      ovSaveLbl.textContent = "Reset \u2713";
      setTimeout(()=>{ ovSaveLbl.textContent = ""; }, 2000);
    }catch(e){ ovSaveLbl.textContent = "Error"; }
    ovResetBtn.disabled = false;
  });
  isoCtrlRow.appendChild(ovSaveBtn);
  isoCtrlRow.appendChild(ovResetBtn);
  isoCtrlRow.appendChild(ovSaveLbl);

  // ── Discovery controls card ───────────────────────────────────────────
  const discoCard = document.createElement("div");
  discoCard.className = "card";
  discoCard.style.cssText = "border-color:#7c3aed;background:#0f000f";

  function _renderDiscoMap() {
    mapDiv.innerHTML = _buildDiscoverySVG(tb.discoResults);
    // Attach click handlers via event delegation
    mapDiv.addEventListener("click", _discoMapClick);
  }

  function _discoMapClick(e) {
    let node = e.target;
    while (node && node !== mapDiv) {
      if (node.tagName === "g" || node.tagName === "G") {
        const idx = node.getAttribute("data-disco");
        if (idx !== null) {
          const obj = tb.discoResults[parseInt(idx, 10)];
          if (obj) {
            tb.discoSelected = obj.key || obj.address;
            ctx.actions.showObjectDetail(obj);
            _renderDiscoMap();
          }
          return;
        }
      }
      node = node.parentNode;
    }
  }

  function _buildDiscoControls() {
    discoCard.innerHTML = "";

    // Header
    const hdr = document.createElement("div");
    hdr.style.cssText = "display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap";
    const title = document.createElement("span");
    title.style.cssText = "font-weight:700;font-size:15px;color:#e879f9";
    title.textContent = "New Objects Heard";
    hdr.appendChild(title);
    const desc = document.createElement("span");
    desc.style.cssText = "font-size:11px;color:#94a3b8";
    desc.textContent = "Find objects first discovered in a time window";
    hdr.appendChild(desc);
    discoCard.appendChild(hdr);

    // Time range inputs
    const rangeRow = document.createElement("div");
    rangeRow.style.cssText = "display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px";

    const fromLbl = document.createElement("span");
    fromLbl.style.cssText = "font-size:12px;color:#94a3b8";
    fromLbl.textContent = "From";
    rangeRow.appendChild(fromLbl);

    const fromInput = document.createElement("input");
    fromInput.type = "number";
    fromInput.min = "0";
    fromInput.max = "10080"; // 7 days in minutes
    fromInput.value = String(tb.discoFromMin);
    fromInput.style.cssText = "width:70px;background:#071008;color:#e2e8f0;border:1px solid #7c3aed;border-radius:4px;padding:4px 6px;font-size:13px;text-align:center";
    fromInput.addEventListener("change", () => { tb.discoFromMin = Math.max(0, parseInt(fromInput.value, 10) || 0); });
    rangeRow.appendChild(fromInput);

    const fromUnit = document.createElement("span");
    fromUnit.style.cssText = "font-size:12px;color:#94a3b8";
    fromUnit.textContent = "min ago";
    rangeRow.appendChild(fromUnit);

    const toLbl = document.createElement("span");
    toLbl.style.cssText = "font-size:12px;color:#94a3b8;margin-left:6px";
    toLbl.textContent = "to";
    rangeRow.appendChild(toLbl);

    const toInput = document.createElement("input");
    toInput.type = "number";
    toInput.min = "0";
    toInput.max = "10080";
    toInput.value = String(tb.discoToMin);
    toInput.style.cssText = "width:70px;background:#071008;color:#e2e8f0;border:1px solid #7c3aed;border-radius:4px;padding:4px 6px;font-size:13px;text-align:center";
    toInput.addEventListener("change", () => { tb.discoToMin = Math.max(0, parseInt(toInput.value, 10) || 0); });
    rangeRow.appendChild(toInput);

    const toUnit = document.createElement("span");
    toUnit.style.cssText = "font-size:12px;color:#94a3b8";
    toUnit.textContent = "min ago";
    rangeRow.appendChild(toUnit);

    // Search button
    const searchBtn = document.createElement("button");
    searchBtn.className = "btn inline";
    searchBtn.style.cssText = "margin-left:8px;padding:4px 16px;font-size:12px;font-weight:600;background:#2d1854;border-color:#7c3aed;color:#e879f9";
    searchBtn.textContent = "Search";
    searchBtn.addEventListener("click", () => {
      tb.discoFromMin = Math.max(0, parseInt(fromInput.value, 10) || 0);
      tb.discoToMin = Math.max(0, parseInt(toInput.value, 10) || 0);
      _runDiscoverySearch();
      _buildDiscoControls();
      _renderDiscoMap();
    });
    rangeRow.appendChild(searchBtn);

    discoCard.appendChild(rangeRow);

    // Quick presets
    const presetRow = document.createElement("div");
    presetRow.style.cssText = "display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:12px";
    const presetLbl = document.createElement("span");
    presetLbl.style.cssText = "font-size:11px;color:#64748b";
    presetLbl.textContent = "Quick:";
    presetRow.appendChild(presetLbl);

    const presets = [
      { label: "Last 5 min", from: 5, to: 0 },
      { label: "Last 15 min", from: 15, to: 0 },
      { label: "Last 30 min", from: 30, to: 0 },
      { label: "Last 1 hr", from: 60, to: 0 },
      { label: "Last 4 hr", from: 240, to: 0 },
      { label: "30-60 min ago", from: 60, to: 30 },
      { label: "1-2 hr ago", from: 120, to: 60 },
      { label: "2-4 hr ago", from: 240, to: 120 },
    ];
    for (const p of presets) {
      const btn = document.createElement("button");
      btn.className = "btn inline";
      const isActive = tb.discoFromMin === p.from && tb.discoToMin === p.to;
      btn.style.cssText = isActive
        ? "font-size:10px;padding:2px 8px;background:#7c3aed;color:#fff;border-color:#e879f9;font-weight:700"
        : "font-size:10px;padding:2px 8px;color:#94a3b8";
      btn.textContent = p.label;
      btn.addEventListener("click", () => {
        tb.discoFromMin = p.from;
        tb.discoToMin = p.to;
        fromInput.value = String(p.from);
        toInput.value = String(p.to);
        _runDiscoverySearch();
        _buildDiscoControls();
        _renderDiscoMap();
      });
      presetRow.appendChild(btn);
    }
    discoCard.appendChild(presetRow);

    // Results
    if (!tb.discoResults.length) {
      const empty = document.createElement("div");
      empty.style.cssText = "text-align:center;padding:16px;color:#64748b;font-size:13px";
      empty.textContent = "No new objects discovered in this time window. Try a wider range or check that objects are within scanner range.";
      discoCard.appendChild(empty);
      return;
    }

    // Results summary
    const summRow = document.createElement("div");
    summRow.style.cssText = "display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap";
    const summLbl = document.createElement("span");
    summLbl.style.cssText = "font-size:13px;font-weight:600;color:#e879f9";
    summLbl.textContent = `${tb.discoResults.length} object${tb.discoResults.length !== 1 ? "s" : ""} found`;
    summRow.appendChild(summLbl);
    // Kind breakdown
    const kindCounts = {};
    for (const o of tb.discoResults) { kindCounts[o.kind || "ble"] = (kindCounts[o.kind || "ble"] || 0) + 1; }
    const kindStr = Object.entries(kindCounts).map(([k, v]) => `${v} ${k}`).join(", ");
    const kindLbl = document.createElement("span");
    kindLbl.style.cssText = "font-size:11px;color:#94a3b8";
    kindLbl.textContent = "(" + kindStr + ")";
    summRow.appendChild(kindLbl);
    discoCard.appendChild(summRow);

    // Results table
    const table = document.createElement("div");
    table.style.cssText = "max-height:300px;overflow-y:auto;border:1px solid #2d1854;border-radius:6px";

    const tbl = document.createElement("table");
    tbl.className = "table";
    tbl.style.cssText = "width:100%;font-size:12px";
    const thead = document.createElement("thead");
    thead.innerHTML = `<tr><th style="width:50px">Kind</th><th>Name / Address</th><th>Room</th><th>First Seen</th><th>RSSI</th><th>Source</th></tr>`;
    tbl.appendChild(thead);

    const tbody = document.createElement("tbody");
    const DISCO_COLORS = ["#e879f9", "#60a5fa", "#f87171", "#34d399", "#fbbf24", "#fb923c", "#5eead4", "#f472b6", "#a3e635", "#818cf8"];
    for (let i = 0; i < tb.discoResults.length; i++) {
      const obj = tb.discoResults[i];
      const col = DISCO_COLORS[i % DISCO_COLORS.length];
      const isSelected = tb.discoSelected === (obj.key || obj.address);
      const tr = document.createElement("tr");
      tr.style.cssText = "cursor:pointer;" + (isSelected ? "background:#1a0a2e;" : "") + "border-bottom:1px solid #1a0a2e";
      tr.addEventListener("click", () => {
        tb.discoSelected = obj.key || obj.address;
        ctx.actions.showObjectDetail(obj);
        _renderDiscoMap();
        // Re-highlight in table
        for (const row of tbody.children) {
          row.style.background = "";
        }
        tr.style.background = "#1a0a2e";
      });
      // Hover
      tr.addEventListener("mouseenter", () => { if (!isSelected) tr.style.background = "#0f051f"; });
      tr.addEventListener("mouseleave", () => { if (tb.discoSelected !== (obj.key || obj.address)) tr.style.background = ""; });

      // Kind
      const kindTd = document.createElement("td");
      const kindBadge = document.createElement("span");
      kindBadge.style.cssText = "font-size:9px;padding:1px 5px;border-radius:3px;font-weight:600;" +
        "background:" + col + "22;color:" + col + ";border:1px solid " + col + "44";
      kindBadge.textContent = obj.kind === "ibeacon" ? "iBeacon" : obj.kind === "private_ble" ? "pBLE" : obj.kind === "entity" ? "Entity" : "BLE";
      kindTd.appendChild(kindBadge);
      tr.appendChild(kindTd);

      // Name/Address
      const nameTd = document.createElement("td");
      nameTd.style.cssText = "max-width:200px;overflow:hidden;text-overflow:ellipsis";
      const nameMain = document.createElement("div");
      nameMain.style.cssText = "font-weight:600;color:" + col;
      nameMain.textContent = obj.user_label || obj.name || obj.address || "?";
      nameTd.appendChild(nameMain);
      if (obj.address && obj.address !== (obj.user_label || obj.name)) {
        const addrSub = document.createElement("div");
        addrSub.style.cssText = "font-size:10px;color:#64748b;font-family:monospace";
        addrSub.textContent = obj.address;
        nameTd.appendChild(addrSub);
      }
      if (obj.company_name) {
        const compSub = document.createElement("div");
        compSub.style.cssText = "font-size:10px;color:#94a3b8";
        compSub.textContent = obj.company_name;
        nameTd.appendChild(compSub);
      }
      tr.appendChild(nameTd);

      // Room
      const roomTd = document.createElement("td");
      roomTd.style.cssText = "color:" + (obj.room ? roomColorFn(obj.room) : "#64748b");
      roomTd.textContent = obj.room || "—";
      tr.appendChild(roomTd);

      // First Seen
      const fsTd = document.createElement("td");
      fsTd.style.cssText = "font-size:11px;white-space:nowrap";
      if (obj.first_seen) {
        const fsDate = new Date(obj.first_seen);
        const agoMs = Date.now() - fsDate.getTime();
        const agoMin = Math.round(agoMs / 60000);
        fsTd.textContent = agoMin < 1 ? "just now" : agoMin < 60 ? `${agoMin}m ago` : `${(agoMin / 60).toFixed(1)}h ago`;
        fsTd.title = fsDate.toLocaleString();
      } else {
        fsTd.textContent = "—";
      }
      tr.appendChild(fsTd);

      // RSSI
      const rssiTd = document.createElement("td");
      rssiTd.style.cssText = "font-family:monospace;font-size:11px";
      rssiTd.textContent = obj.rssi != null ? `${obj.rssi}` : "—";
      tr.appendChild(rssiTd);

      // Source scanner
      const srcTd = document.createElement("td");
      srcTd.style.cssText = "font-size:11px;max-width:120px;overflow:hidden;text-overflow:ellipsis";
      const sources = obj.sources || [];
      if (sources.length) {
        const srcName = typeof sources[0] === "string" ? sources[0] : (sources[0].source || "");
        // Try to find friendly name from radios
        const radio = radios.find(r => r.source === srcName);
        srcTd.textContent = radio?.name || srcName || "—";
        if (sources.length > 1) srcTd.textContent += ` +${sources.length - 1}`;
      } else {
        srcTd.textContent = obj.source || "—";
      }
      tr.appendChild(srcTd);

      tbody.appendChild(tr);
    }
    tbl.appendChild(tbody);
    table.appendChild(tbl);
    discoCard.appendChild(table);

    // Tip
    const tip = document.createElement("div");
    tip.style.cssText = "font-size:10px;color:#64748b;margin-top:8px";
    tip.textContent = "Click any row or map pin to view full object details (manufacturer data, services, signal sources, etc.)";
    discoCard.appendChild(tip);
  }

  // ── Mode toggle ─────────────────────────────────────────────────────────
  const modeRow = document.createElement("div");
  modeRow.style.cssText = "display:flex;align-items:center;gap:4px;margin-bottom:8px";

  const _makeModeBtn = (label, mode, color) => {
    const btn = document.createElement("button");
    btn.className = "btn inline";
    const isActive = tb.mode === mode;
    btn.style.cssText = isActive
      ? `font-size:12px;padding:4px 14px;font-weight:700;background:${color}22;color:${color};border-color:${color}`
      : "font-size:12px;padding:4px 14px;color:#94a3b8;border-color:#1b3526";
    btn.textContent = label;
    btn.addEventListener("click", () => {
      tb.mode = mode;
      _stopPlayback();
      // Show/hide the right controls card
      ctrlCard.style.display = mode === "playback" ? "" : "none";
      discoCard.style.display = mode === "discovery" ? "" : "none";
      // Update mode button styles
      for (const c of modeRow.children) {
        const m = c.getAttribute("data-mode");
        if (m === mode) {
          const mCol = m === "playback" ? "#fbbf24" : "#e879f9";
          c.style.cssText = `font-size:12px;padding:4px 14px;font-weight:700;background:${mCol}22;color:${mCol};border-color:${mCol}`;
        } else {
          c.style.cssText = "font-size:12px;padding:4px 14px;color:#94a3b8;border-color:#1b3526";
        }
      }
      // Re-render map for current mode
      if (mode === "playback") {
        _renderFrame();
      } else {
        _runDiscoverySearch();
        _buildDiscoControls();
        _renderDiscoMap();
      }
    });
    btn.setAttribute("data-mode", mode);
    return btn;
  };

  modeRow.appendChild(_makeModeBtn("Playback", "playback", "#fbbf24"));
  modeRow.appendChild(_makeModeBtn("New Objects", "discovery", "#e879f9"));

  // ── Assemble ───────────────────────────────────────────────────────────
  outer.appendChild(modeRow);
  outer.appendChild(isoCtrlRow);
  outer.appendChild(mapDiv);

  // Both cards are appended but only the active mode's card is visible
  ctrlCard.style.display = tb.mode === "playback" ? "" : "none";
  discoCard.style.display = tb.mode === "discovery" ? "" : "none";
  outer.appendChild(ctrlCard);
  outer.appendChild(discoCard);

  // Mark traceback as active to suppress poll re-renders (panel.js checks this)
  tb.active = true;

  // Auto-load data on tab open
  if (tb.mode === "playback") {
    _loadTracebackData().then(() => {
      _buildControls();
      _renderFrame();
    });
  } else {
    _runDiscoverySearch();
    _buildDiscoControls();
    _renderDiscoMap();
  }

  return outer;
}
