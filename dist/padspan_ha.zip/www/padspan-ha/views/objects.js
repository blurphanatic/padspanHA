export function renderTags(ctx, tagsList) {
  const { el } = ctx.helpers;
  const { mode, tagFilter } = ctx.state;

  const isLive = ctx.state.dataMode === "live";
  const roomTagMap = ctx.state.roomTagMap || {};
  const snap = (ctx.state.live && ctx.state.live.snapshot) || null;
  const missingByRoom =
    ctx.state.missingRoomTagMap ||
    (snap && snap.room_tag_map_missing) ||
    {};

  // Index live snapshot tags so we can show friendly names + state (not just entity_id).
  const liveTags = ((snap && snap.tags) || []);
  const liveIndex = {};
  const liveMissingIndex = {};
  for (const t of liveTags) {
    if (!t || !t.entity_id) continue;
    const eid = String(t.entity_id);
    if (t.missing) liveMissingIndex[eid] = t;
    else liveIndex[eid] = t;
  }

  const rooms = Object.keys(roomTagMap);

  // Ensure selectedRooms is always valid.
  if (!ctx.state.selectedRooms || !Array.isArray(ctx.state.selectedRooms)) ctx.state.selectedRooms = rooms.slice(0, 1);
  if (ctx.state.selectedRooms.length === 0 && rooms.length) ctx.state.selectedRooms = [rooms[0]];

  tagsList.innerHTML = "";

  // Selected tags
  const selectedRooms = (ctx.state.selectedRooms || []).filter(r => rooms.includes(r));
  const sets = selectedRooms.map(r => new Set(roomTagMap[r] || []));

  const union = new Set();
  for (const s of sets) for (const v of s) union.add(v);

  const intersect = new Set(union);
  for (const s of sets) for (const v of Array.from(intersect)) if (!s.has(v)) intersect.delete(v);

  let items = [];
  if (mode === "union") items = Array.from(union);
  else if (mode === "intersect") items = Array.from(intersect);
  else items = Array.from(union);

  // Optional filter
  if (tagFilter && tagFilter.trim()) {
    const q = tagFilter.trim().toLowerCase();
    items = items.filter(eid => {
      const meta = liveIndex[eid];
      return eid.toLowerCase().includes(q) || (meta && String(meta.name || "").toLowerCase().includes(q));
    });
  }

  const list = el("div", { class: "list" });

  // Empty state guidance (common when only placeholders exist).
  if (items.length === 0) {
    const missingTotal = Object.values(missingByRoom).reduce((a, v) => a + (Array.isArray(v) ? v.length : 0), 0);
    list.appendChild(
      el("div", { class: "muted", style: "padding:8px 4px" },
        missingTotal
          ? `No tags found. (${missingTotal} configured tags are missing in Home Assistant.)`
          : isLive
            ? "No tags found. Confirm your BLE integration creates entities whose state equals a room/area (e.g., *area_last_seen)."
            : "No tags mapped for the selected room(s)."
      )
    );
  }

  // Render each tag
  for (const eid of items) {
    const meta = liveIndex[eid] || null;
    const item = el("div", { class: "item" });

    const textWrap = el("div", { style: "display:flex;flex-direction:column;gap:2px;flex:1" });
    textWrap.appendChild(el("span", {}, meta ? String(meta.name || eid) : eid));

    if (meta) {
      const details = [];
      details.push(eid);
      if (meta.state !== undefined) details.push(String(meta.state));
      if (meta.nearest_receiver) details.push(`rx:${meta.nearest_receiver}`);
      textWrap.appendChild(el("span", { class: "muted" }, details.join(" • ")));
    } else {
      textWrap.appendChild(el("span", { class: "muted" }, eid));
    }

    item.appendChild(textWrap);

    // "open in HA" button
    const openBtn = el("button", { class: "btn tiny" }, "Open");
    openBtn.addEventListener("click", () => {
      const url = `/developer-tools/state?entity_id=${encodeURIComponent(eid)}`;
      window.open(url, "_blank");
    });
    item.appendChild(openBtn);

    list.appendChild(item);
  }

  // If there are missing configured tags for selected rooms, show them underneath (collapsed-ish).
  const missingForSelected = [];
  for (const r of selectedRooms) for (const eid of (missingByRoom[r] || [])) missingForSelected.push({ room: r, eid });
  if (isLive && missingForSelected.length) {
    list.appendChild(el("div", { class: "muted", style: "padding:10px 4px 4px" }, "Configured (missing in Home Assistant):"));
    for (const x of missingForSelected.slice(0, 200)) {
      const item = el("div", { class: "item" });
      const tw = el("div", { style: "display:flex;flex-direction:column;gap:2px;flex:1" });
      tw.appendChild(el("span", {}, x.eid));
      tw.appendChild(el("span", { class: "muted" }, `room: ${x.room}`));
      item.appendChild(tw);
      list.appendChild(item);
    }
  }

  tagsList.appendChild(list);
}

export function render(ctx){
  const { el, esc, roomColor } = ctx.helpers;
  const { roomTagMap, mode, tagFilter } = ctx.state;
  const selectedRooms = new Set(Array.isArray(ctx.state.selectedRooms) ? ctx.state.selectedRooms : []);

  const root = el("section",{id:"objects"});
  root.className = ctx.state.view==="objects" ? "" : "hidden";

  // ----------------------------
  // Inventory: unified Objects model (BLE advertisements + mapped entities)
  // ----------------------------
  const isLive = ctx.state.dataMode === "live";
  const liveSnap = (ctx.state.live && ctx.state.live.snapshot) || null;
  const objModel = liveSnap && liveSnap.objects ? liveSnap.objects : null;

  const fmtAgo = (age_s)=>{
    const s = Number(age_s);
    if(!isFinite(s)) return "—";
    if(s < 1) return "<1s";
    if(s < 60) return `${Math.round(s)}s`;
    const m = Math.floor(s/60);
    const rs = Math.round(s - m*60);
    if(m < 60) return `${m}m ${rs}s`;
    const h = Math.floor(m/60);
    const rm = m - h*60;
    return `${h}h ${rm}m`;
  };
  const fmtNum = (n)=>{
    const v = Number(n);
    if(!isFinite(v)) return "0";
    return v.toLocaleString();
  };

  // --- Inline objects list (BLE scanner detections + entities) ---
  const allObjects = objModel && Array.isArray(objModel.list) ? objModel.list : [];
  const summary = objModel && objModel.summary ? objModel.summary : null;

  if (!ctx.state.objSearch) ctx.state.objSearch = "";
  if (!ctx.state.objKind)   ctx.state.objKind   = "all";
  if (!ctx.state.objStatus) ctx.state.objStatus  = "all";

  const objSearchInput = el("input",{type:"text", placeholder:"Search address, name, label…", value: ctx.state.objSearch});
  const objKindSel = el("select",{class:"btn"});
  [{v:"all",t:"All"},{v:"ble",t:"BLE devices"},{v:"entity",t:"HA entities"}]
    .forEach(o=>objKindSel.appendChild(el("option",{value:o.v},o.t)));
  objKindSel.value = ctx.state.objKind;

  const objStatusSel = el("select",{class:"btn"});
  [{v:"all",t:"All statuses"},{v:"unidentified",t:"Unidentified"},{v:"identified",t:"Identified"}]
    .forEach(o=>objStatusSel.appendChild(el("option",{value:o.v},o.t)));
  objStatusSel.value = ctx.state.objStatus;

  const objStats = el("span",{class:"muted"});

  const objTbody = el("tbody",{});
  const objTable = el("table",{class:"table"},[
    el("thead",{}, el("tr",{},[
      el("th",{},"Kind"),
      el("th",{},"Name / Address"),
      el("th",{},"Signal"),
      el("th",{},"Last seen"),
      el("th",{},"Scanner"),
      el("th",{},"Tag"),
    ])),
    objTbody,
  ]);

  const objRowEls = allObjects.map(o=>{
    const kind = o.kind || "";
    const identified = !!o.identified;
    const addr = o.address || "";
    const userLabel = o.user_label || "";
    const displayName = userLabel || o.name || o.entity_id || addr || "—";
    const rssi = o.rssi != null ? `${o.rssi} dBm` : "";
    const age = o.age_s != null ? fmtAgo(o.age_s) : "";
    const scanner = kind==="ble" && Array.isArray(o.sources) && o.sources.length
      ? o.sources.join(", ") : (o.room || "");

    const tagCell = (() => {
      if (kind !== "ble" || !addr) return el("td",{}, "");
      const btn = el("button",{class:"btn tiny"}, userLabel ? "Relabel" : "Tag");
      btn.addEventListener("click",(e)=>{ e.stopPropagation(); ctx.actions.tagObjectPrompt(addr, userLabel); });
      return el("td",{}, btn);
    })();

    const tr = el("tr",{
      "data-kind": kind,
      "data-identified": identified ? "1" : "0",
      "data-search": `${kind} ${displayName} ${addr} ${userLabel} ${o.entity_id||""} ${scanner}`.toLowerCase(),
    },[
      el("td",{}, [
        el("span",{class:"badge"+(identified?"":" warn")}, kind==="ble" ? (identified?"BLE":"BLE?") : "Entity"),
      ]),
      el("td",{}, [
        el("div",{style:"font-weight:600"}, displayName),
        (addr && addr !== displayName ? el("div",{class:"muted",style:"font-size:11px"}, addr) : null),
        (o.entity_id && !userLabel ? el("div",{class:"muted",style:"font-size:11px"}, o.entity_id) : null),
        (kind==="ble" && o.manufacturer_data && Object.keys(o.manufacturer_data).length
          ? el("div",{class:"muted",style:"font-size:11px"}, `Apple/Manuf: ${Object.keys(o.manufacturer_data).slice(0,2).join(", ")}`) : null),
      ].filter(Boolean)),
      el("td",{}, rssi ? el("span",{class:"badge"}, rssi) : "—"),
      el("td",{}, age || "—"),
      el("td",{class:"muted",style:"font-size:11px;max-width:160px;overflow:hidden;text-overflow:ellipsis"}, scanner || "—"),
      tagCell,
    ]);
    objTbody.appendChild(tr);
    return tr;
  });

  function applyObjFilter(){
    const q = String(ctx.state.objSearch||"").toLowerCase();
    const k = ctx.state.objKind || "all";
    const s = ctx.state.objStatus || "all";
    let shown = 0;
    for(const tr of objRowEls){
      const kind = tr.getAttribute("data-kind");
      const ident = tr.getAttribute("data-identified")==="1";
      const hay = tr.getAttribute("data-search")||"";
      let ok = true;
      if(k !== "all" && kind !== k) ok = false;
      if(s === "identified" && !ident) ok = false;
      if(s === "unidentified" && ident) ok = false;
      if(q && !hay.includes(q)) ok = false;
      tr.style.display = ok ? "" : "none";
      if(ok) shown++;
    }
    objStats.textContent = `${shown} shown`;
  }

  objSearchInput.addEventListener("input",  ()=>{ ctx.state.objSearch = objSearchInput.value; applyObjFilter(); });
  objKindSel.addEventListener("change",     ()=>{ ctx.state.objKind   = objKindSel.value;     applyObjFilter(); });
  objStatusSel.addEventListener("change",   ()=>{ ctx.state.objStatus = objStatusSel.value;   applyObjFilter(); });
  applyObjFilter();

  const inventorySection = el("div",{class:"card"},[
    el("div",{class:"row",style:"margin-bottom:8px"},[
      el("div",{class:"h2",style:"flex:1"},"BLE Scanner Detections"),
      summary ? el("span",{class:"badge"}, `${summary.ble||0} BLE`) : null,
      summary ? el("span",{class:"badge warn"}, `${summary.unidentified||0} unidentified`) : null,
      summary ? el("span",{class:"badge"}, `${summary.entities||0} entities`) : null,
    ].filter(Boolean)),
    el("div",{class:"toolbar"},[objSearchInput, objKindSel, objStatusSel, objStats]),
    allObjects.length
      ? objTable
      : el("div",{class:"muted"}, isLive ? "Waiting for scanner data…" : "Switch to Live mode to see real BLE detections."),
  ]);
  root.appendChild(inventorySection);


  const roomsList = el("div",{class:"rooms", id:"rooms"});
  const tagsList = el("div",{class:"tags", id:"tags"});

  const rooms = (() => {
    const disc = liveSnap && liveSnap.rooms_discovered;
    if (disc && disc.length) return [...disc].sort((a,b)=>a.localeCompare(b));
    return Object.keys(roomTagMap||{}).sort((a,b)=>a.localeCompare(b));
  })();
  // Ensure at least one room selected so tags list has context.
  if (selectedRooms.size === 0 && rooms.length) { selectedRooms.add(rooms[0]); ctx.state.selectedRooms = Array.from(selectedRooms); }
  if(!rooms.length){
    roomsList.appendChild(el("div",{class:"item"},"No room data yet."));
  } else {
    for(const room of rooms){
      const count = (roomTagMap[room]||[]).length;
      const row = el("label",{class:"item"});
      const cb = el("input",{type:"checkbox"});
      cb.checked = selectedRooms.has(room);
      cb.addEventListener("change", ()=>{ cb.checked ? selectedRooms.add(room) : selectedRooms.delete(room); ctx.state.selectedRooms = Array.from(selectedRooms); ctx.actions.renderTags(); });
      row.appendChild(cb);
      row.appendChild(el("span",{class:"roomdot", style:`background:${roomColor(room)}`}, ""));
      row.appendChild(el("span",{}, esc(room)));
      row.appendChild(el("span",{class:"muted"}, `(${count})`));
      roomsList.appendChild(row);
    }
  }

  const toolbarLeft = el("div",{class:"toolbar"},[
    el("button",{class:"btn", onclick:()=>{ rooms.forEach(r=>selectedRooms.add(r)); ctx.state.selectedRooms = Array.from(selectedRooms); ctx.state._roomsInit = true; ctx.actions.renderRooms(); ctx.actions.renderTags(); }},"All Rooms"),
    el("button",{class:"btn", onclick:()=>{ selectedRooms.clear(); ctx.state.selectedRooms = []; ctx.state._roomsInit = true; ctx.actions.renderRooms(); ctx.actions.renderTags(); }},"Clear"),
  ]);

  const modeSel = el("select",{class:"btn", id:"modeSel"});
  modeSel.style.maxWidth="420px";
  const optAll = el("option",{value:"all"},"Show tags in ALL selected rooms (intersection)");
  const optAny = el("option",{value:"any"},"Show tags in ANY selected room (union)");
  modeSel.appendChild(optAll); modeSel.appendChild(optAny);
  modeSel.value = mode;
  modeSel.addEventListener("change", ()=>{ ctx.state.mode = modeSel.value; ctx.actions.renderTags(); });

  const filter = el("input",{type:"text", id:"tagFilter", placeholder:"Filter tags… (e.g., keys)"});
  filter.value = tagFilter;
  filter.addEventListener("input", ()=>{ ctx.state.tagFilter = filter.value; ctx.actions.renderTags(); });

  const toolbarRight = el("div",{class:"toolbar"},[modeSel, filter]);

  const leftCard = el("div",{class:"card"},[
    el("div",{class:"h2"},"Room Presence Mapping"),
    el("div",{class:"muted",style:"margin-bottom:6px"},"Select rooms to see which trackers are assigned to them."),
    toolbarLeft,
    roomsList,
  ]);

  const rightCard = el("div",{class:"card"},[
    el("div",{class:"muted"},"Trackers in selected rooms"),
    toolbarRight,
    tagsList,
  ]);

  const grid = el("div",{class:"grid"},[leftCard,rightCard]);
  root.appendChild(grid);

  renderTags(ctx, tagsList);

  return root;
}
