// PadSpan HA — BLE Room-Presence Tracking for Home Assistant
// Copyright (C) 2026 Garry Broeckling
// Licensed under the GNU General Public License v3.0
// See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
// PadSpan HA — BLE Fingerprint Calibration
// Phone-based signal collection for precise indoor location modelling.
//
// Sub-tabs:
//   Setup       — pick your beacon device, collection settings
//   Pin & Listen — tap map to place pin, collect RSSI for N seconds
//   Roam        — guided coverage-maximising walk with live heatmap
//   Model       — quality stats, path-loss fits, LOO accuracy, export

const GRID_N    = 10;    // 10×10 coverage grid
const SIGMA_C   = 1.8;   // Gaussian sigma in cell units
const POLL_MS   = 1000;  // RSSI poll interval during collection (1s = ~60 samples in 60s)

// ── Exports ──────────────────────────────────────────────────────────────────
export function render(ctx) {
  const { el } = ctx.helpers;
  const root = el("section", { id: "calibration" });
  root.className = ctx.state.view === "calibration" ? "" : "hidden";

  // Per-session UI state
  if (!ctx.state._calib) ctx.state._calib = {
    tab:        "setup",
    deviceId:   null,
    deviceLabel: null,
    mapId:      null,
    duration:   15,
    pinX:       null,
    pinY:       null,
    pinRoom:    null,
    pinLabel:   "",
    collecting: false,
    stopFlag:   false,
    readings:   null,   // {source → {name,samples[]}} after collection
    savedThisSession: 0,
  };
  const cs = ctx.state._calib;

  // Load calibration DB once
  if (!ctx.state.calibration) {
    ctx.actions.calibrationGet()
      .then(d => { ctx.state.calibration = d; ctx.actions.renderRooms(); })
      .catch(() => { ctx.state.calibration = { points: [], model: {} }; });
  }
  const calData = ctx.state.calibration || { points: [], model: {} };

  // Header
  root.appendChild(el("div", { style: "margin-bottom:10px" }, [
    el("div", { style: "font-weight:700;font-size:16px;color:#52b788" }, "BLE Location Calibration"),
    el("div", { style: "font-size:12px;color:#78909c;margin-top:2px" },
      "Build a fingerprint database so PadSpan™ can pinpoint every beacon in 3D space."),
  ]));

  // Tab bar
  const TABS = [["setup","Setup"],["pin","Pin & Listen"],["roam","Roam"],["model","Model"],["tune","Tune"],["beacon","Beacon Tune"]];
  const tabBar = el("div", { class: "tabs", style: "margin-bottom:14px;flex-wrap:wrap;gap:4px" });
  for (const [id, label] of TABS) {
    tabBar.appendChild(el("button", {
      class: "tab" + (cs.tab === id ? " active" : ""),
      onclick: () => { cs.tab = id; ctx.actions.renderRooms(); },
    }, label));
  }
  root.appendChild(tabBar);

  if (cs.tab === "setup") root.appendChild(_setup(ctx, el, cs, calData));
  if (cs.tab === "pin")   root.appendChild(_pinAndListen(ctx, el, cs, calData));
  if (cs.tab === "roam")  root.appendChild(_roam(ctx, el, cs, calData));
  if (cs.tab === "model") root.appendChild(_modelTab(ctx, el, cs, calData));
  if (cs.tab === "tune")  root.appendChild(_tuneTab(ctx, el, cs, calData));
  if (cs.tab === "beacon") root.appendChild(_beaconTuneTab(ctx, el, cs, calData));

  return root;
}

// ── Setup tab ─────────────────────────────────────────────────────────────────
function _setup(ctx, el, cs, calData) {
  const wrap = el("div", { style: "display:flex;flex-direction:column;gap:14px" });
  const snap = (ctx.state.live && ctx.state.live.snapshot) || null;

  // How-it-works explainer
  wrap.appendChild(el("div", { class: "card", style: "border-color:#52b788" }, [
    el("div", { style: "font-weight:700;font-size:14px;margin-bottom:8px;color:#52b788" },
      "How Calibration Works"),
    el("div", { style: "font-size:13px;line-height:1.7;color:#b0c4b1" }, [
      el("div", {}, "1. Your phone broadcasts BLE. The house scanners hear it."),
      el("div", { style: "margin-top:4px" }, "2. You stand at a known spot on the map and tap it."),
      el("div", { style: "margin-top:4px" }, "3. PadSpan records the RSSI fingerprint — which scanners saw you and how strongly."),
      el("div", { style: "margin-top:4px" }, "4. Repeat at 10–20 locations spread across each floor."),
      el("div", { style: "margin-top:4px" }, "5. The Model tab shows location accuracy after enough points are collected."),
    ]),
  ]));

  // Device selector — merge objects.list + raw advertisements so the user can pick ANY BLE device
  const bleObjs = (snap?.objects?.list || [])
    .filter(o => o.kind === "ble" || o.kind === "entity")
    .sort((a, b) => (b.rssi || -100) - (a.rssi || -100));

  // Build unique-address map from raw advertisements (one entry per MAC)
  const adAddrMap = {};
  for (const ad of (snap?.ble?.advertisements || [])) {
    const addr = (ad.address || "").toUpperCase();
    if (!addr) continue;
    if (!adAddrMap[addr]) {
      adAddrMap[addr] = { address: addr, name: ad.name || addr, rssi: ad.rssi };
    } else if ((ad.rssi || -200) > (adAddrMap[addr].rssi || -200)) {
      adAddrMap[addr].rssi = ad.rssi;
    }
  }
  // Only show addresses not already covered by bleObjs
  const knownAddrs = new Set(bleObjs.map(o => (o.address || "").toUpperCase()));
  const adOnlyDevices = Object.values(adAddrMap).filter(d => !knownAddrs.has(d.address));
  adOnlyDevices.sort((a, b) => (b.rssi || -200) - (a.rssi || -200));

  const allDevices = bleObjs.length + adOnlyDevices.length;

  const deviceCard = el("div", { class: "card" });
  deviceCard.appendChild(el("div", { style: "font-weight:700;font-size:14px;margin-bottom:8px" }, "Beacon Device"));
  deviceCard.appendChild(el("div", { class: "muted", style: "font-size:12px;margin-bottom:10px" },
    "Select the phone or tag that will act as your calibration beacon. It must be visible to your scanners (Bluetooth on, HA companion app running)."));

  if (allDevices) {
    const sel = document.createElement("select");
    sel.style.cssText = "width:100%;margin-bottom:10px;";
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = cs.deviceId ? "" : "— choose device —";
    sel.appendChild(placeholder);
    // Tracked objects
    for (const o of bleObjs) {
      const addr = o.address || o.entity_id || "";
      const opt = document.createElement("option");
      opt.value = addr;
      opt.textContent = (o.user_label || o.name || addr) + (o.rssi ? ` (${o.rssi} dBm)` : "");
      if (addr === cs.deviceId) opt.selected = true;
      sel.appendChild(opt);
    }
    // Raw advertisement devices not already in objects.list
    if (adOnlyDevices.length) {
      const grp = document.createElement("optgroup");
      grp.label = "── Raw BLE advertisements ──";
      for (const d of adOnlyDevices) {
        const opt = document.createElement("option");
        opt.value = d.address;
        opt.textContent = (d.name !== d.address ? d.name + "  " : "") + d.address + (d.rssi ? ` (${d.rssi} dBm)` : "");
        if (d.address === (cs.deviceId || "").toUpperCase()) opt.selected = true;
        grp.appendChild(opt);
      }
      sel.appendChild(grp);
    }
    sel.addEventListener("change", () => {
      cs.deviceId = sel.value;
      const obj = bleObjs.find(o => (o.address || o.entity_id || "") === sel.value);
      cs.deviceLabel = obj ? (obj.user_label || obj.name || sel.value) : sel.value;
      ctx.actions.renderRooms();
    });
    deviceCard.appendChild(sel);
  } else {
    deviceCard.appendChild(el("div", { style: "font-size:12px;color:#f59e0b;margin-bottom:10px" },
      "No BLE devices visible in snapshot. Switch to Live mode and ensure Bluetooth is active on your phone."));
  }

  // Manual MAC entry
  const manualRow = el("div", { style: "display:flex;gap:8px;align-items:center;margin-bottom:6px" });
  const macInput = document.createElement("input");
  macInput.type = "text";
  macInput.placeholder = "Or enter MAC / entity_id manually…";
  macInput.style.cssText = "flex:1;font-family:monospace;font-size:12px;";
  macInput.value = cs.deviceId || "";
  const applyBtn = el("button", { class: "btn inline" }, "Use");
  applyBtn.addEventListener("click", () => {
    if (macInput.value.trim()) {
      cs.deviceId = macInput.value.trim();
      cs.deviceLabel = cs.deviceId;
      ctx.actions.renderRooms();
    }
  });
  manualRow.appendChild(macInput);
  manualRow.appendChild(applyBtn);
  deviceCard.appendChild(manualRow);

  // Show selected device live data using advertisements for real per-radio RSSI
  if (cs.deviceId && snap) {
    const { perRadio, targetAddr } = _findBeaconAds(snap, cs.deviceId);
    const radioCount = Object.keys(perRadio).length;
    const obj = (snap?.objects?.list || []).find(o =>
      (o.address || "").toUpperCase() === (targetAddr || cs.deviceId).toUpperCase() ||
      (o.entity_id || "") === cs.deviceId
    );
    if (radioCount > 0) {
      const box = el("div", { style: "background:#0a150e;border:1px solid #1b3526;border-radius:8px;padding:10px;margin-top:6px" });
      box.appendChild(el("div", { style: "font-weight:600;font-size:13px;color:#52b788;margin-bottom:6px" },
        `✓ ${obj?.user_label || obj?.name || cs.deviceId} — seen by ${radioCount} radio${radioCount > 1 ? "s" : ""}`));
      if (obj?.room) box.appendChild(el("div", { style: "font-size:12px;color:#94a3b8;margin-bottom:6px" }, `Room: ${obj.room}`));
      box.appendChild(el("div", { style: "font-size:11px;color:#78909c;margin-bottom:4px" }, "Per-radio RSSI:"));
      const sorted = Object.entries(perRadio).sort((a, b) => (b[1].rssi || -200) - (a[1].rssi || -200));
      for (const [src, info] of sorted) {
        box.appendChild(_rssiRow(el, info.name || src, info.rssi));
      }
      deviceCard.appendChild(box);
    } else {
      deviceCard.appendChild(el("div", {
        style: "font-size:12px;color:#f59e0b;margin-top:6px;padding:8px;background:#0a150e;border-radius:6px"
      }, `⚠ "${cs.deviceId}" not seen in any radio advertisement. Make sure Bluetooth is on and the device is near a scanner.`));
    }
  }
  wrap.appendChild(deviceCard);

  // Map selector
  const maps = ctx.state.maps?.list || [];
  const mapCard = el("div", { class: "card" });
  mapCard.appendChild(el("div", { style: "font-weight:700;font-size:14px;margin-bottom:8px" }, "Floor Map"));
  mapCard.appendChild(el("div", { class: "muted", style: "font-size:12px;margin-bottom:10px" },
    "Select the floor plan you'll be calibrating. You can switch maps at any time."));
  if (maps.length) {
    const mapSel = document.createElement("select");
    mapSel.style.width = "100%";
    const mp0 = document.createElement("option");
    mp0.value = "";
    mp0.textContent = cs.mapId ? "" : "— choose map —";
    mapSel.appendChild(mp0);
    for (const m of maps) {
      const opt = document.createElement("option");
      opt.value = m.id;
      opt.textContent = m.name || m.id;
      if (m.id === cs.mapId) opt.selected = true;
      mapSel.appendChild(opt);
    }
    mapSel.addEventListener("change", () => { cs.mapId = mapSel.value; ctx.actions.renderRooms(); });
    mapCard.appendChild(mapSel);
  } else {
    mapCard.appendChild(el("div", { style: "font-size:12px;color:#f59e0b" },
      "No maps uploaded yet. Upload a floor plan in the Maps tab first."));
  }
  wrap.appendChild(mapCard);

  // Duration setting
  const durCard = el("div", { class: "card" });
  durCard.appendChild(el("div", { style: "font-weight:700;font-size:14px;margin-bottom:8px" }, "Collection Duration"));
  durCard.appendChild(el("div", { class: "muted", style: "font-size:12px;margin-bottom:10px" },
    "How long to sample RSSI at each calibration point. Sampled every 1s — 30s gives ~30 samples, 60s gives ~60. 60s recommended for best accuracy."));
  const durRow = el("div", { style: "display:flex;gap:10px;flex-wrap:wrap" });
  for (const d of [15, 30, 60, 90]) {
    const btn = el("button", {
      class: "btn" + (cs.duration === d ? "" : " inline"),
      style: "min-width:60px",
      onclick: () => { cs.duration = d; ctx.actions.renderRooms(); },
    }, `${d}s`);
    durRow.appendChild(btn);
  }
  durCard.appendChild(durRow);
  wrap.appendChild(durCard);

  // Radio status — show all radios and how many BLE devices each sees
  if (snap) {
    const radios = snap?.ble?.radios || [];
    const radioCard = el("div", { class: "card" });
    radioCard.appendChild(el("div", { style: "font-weight:700;font-size:14px;margin-bottom:6px" }, "Radio Status"));
    if (radios.length) {
      const ads = snap?.ble?.advertisements || [];
      for (const r of radios) {
        const seen = ads.filter(a => a.source === r.source).length;
        const beaconHere = cs.deviceId ? ads.some(a =>
          a.source === r.source &&
          (a.address || "").toUpperCase() === (cs.deviceId || "").toUpperCase()
        ) : false;
        // Prefer area name (room) over raw adapter name
        const displayName = r.area_name || r.area || r.name || r.source || "?";
        const subLabel = (r.area_name || r.area) && r.name && r.name !== r.source ? r.name : "";
        const nameEl = el("div", { style: "flex:1;min-width:80px" }, [
          el("span", { style: "font-size:12px;font-weight:600" }, displayName),
          ...(subLabel ? [el("span", { style: "font-size:10px;color:#78909c;display:block;font-family:monospace" }, subLabel)] : []),
        ]);
        const row = el("div", { style: "display:flex;gap:8px;align-items:center;padding:4px 0;border-bottom:1px solid #0d1f12;flex-wrap:wrap" }, [
          nameEl,
          r.scanning ? el("span", { class: "badge", style: "font-size:10px" }, "scanning") : el("span", { class: "badge warn", style: "font-size:10px" }, "idle"),
          el("span", { class: "muted", style: "font-size:11px;white-space:nowrap" }, `${seen} device${seen !== 1 ? "s" : ""}`),
          beaconHere ? el("span", { style: "font-size:10px;color:#52b788;white-space:nowrap" }, "✓ beacon") : null,
        ].filter(Boolean));
        radioCard.appendChild(row);
      }
    } else {
      radioCard.appendChild(el("div", { class: "muted", style: "font-size:12px" },
        "No radios in snapshot. Switch to Live mode."));
    }
    // Total advertisement count
    const totalAds = (snap?.ble?.advertisements || []).length;
    radioCard.appendChild(el("div", { class: "muted", style: "font-size:11px;margin-top:6px" },
      `${totalAds} total BLE advertisement${totalAds !== 1 ? "s" : ""} in snapshot`));
    wrap.appendChild(radioCard);
  }

  // Readiness check
  const ready = cs.deviceId && cs.mapId;
  const readyCard = el("div", { class: "card", style: `border-color:${ready ? "#52b788" : "#f59e0b"}` }, [
    el("div", { style: `font-weight:700;font-size:14px;margin-bottom:6px;color:${ready ? "#52b788" : "#f59e0b"}` },
      ready ? "✓ Ready to calibrate" : "⚠ Setup incomplete"),
    el("div", { style: "font-size:12px;color:#94a3b8" }, [
      el("span", { style: `color:${cs.deviceId ? "#52b788" : "#f59e0b"}` },
        (cs.deviceId ? "✓" : "✗") + " Beacon device selected"),
      el("br"),
      el("span", { style: `color:${cs.mapId ? "#52b788" : "#f59e0b"}` },
        (cs.mapId ? "✓" : "✗") + " Floor map selected"),
    ]),
    ...(ready ? [
      el("button", {
        class: "btn",
        style: "margin-top:10px;width:100%",
        onclick: () => { cs.tab = "pin"; ctx.actions.renderRooms(); },
      }, "Start Calibrating →"),
    ] : []),
  ]);
  wrap.appendChild(readyCard);

  // Progress summary
  const pts = calData.points || [];
  if (pts.length) {
    const mapIds = [...new Set(pts.map(p => p.map_id))];
    wrap.appendChild(el("div", { class: "card" }, [
      el("div", { style: "font-weight:700;font-size:14px;margin-bottom:6px" }, "Calibration Progress"),
      el("div", { style: "font-size:13px;color:#94a3b8" },
        `${pts.length} point${pts.length > 1 ? "s" : ""} collected across ${mapIds.length} map${mapIds.length > 1 ? "s" : ""}.`),
      el("button", {
        class: "btn inline",
        style: "margin-top:8px",
        onclick: () => { cs.tab = "model"; ctx.actions.renderRooms(); },
      }, "View Model →"),
    ]));
  }

  return wrap;
}

// ── Pin & Listen tab ──────────────────────────────────────────────────────────
function _pinAndListen(ctx, el, cs, calData) {
  const wrap = el("div", { style: "display:flex;flex-direction:column;gap:14px" });

  if (!cs.deviceId || !cs.mapId) {
    wrap.appendChild(el("div", { class: "card", style: "border-color:#f59e0b" }, [
      el("div", { style: "font-size:13px;color:#f59e0b;font-weight:700" }, "Setup required"),
      el("div", { class: "muted", style: "font-size:12px;margin-top:4px" },
        "Return to Setup and select your beacon device and floor map."),
      el("button", {
        class: "btn", style: "margin-top:10px",
        onclick: () => { cs.tab = "setup"; ctx.actions.renderRooms(); },
      }, "Go to Setup"),
    ]));
    return wrap;
  }

  const maps = ctx.state.maps?.list || [];
  const mapData = maps.find(m => m.id === cs.mapId);
  if (!mapData?.image?.filename) {
    wrap.appendChild(el("div", { class: "card" }, [
      el("div", { class: "muted" }, "Selected map has no image. Upload a floor plan in the Maps tab."),
    ]));
    return wrap;
  }

  // Instructions (collapsed after first point)
  const pts = calData.points || [];
  const mapPts = pts.filter(p => p.map_id === cs.mapId);
  if (!mapPts.length) {
    wrap.appendChild(el("div", { style: "font-size:12px;color:#78909c;padding:8px 4px;line-height:1.6" },
      "Tap anywhere on the map to place a calibration pin, then press Start Collecting. Stand still at that exact spot for the full duration."));
  }

  // ── Interactive map ──────────────────────────────────────────────────────
  const mapWrap = el("div", { style: "position:relative;border-radius:10px;overflow:hidden;border:2px solid #1b3526;touch-action:none" });
  const snap = (ctx.state.live && ctx.state.live.snapshot) || null;

  // Build SVG string
  const ar = (mapData.image.height || 600) / (mapData.image.width || 800);
  const imgUrl = `/local/padspan_ha/maps/${mapData.image.filename}`;
  const vbH = ar * 100;

  // Existing calibration points as dots
  let dotsSvg = mapPts.map(p => {
    const px = p.x_frac * 100;
    const py = p.y_frac * vbH;
    const sc = (p.scanner_readings || []).length;
    return `<circle cx="${px}" cy="${py}" r="3.5" fill="#52b788" stroke="white" stroke-width="1" opacity="0.85"/>
            <title>${p.room || p.label || ""} (${sc} scanners)</title>`;
  }).join("");

  // Current pin
  let pinSvg = "";
  if (cs.pinX !== null) {
    const px = cs.pinX * 100;
    const py = cs.pinY * vbH;
    pinSvg = `
      <circle cx="${px}" cy="${py}" r="10" fill="none" stroke="#f59e0b" stroke-width="2" stroke-dasharray="3 2" opacity="0.8"/>
      <circle cx="${px}" cy="${py}" r="4" fill="#f59e0b" stroke="white" stroke-width="1.5"/>
      <line x1="${px}" y1="${py - 10}" x2="${px}" y2="${py - 16}" stroke="#f59e0b" stroke-width="1.5"/>`;
  }

  const svgStr = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 ${vbH}"
      preserveAspectRatio="none" style="width:100%;display:block;cursor:crosshair">
    <image href="${imgUrl}" x="0" y="0" width="100" height="${vbH}" preserveAspectRatio="none"/>
    ${dotsSvg}
    ${pinSvg}
  </svg>`;

  mapWrap.innerHTML = svgStr;

  // Tap handler — must attach after setting innerHTML
  const svgEl = mapWrap.querySelector("svg");
  if (svgEl && !cs.collecting) {
    const onTap = (ev) => {
      const rect = svgEl.getBoundingClientRect();
      // touchend: use changedTouches (the lifted finger); click: use clientX/Y directly
      const touch = (ev.changedTouches && ev.changedTouches[0]) || null;
      const clientX = touch ? touch.clientX : ev.clientX;
      const clientY = touch ? touch.clientY : ev.clientY;
      cs.pinX = (clientX - rect.left) / rect.width;
      cs.pinY = (clientY - rect.top) / rect.height;
      cs.readings = null;
      // Auto-detect room
      cs.pinRoom = _detectRoom(cs.pinX, cs.pinY, mapData) || "";
      ctx.actions.renderRooms();
    };
    svgEl.addEventListener("click", onTap);
    svgEl.addEventListener("touchend", (ev) => { ev.preventDefault(); onTap(ev); });
  }
  wrap.appendChild(mapWrap);

  // Map legend
  wrap.appendChild(el("div", { style: "font-size:11px;color:#78909c;text-align:center" },
    `${mapPts.length} point${mapPts.length !== 1 ? "s" : ""} on this map · tap to place pin`));

  // ── Pin info panel ────────────────────────────────────────────────────────
  if (cs.pinX !== null) {
    const pinPanel = el("div", { class: "card" });

    if (cs.collecting) {
      // Active collection UI — injected as a real DOM node we can update
      const collUI = _buildCollectionUI(ctx, el, cs, mapData);
      pinPanel.appendChild(collUI);
    } else if (cs.readings) {
      // Collection done — show summary + save/discard
      pinPanel.appendChild(_buildSavePanel(ctx, el, cs, calData, mapData));
    } else {
      // Ready to collect
      pinPanel.appendChild(el("div", { style: "margin-bottom:10px" }, [
        el("div", { style: "font-weight:700;font-size:14px;margin-bottom:4px" },
          `Pin at: ${cs.pinRoom || "Unknown room"}`),
        el("div", { style: "font-size:12px;color:#94a3b8" },
          `Position: ${(cs.pinX * 100).toFixed(1)}% × ${(cs.pinY * 100).toFixed(1)}%`),
      ]));

      // Optional label
      const lblRow = el("div", { style: "margin-bottom:10px" });
      const lblInput = document.createElement("input");
      lblInput.type = "text";
      lblInput.placeholder = `Label (optional, e.g. "Kitchen center")`;
      lblInput.style.width = "100%";
      lblInput.style.boxSizing = "border-box";
      lblInput.value = cs.pinLabel || "";
      lblInput.addEventListener("input", () => { cs.pinLabel = lblInput.value; });
      lblRow.appendChild(lblInput);
      pinPanel.appendChild(lblRow);

      // Live beacon signal status
      const { perRadio: pinPerRadio } = _findBeaconAds(snap, cs.deviceId);
      const pinRadioCount = Object.keys(pinPerRadio).length;
      const signalBox = el("div", { style: `padding:8px 10px;border-radius:8px;margin-bottom:10px;background:#071008;border:1px solid ${pinRadioCount > 0 ? "#1b3526" : "#7d5c2b"}` });
      if (pinRadioCount > 0) {
        signalBox.appendChild(el("div", { style: "font-size:12px;color:#52b788;font-weight:600;margin-bottom:4px" },
          `✓ Beacon visible on ${pinRadioCount} radio${pinRadioCount > 1 ? "s" : ""}`));
        const sorted = Object.entries(pinPerRadio).sort((a, b) => (b[1].rssi || -200) - (a[1].rssi || -200));
        for (const [src, info] of sorted) {
          signalBox.appendChild(_rssiRow(el, info.name || src, info.rssi));
        }
      } else {
        signalBox.appendChild(el("div", { style: "font-size:12px;color:#f59e0b;font-weight:600" },
          "⚠ Beacon not currently detected by any radio"));
        signalBox.appendChild(el("div", { class: "muted", style: "font-size:11px;margin-top:3px" },
          "Collection will start but may capture no data. Verify beacon is broadcasting."));
      }
      pinPanel.appendChild(signalBox);

      // Start button
      const startBtn = el("button", {
        class: "btn",
        style: "width:100%;font-size:15px;padding:12px",
      }, `▶  Start Collecting (${cs.duration}s)`);
      startBtn.addEventListener("click", () => _startCollection(ctx, cs, snap, mapData));
      pinPanel.appendChild(startBtn);
    }

    wrap.appendChild(pinPanel);
  }

  return wrap;
}

// ── Collection UI ─────────────────────────────────────────────────────────────
function _buildCollectionUI(ctx, el, cs) {
  const wrap = el("div", { id: "collect-ui" });
  wrap.appendChild(el("div", { style: "font-weight:700;font-size:15px;text-align:center;margin-bottom:10px" },
    "Collecting — hold still!"));

  // Countdown — updated by collection loop via direct DOM ref stored on cs
  const timerDiv = el("div", {
    id: "collect-timer",
    style: "font-size:48px;font-weight:900;text-align:center;color:#52b788;font-family:monospace;margin-bottom:4px",
  }, "…");
  cs._timerEl = timerDiv;   // store ref so loop can update without document.getElementById
  wrap.appendChild(timerDiv);

  // Poll counter — proves the loop is running
  const pollDiv = el("div", {
    style: "font-size:11px;text-align:center;color:#78909c;margin-bottom:12px;font-family:monospace",
  }, `Poll #${cs._pollCount || 0}  ·  ${_totalSamples(cs)} sample${_totalSamples(cs) !== 1 ? "s" : ""} collected`);
  cs._pollCountEl = pollDiv;
  wrap.appendChild(pollDiv);

  wrap.appendChild(el("div", { style: "font-size:12px;color:#78909c;text-align:center;margin-bottom:8px" },
    "Per-radio RSSI (updating live):"));

  // Scanner RSSI container — updated by collection loop
  const scanDiv = el("div", { id: "collect-scanners", style: "display:flex;flex-direction:column;gap:6px" });
  cs._scanEl = scanDiv;     // store ref so loop can update without document.getElementById
  // Populate immediately from any readings already accumulated
  const { el: elHelper } = ctx.helpers;
  for (const [src, rd] of Object.entries(cs.readings || {})) {
    const mean = rd.samples.length ? rd.samples.reduce((a, b) => a + b, 0) / rd.samples.length : -100;
    scanDiv.appendChild(_rssiRow(elHelper, rd.name || src, Math.round(mean), rd.samples.length));
  }
  wrap.appendChild(scanDiv);

  // Stop button
  const stopBtn = el("button", {
    class: "btn inline",
    style: "margin-top:14px;width:100%",
  }, "Stop & Discard");
  stopBtn.addEventListener("click", () => {
    cs.stopFlag = true;
    cs.collecting = false;
    cs.readings = null;
    ctx.actions.renderRooms();
  });
  wrap.appendChild(stopBtn);

  return wrap;
}

// ── Start collection loop ─────────────────────────────────────────────────────
function _startCollection(ctx, cs, _snap, _mapData) {
  cs.collecting  = true;
  cs.stopFlag    = false;
  cs.readings    = {};
  cs._pollCount  = 0;
  ctx.actions.renderRooms();

  const endTime = Date.now() + cs.duration * 1000;

  const loop = async () => {
    if (cs.stopFlag) return;

    // Poll snapshot
    try { await ctx.actions.refreshSnapshot(); } catch (_) { /**/ }
    cs._pollCount = (cs._pollCount || 0) + 1;

    const snap = ctx.state.live?.snapshot;

    // ── Collect per-radio RSSI from BLE advertisements (primary source) ──────
    // snap.objects.list[].sources is just a list of source-ID strings, NOT RSSI data.
    // The real per-radio RSSI lives in snap.ble.advertisements, one entry per {device,radio}.
    const { perRadio } = _findBeaconAds(snap, cs.deviceId);
    for (const [src, info] of Object.entries(perRadio)) {
      if (typeof info.rssi !== "number") continue;
      if (!cs.readings[src]) {
        cs.readings[src] = { name: info.name || src, samples: [] };
      } else if (info.name && info.name !== src) {
        cs.readings[src].name = info.name; // update to area name if now available
      }
      cs.readings[src].samples.push(info.rssi);
    }

    const remaining = Math.max(0, Math.ceil((endTime - Date.now()) / 1000));
    const total = _totalSamples(cs);
    const { el } = ctx.helpers;

    // Update DOM directly via refs stored on cs (works in shadow DOM)
    if (cs._timerEl) cs._timerEl.textContent = remaining + "s";
    if (cs._pollCountEl) cs._pollCountEl.textContent =
      `Poll #${cs._pollCount}  ·  ${total} sample${total !== 1 ? "s" : ""} collected`;
    if (cs._scanEl) {
      cs._scanEl.innerHTML = "";
      const sorted = Object.entries(cs.readings).sort((a, b) => {
        const ma = a[1].samples.length ? a[1].samples.reduce((x,y)=>x+y,0)/a[1].samples.length : -200;
        const mb = b[1].samples.length ? b[1].samples.reduce((x,y)=>x+y,0)/b[1].samples.length : -200;
        return mb - ma;
      });
      if (sorted.length) {
        for (const [src, rd] of sorted) {
          const mean = rd.samples.reduce((a, b) => a + b, 0) / rd.samples.length;
          cs._scanEl.appendChild(_rssiRow(el, rd.name || src, Math.round(mean), rd.samples.length));
        }
      } else {
        cs._scanEl.appendChild(el("div", { style: "font-size:12px;color:#f59e0b;text-align:center;padding:8px" },
          "Beacon not detected yet. Make sure Bluetooth is on and device is near a scanner."));
      }
    }

    if (Date.now() >= endTime || cs.stopFlag) {
      cs.collecting = false;
      cs.readings = (!cs.stopFlag && Object.keys(cs.readings).length > 0) ? cs.readings : null;
      ctx.actions.renderRooms();
      return;
    }

    const nextIn = Math.min(POLL_MS, endTime - Date.now());
    if (nextIn > 0) setTimeout(loop, nextIn);
  };

  loop();
}

// ── Save panel (after collection) ─────────────────────────────────────────────
function _buildSavePanel(ctx, el, cs, calData, mapData) {
  const wrap = el("div");
  const readingsEntries = Object.entries(cs.readings || {});
  const totalSamples = readingsEntries.reduce((s, [, r]) => s + r.samples.length, 0);

  wrap.appendChild(el("div", { style: "font-weight:700;font-size:14px;margin-bottom:8px;color:#52b788" },
    "✓ Collection complete"));
  wrap.appendChild(el("div", { style: "font-size:12px;color:#94a3b8;margin-bottom:10px" },
    `${readingsEntries.length} scanner${readingsEntries.length !== 1 ? "s" : ""} · ${totalSamples} total samples · ${cs.pinRoom || "unknown room"}`));

  // Per-scanner summary
  if (readingsEntries.length) {
    for (const [src, rd] of readingsEntries) {
      const mean = rd.samples.length ? rd.samples.reduce((a, b) => a + b, 0) / rd.samples.length : -100;
      wrap.appendChild(_rssiRow(el, rd.name || src, Math.round(mean), rd.samples.length));
    }
  } else {
    wrap.appendChild(el("div", { style: "font-size:12px;color:#f59e0b;margin-bottom:8px" },
      "No scanner data captured. The device was not visible during collection."));
  }

  // Buttons
  const btnRow = el("div", { style: "display:flex;gap:8px;margin-top:12px" });

  if (readingsEntries.length > 0) {
    const saveBtn = el("button", { class: "btn", style: "flex:1" }, "Save Point");
    saveBtn.addEventListener("click", async () => {
      saveBtn.disabled = true;
      saveBtn.textContent = "Saving…";
      try {
        // Build point payload
        const scannerReadings = readingsEntries.map(([source, rd]) => ({
          source,
          name: rd.name || source,
          rssi_samples: rd.samples,
        }));
        await ctx.actions.calibrationSavePoint({
          map_id:    cs.mapId,
          x_frac:    cs.pinX,
          y_frac:    cs.pinY,
          floor_id:  mapData.floor_id || "",
          room:      cs.pinRoom || "",
          label:     cs.pinLabel || "",
          device_id: cs.deviceId || "",
          duration_s: cs.duration,
          scanner_readings: scannerReadings,
        });
        // Refresh local DB
        const fresh = await ctx.actions.calibrationGet();
        ctx.state.calibration = fresh;
        cs.readings   = null;
        cs.pinX       = null;
        cs.pinY       = null;
        cs.pinRoom    = null;
        cs.pinLabel   = "";
        cs.savedThisSession++;
        ctx.toast(`Point saved (${cs.savedThisSession} this session).`);
        ctx.actions.renderRooms();
      } catch (e) {
        saveBtn.disabled = false;
        saveBtn.textContent = "Save Point";
        ctx.toast("Save failed: " + String(e), true);
      }
    });
    btnRow.appendChild(saveBtn);
  }

  const discardBtn = el("button", { class: "btn inline", style: "flex:1" }, "Discard");
  discardBtn.addEventListener("click", () => {
    cs.readings = null;
    cs.pinX     = null;
    cs.pinY     = null;
    cs.pinLabel = "";
    ctx.actions.renderRooms();
  });
  btnRow.appendChild(discardBtn);
  wrap.appendChild(btnRow);

  return wrap;
}

// ── Roam tab ──────────────────────────────────────────────────────────────────
function _roam(ctx, el, cs, calData) {
  const wrap = el("div", { style: "display:flex;flex-direction:column;gap:14px" });

  if (!cs.deviceId || !cs.mapId) {
    wrap.appendChild(el("div", { class: "card", style: "border-color:#f59e0b" }, [
      el("div", { style: "color:#f59e0b;font-weight:700" }, "Setup required"),
      el("button", {
        class: "btn", style: "margin-top:10px",
        onclick: () => { cs.tab = "setup"; ctx.actions.renderRooms(); },
      }, "Go to Setup"),
    ]));
    return wrap;
  }

  const maps = ctx.state.maps?.list || [];
  const mapData = maps.find(m => m.id === cs.mapId);
  if (!mapData?.image?.filename) {
    wrap.appendChild(el("div", { class: "card" }, [
      el("div", { class: "muted" }, "No map image available."),
    ]));
    return wrap;
  }

  const pts = calData.points || [];
  const mapPts = pts.filter(p => p.map_id === cs.mapId);

  // Compute coverage grid (JS side)
  const grid = _computeCoverage(mapPts, GRID_N);
  const covered = grid.filter(v => v >= 0.5).length;
  const pct = Math.round(covered / (GRID_N * GRID_N) * 100);
  const target = _nextTarget(grid, GRID_N);

  // Coverage progress bar
  const progCard = el("div", { class: "card" });
  progCard.appendChild(el("div", { style: "display:flex;align-items:center;gap:10px;margin-bottom:8px" }, [
    el("div", { style: "font-weight:700;font-size:14px" }, "Coverage"),
    el("span", { class: "badge", style: "margin-left:auto" }, `${mapPts.length} points`),
    el("span", { class: pct >= 70 ? "badge" : "badge warn" }, `${pct}%`),
  ]));
  const barOuter = el("div", { style: "height:10px;background:#1b3526;border-radius:5px;overflow:hidden" });
  const barInner = el("div", { style: `height:100%;width:${pct}%;background:${pct >= 70 ? "#52b788" : pct >= 40 ? "#f59e0b" : "#dc2626"};transition:width 0.5s` });
  barOuter.appendChild(barInner);
  progCard.appendChild(barOuter);
  progCard.appendChild(el("div", { class: "muted", style: "font-size:11px;margin-top:6px" },
    pct >= 80
      ? "✓ Excellent coverage — model should be highly accurate."
      : pct >= 50
      ? "Good progress. Keep adding points to improve accuracy."
      : "Keep going — more points needed for a reliable model."));
  wrap.appendChild(progCard);

  // Coverage heatmap map
  const ar = (mapData.image.height || 600) / (mapData.image.width || 800);
  const vbH = ar * 100;
  const imgUrl = `/local/padspan_ha/maps/${mapData.image.filename}`;
  const cellW = 100 / GRID_N;
  const cellH = vbH / GRID_N;

  // Coverage grid cells
  let gridSvg = "";
  for (let cy = 0; cy < GRID_N; cy++) {
    for (let cx = 0; cx < GRID_N; cx++) {
      const v = grid[cy * GRID_N + cx];
      const opacity = Math.max(0, 0.6 * (1 - v)).toFixed(2);
      const color = v >= 0.5 ? "#52b788" : v >= 0.2 ? "#f59e0b" : "#dc2626";
      gridSvg += `<rect x="${(cx * cellW).toFixed(2)}" y="${(cy * cellH).toFixed(2)}" width="${cellW.toFixed(2)}" height="${cellH.toFixed(2)}" fill="${color}" opacity="${opacity}" rx="0.5"/>`;
    }
  }

  // Existing calibration dots
  const dotsSvg = mapPts.map(p =>
    `<circle cx="${(p.x_frac * 100).toFixed(2)}" cy="${(p.y_frac * vbH).toFixed(2)}" r="2.5" fill="#52b788" stroke="white" stroke-width="0.8" opacity="0.9"/>`
  ).join("");

  // Next target crosshair
  const tx = (target.x_frac * 100).toFixed(2);
  const ty = (target.y_frac * vbH).toFixed(2);
  const targetSvg = `
    <circle cx="${tx}" cy="${ty}" r="7" fill="none" stroke="#60a5fa" stroke-width="2" stroke-dasharray="3 2"/>
    <circle cx="${tx}" cy="${ty}" r="2.5" fill="#60a5fa"/>
    <line x1="${tx}" y1="${(parseFloat(ty) - 7)}" x2="${tx}" y2="${(parseFloat(ty) - 13)}" stroke="#60a5fa" stroke-width="1.5"/>
    <line x1="${tx}" y1="${(parseFloat(ty) + 7)}" x2="${tx}" y2="${(parseFloat(ty) + 13)}" stroke="#60a5fa" stroke-width="1.5"/>
    <line x1="${(parseFloat(tx) - 7)}" y1="${ty}" x2="${(parseFloat(tx) - 13)}" y2="${ty}" stroke="#60a5fa" stroke-width="1.5"/>
    <line x1="${(parseFloat(tx) + 7)}" y1="${ty}" x2="${(parseFloat(tx) + 13)}" y2="${ty}" stroke="#60a5fa" stroke-width="1.5"/>`;

  const mapWrap = el("div", { style: "border-radius:10px;overflow:hidden;border:2px solid #1b3526" });
  mapWrap.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 ${vbH}"
      preserveAspectRatio="none" style="width:100%;display:block">
    <image href="${imgUrl}" x="0" y="0" width="100" height="${vbH}" preserveAspectRatio="none"/>
    ${gridSvg}
    ${dotsSvg}
    ${pct < 100 ? targetSvg : ""}
  </svg>`;
  wrap.appendChild(mapWrap);

  // Legend
  wrap.appendChild(el("div", { style: "display:flex;gap:14px;font-size:11px;color:#78909c;padding:0 4px" }, [
    el("span", {}, [el("span", { style: "color:#52b788" }, "■ "), "Covered"]),
    el("span", {}, [el("span", { style: "color:#f59e0b" }, "■ "), "Partial"]),
    el("span", {}, [el("span", { style: "color:#dc2626" }, "■ "), "Uncovered"]),
    el("span", {}, [el("span", { style: "color:#60a5fa" }, "⊕ "), "Target"]),
  ]));

  // Next target card
  if (pct < 100) {
    const tgtRoom = _detectRoom(target.x_frac, target.y_frac, mapData);
    const tgtCard = el("div", { class: "card", style: "border-color:#60a5fa" });
    tgtCard.appendChild(el("div", { style: "font-weight:700;font-size:14px;color:#60a5fa;margin-bottom:6px" },
      "Next Target"));
    tgtCard.appendChild(el("div", { style: "font-size:13px;margin-bottom:4px" },
      tgtRoom ? `Go to: ${tgtRoom}` : `Position: ${(target.x_frac * 100).toFixed(0)}% × ${(target.y_frac * 100).toFixed(0)}%`));
    tgtCard.appendChild(el("div", { class: "muted", style: "font-size:12px;margin-bottom:12px" },
      "Walk to the blue crosshair location on the map. Stand still, then press the button below."));

    if (cs.collecting) {
      tgtCard.appendChild(_buildCollectionUI(ctx, el, cs));
    } else if (cs.readings) {
      tgtCard.appendChild(_buildSavePanel(ctx, el, cs, calData, mapData));
    } else {
      const collectBtn = el("button", {
        class: "btn",
        style: "width:100%;font-size:15px;padding:12px",
      }, `▶  I'm Here — Collect (${cs.duration}s)`);
      collectBtn.addEventListener("click", () => {
        // Auto-set pin to target location
        cs.pinX     = target.x_frac;
        cs.pinY     = target.y_frac;
        cs.pinRoom  = tgtRoom || "";
        cs.pinLabel = tgtRoom ? `Roam: ${tgtRoom}` : "Roam point";
        const snap = (ctx.state.live && ctx.state.live.snapshot) || null;
        _startCollection(ctx, cs, snap, mapData);
      });
      tgtCard.appendChild(collectBtn);
    }
    wrap.appendChild(tgtCard);
  } else {
    wrap.appendChild(el("div", { class: "card", style: "border-color:#52b788;text-align:center" }, [
      el("div", { style: "font-size:28px;margin-bottom:8px" }, "🎉"),
      el("div", { style: "font-weight:700;font-size:15px;color:#52b788;margin-bottom:6px" }, "Full Coverage!"),
      el("div", { class: "muted", style: "font-size:12px" },
        "Every zone has calibration data. Check the Model tab to see accuracy estimates."),
      el("button", {
        class: "btn", style: "margin-top:12px",
        onclick: () => { cs.tab = "model"; ctx.actions.renderRooms(); },
      }, "View Model →"),
    ]));
  }

  return wrap;
}

// ── Model tab ─────────────────────────────────────────────────────────────────
function _modelTab(ctx, el, cs, calData) {
  const wrap = el("div", { style: "display:flex;flex-direction:column;gap:14px" });
  const pts  = calData.points || [];
  const model = calData.model || {};
  const maps  = ctx.state.maps?.list || [];

  // Compute button
  const computeCard = el("div", { class: "card" });
  computeCard.appendChild(el("div", { style: "font-weight:700;font-size:14px;margin-bottom:6px" }, "Model Computation"));
  computeCard.appendChild(el("div", { class: "muted", style: "font-size:12px;margin-bottom:10px" },
    "Fit path-loss curves and run cross-validation after adding new calibration points."));
  const computeWrap = el("div", { style: "display:flex;gap:8px;align-items:center" });
  const makeComputeBtn = () => {
    const b = el("button", { class: "btn" }, "Compute Model");
    b.addEventListener("click", async () => {
      computeWrap.innerHTML = "";
      computeWrap.appendChild(el("span", { class: "muted", style: "font-size:12px" }, "Computing…"));
      try {
        const result = await ctx.actions.calibrationComputeModel();
        ctx.state.calibration = await ctx.actions.calibrationGet();
        ctx.toast("Model computed.");
        ctx.actions.renderRooms();
      } catch (e) {
        ctx.toast("Compute failed: " + String(e), true);
        computeWrap.innerHTML = "";
        computeWrap.appendChild(makeComputeBtn());
      }
    });
    return b;
  };
  computeWrap.appendChild(makeComputeBtn());
  computeCard.appendChild(computeWrap);

  if (model.last_computed) {
    computeCard.appendChild(el("div", {
      class: "muted",
      style: "font-size:11px;margin-top:8px",
    }, `Last computed: ${model.last_computed}`));
  }
  wrap.appendChild(computeCard);

  if (!pts.length) {
    wrap.appendChild(el("div", { class: "card" }, [
      el("div", { class: "muted" }, "No calibration points yet. Use Pin & Listen or Roam to collect data."),
    ]));
    return wrap;
  }

  // Summary stats
  const mapIds = [...new Set(pts.map(p => p.map_id))];
  const scanners = new Set();
  pts.forEach(p => p.scanner_readings?.forEach(r => scanners.add(r.source)));

  const summCard = el("div", { class: "card" });
  summCard.appendChild(el("div", { style: "font-weight:700;font-size:14px;margin-bottom:12px" }, "Summary"));
  const statGrid = el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:10px" });
  const stat = (label, value, color) => el("div", { style: "background:#0a150e;border:1px solid #1b3526;border-radius:8px;padding:10px;text-align:center" }, [
    el("div", { style: `font-size:22px;font-weight:900;color:${color || "#52b788"}` }, String(value)),
    el("div", { style: "font-size:11px;color:#78909c;margin-top:2px" }, label),
  ]);
  statGrid.appendChild(stat("Calibration Points", pts.length));
  statGrid.appendChild(stat("Scanners Seen", scanners.size));
  statGrid.appendChild(stat("Maps Calibrated", mapIds.length));

  const loo = model.loo_accuracy;
  if (loo) {
    statGrid.appendChild(stat("Est. Accuracy", `~${loo.mean_error_m_est}m`, loo.mean_error_m_est < 2 ? "#52b788" : "#f59e0b"));
  } else {
    statGrid.appendChild(stat("Accuracy", pts.length >= 4 ? "Compute →" : "Need ≥4 pts", "#78909c"));
  }
  summCard.appendChild(statGrid);
  wrap.appendChild(summCard);

  // Per-map coverage mini-maps
  for (const mid of mapIds) {
    const mapData = maps.find(m => m.id === mid);
    const mapPts  = pts.filter(p => p.map_id === mid);
    const grid = _computeCoverage(mapPts, GRID_N);
    const covered = grid.filter(v => v >= 0.5).length;
    const pct = Math.round(covered / (GRID_N * GRID_N) * 100);

    const mapCovCard = el("div", { class: "card" });
    mapCovCard.appendChild(el("div", { style: "display:flex;align-items:center;gap:8px;margin-bottom:8px" }, [
      el("div", { style: "font-weight:700;font-size:13px" }, mapData?.name || mid),
      el("span", { class: "badge", style: "margin-left:auto" }, `${mapPts.length} pts`),
      el("span", { class: pct >= 70 ? "badge" : "badge warn" }, `${pct}%`),
    ]));

    if (mapData?.image?.filename) {
      const ar = (mapData.image.height || 600) / (mapData.image.width || 800);
      const vbH = ar * 100;
      const imgUrl = `/local/padspan_ha/maps/${mapData.image.filename}`;
      const cellW = 100 / GRID_N;
      const cellH = vbH / GRID_N;

      let gSvg = "";
      for (let cy = 0; cy < GRID_N; cy++) {
        for (let cx = 0; cx < GRID_N; cx++) {
          const v = grid[cy * GRID_N + cx];
          const op = Math.max(0, 0.55 * (1 - v)).toFixed(2);
          const col = v >= 0.5 ? "#52b788" : v >= 0.2 ? "#f59e0b" : "#dc2626";
          gSvg += `<rect x="${(cx * cellW).toFixed(1)}" y="${(cy * cellH).toFixed(1)}" width="${cellW.toFixed(1)}" height="${cellH.toFixed(1)}" fill="${col}" opacity="${op}" rx="0.5"/>`;
        }
      }
      const dotsSvg = mapPts.map(p =>
        `<circle cx="${(p.x_frac * 100).toFixed(1)}" cy="${(p.y_frac * vbH).toFixed(1)}" r="2" fill="#52b788" stroke="white" stroke-width="0.6" opacity="0.9"/>`
      ).join("");

      const miniDiv = el("div", { style: "border-radius:6px;overflow:hidden;border:1px solid #1b3526;margin-bottom:8px" });
      miniDiv.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 ${vbH}" preserveAspectRatio="none" style="width:100%;display:block">
        <image href="${imgUrl}" x="0" y="0" width="100" height="${vbH}" preserveAspectRatio="none"/>
        ${gSvg}${dotsSvg}
      </svg>`;
      mapCovCard.appendChild(miniDiv);
    }

    // LOO accuracy for this map
    const mapLoo = model.coverage_by_map?.[mid]?.loo_accuracy;
    if (mapLoo) {
      mapCovCard.appendChild(el("div", { style: "font-size:12px;color:#94a3b8" },
        `Cross-validation accuracy: ~${mapLoo.mean_error_m_est}m mean · ${mapLoo.max_error_frac.toFixed(3)} frac max`));
    }
    wrap.appendChild(mapCovCard);
  }

  // Per-scanner path-loss stats
  if (model.path_loss && Object.keys(model.path_loss).length) {
    const plCard = el("div", { class: "card" });
    plCard.appendChild(el("div", { style: "font-weight:700;font-size:14px;margin-bottom:10px" }, "Path-Loss Fits"));
    plCard.appendChild(el("div", { class: "muted", style: "font-size:12px;margin-bottom:10px" },
      "RSSI = RSSI_1m − 10 · n · log₁₀(d). n > 3 = heavy attenuation (walls/floors). R² > 0.7 = reliable fit."));
    const tbody = el("tbody");
    for (const [src, fit] of Object.entries(model.path_loss)) {
      const rSqColor = fit.r_squared >= 0.7 ? "#52b788" : fit.r_squared >= 0.4 ? "#f59e0b" : "#dc2626";
      tbody.appendChild(el("tr", {}, [
        el("td", { style: "font-size:11px;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" },
          fit.scanner_name || src),
        el("td", { style: "font-family:monospace;font-size:11px" }, fit.n.toFixed(2)),
        el("td", { style: "font-family:monospace;font-size:11px" }, fit.rssi_1m + " dBm"),
        el("td", { style: `font-family:monospace;font-size:11px;color:${rSqColor}` }, fit.r_squared.toFixed(2)),
        el("td", { class: "muted", style: "font-size:11px" }, fit.point_count),
      ]));
    }
    plCard.appendChild(el("table", { class: "table" }, [
      el("thead", {}, el("tr", {}, [
        el("th", {}, "Scanner"), el("th", {}, "n"), el("th", {}, "RSSI@1m"), el("th", {}, "R²"), el("th", {}, "Pts"),
      ])),
      tbody,
    ]));
    wrap.appendChild(plCard);
  }

  // Per-scanner general stats
  if (model.scanner_stats && Object.keys(model.scanner_stats).length) {
    const ssCard = el("div", { class: "card" });
    ssCard.appendChild(el("div", { style: "font-weight:700;font-size:14px;margin-bottom:10px" }, "Scanner Coverage"));
    const tbody = el("tbody");
    for (const [src, st] of Object.entries(model.scanner_stats)) {
      tbody.appendChild(el("tr", {}, [
        el("td", { style: "font-size:11px;max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" },
          st.name || src),
        el("td", { style: "font-family:monospace;font-size:11px" }, st.mean_rssi != null ? st.mean_rssi + " dBm" : "—"),
        el("td", { style: "font-family:monospace;font-size:11px" }, st.std_rssi != null ? "±" + st.std_rssi : "—"),
        el("td", { class: "muted", style: "font-size:11px" }, st.point_count),
      ]));
    }
    ssCard.appendChild(el("table", { class: "table" }, [
      el("thead", {}, el("tr", {}, [
        el("th", {}, "Scanner"), el("th", {}, "Mean RSSI"), el("th", {}, "Std"), el("th", {}, "Pts"),
      ])),
      tbody,
    ]));
    wrap.appendChild(ssCard);
  }

  // Calibration points list
  const ptsCard = el("div", { class: "card" });
  ptsCard.appendChild(el("div", { class: "row", style: "margin-bottom:10px" }, [
    el("div", { style: "font-weight:700;font-size:14px" }, "Calibration Points"),
    el("span", { class: "badge", style: "margin-left:8px" }, pts.length),
  ]));
  const ptsList = el("div", { style: "display:flex;flex-direction:column;gap:4px;max-height:320px;overflow-y:auto" });
  for (const pt of [...pts].reverse()) {
    const mapName = maps.find(m => m.id === pt.map_id)?.name || pt.map_id || "?";
    const sc = pt.scanner_readings?.length || 0;
    const rowWrap = el("div", {
      style: "display:flex;align-items:center;gap:8px;padding:6px 8px;background:#0a150e;border:1px solid #1b3526;border-radius:8px"
    });
    rowWrap.appendChild(el("div", { style: "flex:1;min-width:0" }, [
      el("div", { style: "font-size:12px;font-weight:600" }, pt.label || pt.room || "Unlabeled"),
      el("div", { style: "font-size:11px;color:#78909c" },
        `${mapName} · ${sc} scanner${sc !== 1 ? "s" : ""} · ${pt.collected_at?.slice(0, 10) || ""}`),
    ]));
    const delWrap = el("div");
    const makeDelBtn = () => {
      const b = el("button", { class: "btn tiny" }, "Delete");
      b.addEventListener("click", () => {
        delWrap.innerHTML = "";
        const yes = el("button", { class: "btn tiny", style: "background:#7f1d1d;border-color:#dc2626" }, "Yes");
        const no  = el("button", { class: "btn tiny" }, "No");
        yes.addEventListener("click", async () => {
          delWrap.innerHTML = "";
          try {
            await ctx.actions.calibrationDeletePoint(pt.id);
            ctx.state.calibration = await ctx.actions.calibrationGet();
            ctx.actions.renderRooms();
          } catch (e) {
            ctx.toast("Delete failed: " + String(e), true);
            delWrap.appendChild(makeDelBtn());
          }
        });
        no.addEventListener("click", () => { delWrap.innerHTML = ""; delWrap.appendChild(makeDelBtn()); });
        delWrap.appendChild(yes); delWrap.appendChild(no);
      });
      return b;
    };
    delWrap.appendChild(makeDelBtn());
    rowWrap.appendChild(delWrap);
    ptsList.appendChild(rowWrap);
  }
  ptsCard.appendChild(ptsList);
  wrap.appendChild(ptsCard);

  // Actions
  const actCard = el("div", { class: "card" });
  actCard.appendChild(el("div", { style: "font-weight:700;font-size:14px;margin-bottom:10px" }, "Actions"));

  // Export JSON
  const expBtn = el("button", { class: "btn inline" }, "Export JSON");
  expBtn.addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(calData, null, 2)], { type: "application/json" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url; a.download = "padspan_calibration.json";
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
  });
  actCard.appendChild(expBtn);

  // Clear all
  const clearWrap = el("div", { style: "margin-top:10px;display:flex;gap:8px;align-items:center" });
  const makeClearBtn = () => {
    const b = el("button", { class: "btn inline", style: "border-color:#dc2626;color:#fca5a5" },
      `Clear All (${pts.length})`);
    b.addEventListener("click", () => {
      clearWrap.innerHTML = "";
      const yes = el("button", { class: "btn", style: "background:#7f1d1d;border-color:#dc2626" },
        `Yes, delete all ${pts.length} points`);
      const no  = el("button", { class: "btn inline" }, "Cancel");
      yes.addEventListener("click", async () => {
        clearWrap.innerHTML = "";
        try {
          await ctx.actions.calibrationClear();
          ctx.state.calibration = { points: [], model: {} };
          ctx.toast("All calibration data cleared.");
          ctx.actions.renderRooms();
        } catch (e) {
          ctx.toast("Failed: " + String(e), true);
          clearWrap.appendChild(makeClearBtn());
        }
      });
      no.addEventListener("click", () => { clearWrap.innerHTML = ""; clearWrap.appendChild(makeClearBtn()); });
      clearWrap.appendChild(yes); clearWrap.appendChild(no);
    });
    return b;
  };
  clearWrap.appendChild(makeClearBtn());
  actCard.appendChild(clearWrap);
  wrap.appendChild(actCard);

  return wrap;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

// ── Find all BLE advertisements for the given device ID ───────────────────────
// Returns { myAds, perRadio, targetAddr } where perRadio is {source→{name,rssi,age_s}}.
// Handles both MAC addresses and entity_id values.
function _findBeaconAds(snap, deviceId) {
  if (!snap || !deviceId) return { myAds: [], perRadio: {}, targetAddr: "" };
  const rawId = String(deviceId).trim();
  const upperId = rawId.toUpperCase();

  // If it looks like a MAC address, use it directly; otherwise resolve via objects.list
  let targetAddr = upperId.match(/^[0-9A-F:]{17}$/) ? upperId : "";
  if (!targetAddr) {
    const entity = (snap?.objects?.list || []).find(o =>
      (o.entity_id || "") === rawId ||
      (o.entity_id || "").toUpperCase() === upperId
    );
    targetAddr = (entity?.address || "").toUpperCase();
  }

  // Build source → display name from snap.ble.radios (prefer area/room over adapter name)
  const radioNameMap = {};
  for (const r of (snap?.ble?.radios || [])) {
    if (r.source) radioNameMap[r.source] = r.area_name || r.area || r.name || r.source;
  }

  // Filter raw advertisements by address
  const myAds = (snap?.ble?.advertisements || []).filter(ad =>
    (ad.address || "").toUpperCase() === (targetAddr || upperId)
  );

  // Build per-radio map — keep strongest/most recent reading per radio
  const perRadio = {};
  for (const ad of myAds) {
    const src = String(ad.source || "");
    if (!src) continue;
    if (!perRadio[src] || (ad.rssi || -200) > (perRadio[src].rssi || -200)) {
      perRadio[src] = {
        name: radioNameMap[src] || src,
        rssi: ad.rssi,
        age_s: ad.age_s,
      };
    }
  }
  return { myAds, perRadio, targetAddr };
}

function _totalSamples(cs) {
  return Object.values(cs.readings || {}).reduce((t, r) => t + r.samples.length, 0);
}

function _rssiRow(el, name, rssi, samples) {
  const pct = Math.max(0, Math.min(100, ((rssi ?? -100) + 100) / 60 * 100));
  const color = pct >= 66 ? "#52b788" : pct >= 33 ? "#f59e0b" : "#dc2626";
  return el("div", {
    style: "display:flex;align-items:center;gap:8px;padding:4px 0"
  }, [
    el("div", { style: "font-size:11px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#94a3b8" }, name || "?"),
    el("div", { style: "width:80px;height:6px;background:#1b3526;border-radius:3px;overflow:hidden;flex-shrink:0" }, [
      el("div", { style: `width:${pct.toFixed(0)}%;height:100%;background:${color}` }),
    ]),
    el("div", { style: "font-family:monospace;font-size:11px;color:#e2e8f0;width:48px;text-align:right;flex-shrink:0" },
      rssi != null ? rssi + " dBm" : "—"),
    samples != null
      ? el("div", { style: "font-size:10px;color:#78909c;width:28px;text-align:right;flex-shrink:0" }, "×" + samples)
      : null,
  ].filter(Boolean));
}

function _computeCoverage(pts, gridN) {
  const grid = new Array(gridN * gridN).fill(0);
  for (const pt of pts) {
    const px = pt.x_frac * gridN;
    const py = pt.y_frac * gridN;
    for (let cy = 0; cy < gridN; cy++) {
      for (let cx = 0; cx < gridN; cx++) {
        const dist = Math.sqrt((cx + 0.5 - px) ** 2 + (cy + 0.5 - py) ** 2);
        const contrib = Math.exp(-(dist ** 2) / (2 * SIGMA_C ** 2));
        const idx = cy * gridN + cx;
        grid[idx] = Math.min(1, grid[idx] + contrib);
      }
    }
  }
  return grid;
}

function _nextTarget(grid, gridN) {
  let min = 2, bx = 0.5, by = 0.5;
  for (let cy = 0; cy < gridN; cy++) {
    for (let cx = 0; cx < gridN; cx++) {
      const v = grid[cy * gridN + cx];
      const edgePen = (cx === 0 || cx === gridN - 1 || cy === 0 || cy === gridN - 1) ? 0.05 : 0;
      if (v + edgePen < min) {
        min = v + edgePen;
        bx = (cx + 0.5) / gridN;
        by = (cy + 0.5) / gridN;
      }
    }
  }
  return { x_frac: bx, y_frac: by };
}

// ── Tune tab — 3D iso map with draggable receiver markers ──────────────────
function _tuneTab(ctx, el, cs, calData) {
  const wrap = el("div", { style: "display:flex;flex-direction:column;gap:10px" });
  const maps_list = (ctx.state.maps && ctx.state.maps.list) ? ctx.state.maps.list : [];

  if (!maps_list.length) {
    wrap.appendChild(el("div", { class: "card" }, [
      el("div", { style: "font-weight:700;font-size:14px;margin-bottom:6px;color:#52b788" }, "No Maps Uploaded"),
      el("div", { style: "font-size:12px;color:#94a3b8" },
        "Upload floor plan images in the Maps tab first, then return here to fine-tune receiver positions."),
    ]));
    return wrap;
  }

  // Explainer card
  wrap.appendChild(el("div", { class: "card", style: "border-color:#52b788" }, [
    el("div", { style: "font-weight:700;font-size:14px;margin-bottom:6px;color:#52b788" }, "Receiver Position Tuning"),
    el("div", { style: "font-size:12px;color:#94a3b8;line-height:1.5" },
      "Drag BLE scanner markers to match their real-world positions. The 3D view matches the Overview map. Click Save when done."),
  ]));

  // ── Constants & state ─────────────────────────────────────────────────────
  const TILE = 220, CX = 380, CY = 590, W = 760, BASE_H = 940;
  const LAYER_PAL = ["#52b788","#f59e0b","#60a5fa","#e879f9","#fb923c","#34d399","#f87171","#a78bfa"];
  const _esc = s => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  // roomColor may not exist in standalone calibration panel — provide fallback
  const roomColorFn = ctx.helpers.roomColor || (name => {
    let h = 0; const s = String(name || "");
    for (let i = 0; i < s.length; i++) { h = Math.imul(h ^ s.charCodeAt(i), 16777619); }
    return `hsl(${(h >>> 0) % 360} 70% 55%)`;
  });

  // Live radios from snapshot — used to filter stale receivers
  const _snap = (ctx.state.live && ctx.state.live.snapshot) || null;
  const _liveRadios = _snap?.ble?.radios || [];
  const _isLiveRadio = (r) => _liveRadios.some(rd => rd.name === (r.label || "") || rd.source === (r.id || ""));

  if (!ctx.state._calibTune) ctx.state._calibTune = {
    fg: ctx.state.settings?.overview_iso_floor_gap ?? 150,
    hg: ctx.state.settings?.overview_iso_horiz_gap ?? 0,
    focusIdx: 0,
    draftReceivers: {},   // mapId → [{id,label,x,y,room}]
    dirtyMaps: {},        // mapId → true
    selectedRx: null,     // {mapId, rxId}
    _mapsStamp: null,     // tracks when maps data last changed
  };
  const ts = ctx.state._calibTune;

  // Build a stamp from maps data to detect external updates
  const mapsStamp = maps_list.map(m => `${m.id}:${m.updated||""}:${(m.receivers||[]).length}`).join("|");
  const hasDirty = Object.values(ts.dirtyMaps).some(Boolean);

  // Re-sync draft receivers when maps data changes externally (and no unsaved edits)
  // Filter out stale receivers that no longer match a live radio
  if (!Object.keys(ts.draftReceivers).length || (mapsStamp !== ts._mapsStamp && !hasDirty)) {
    for (const m of maps_list) {
      ts.draftReceivers[m.id] = (m.receivers || [])
        .filter(r => _isLiveRadio(r))
        .map(r => ({
          id: r.id || "", label: r.label || "", x: Number(r.x || 0), y: Number(r.y || 0), room: r.room || "", source: r.source || ""
        }));
    }
    // Remove drafts for maps that no longer exist
    for (const id of Object.keys(ts.draftReceivers)) {
      if (!maps_list.find(m => m.id === id)) delete ts.draftReceivers[id];
    }
    ts._mapsStamp = mapsStamp;
  }

  let _fg = ts.fg, _hg = ts.hg;

  // ── Transforms ────────────────────────────────────────────────────────────
  const iso = (wx, wy, wz) => [CX + (wx - wy) * TILE * 0.866 + wz * _hg, CY + (wx + wy) * TILE * 0.5 - wz * _fg];
  const pt  = c => `${Math.round(c[0])},${Math.round(c[1])}`;
  const pts = cs => cs.map(pt).join(" ");

  // Inverse iso: screen → world at known z-level
  const invIso = (sx, sy, z) => {
    const ax = sx - CX - z * _hg;
    const ay = sy - CY + z * _fg;
    const A = TILE * 0.866, B = TILE * 0.5;
    const wx = (ax / A + ay / B) / 2;
    const wy = (ay / B - ax / A) / 2;
    return [wx, wy];
  };

  // Filter & sort maps
  const hiddenIds = ctx.state.maps._hiddenMapIds || new Set();
  const sorted = [...maps_list].filter(m => !hiddenIds.has(m.id)).sort((a, b) => (a.stack?.z_level || 0) - (b.stack?.z_level || 0));
  const byLevel = new Map();
  for (const m of sorted) { const z = m.stack?.z_level ?? 0; if (!byLevel.has(z)) byLevel.set(z, []); byLevel.get(z).push(m); }
  const sortedIsoLevels = [...byLevel.keys()].sort((a, b) => a - b);
  const levelColor = z => LAYER_PAL[sortedIsoLevels.indexOf(z) % LAYER_PAL.length];

  // Floor focus slider positions
  const _isoPos = [null];
  for (let i = 0; i < sortedIsoLevels.length; i++) {
    _isoPos.push(sortedIsoLevels[i]);
    if (i < sortedIsoLevels.length - 1) _isoPos.push([sortedIsoLevels[i], sortedIsoLevels[i + 1]]);
  }
  ts.focusIdx = Math.max(0, Math.min(ts.focusIdx, _isoPos.length - 1));
  const _getFocusZ = idx => _isoPos[Math.max(0, Math.min(idx, _isoPos.length - 1))];
  const _getFocusLbl = idx => {
    const pos = _getFocusZ(idx);
    if (pos === null) return "All floors";
    const fl = ctx.state.model?.floors || [];
    const zArr = Array.isArray(pos) ? pos : [pos];
    return zArr.map(z => { const f = fl.find(x => x.level === z); return f ? (f.name || `L${z}`) : `L${z}`; }).join(" + ");
  };

  // Per-map forward+inverse transforms
  const mapXforms = {};
  for (const m of sorted) {
    const stk = m.stack || {}, z = stk.z_level || 0, ox = stk.x_offset || 0, oy_ = stk.y_offset || 0, sc = stk.scale || 1.0;
    const ar = (m.image?.height || 600) / (m.image?.width || 800);
    const arRef = stk.ref_ar || ar, sxAdj = stk.scale_x_adj || 1.0;
    const rotRad = (stk.rotation || 0) * Math.PI / 180;
    const cosR = Math.cos(rotRad), sinR = Math.sin(rotRad);
    mapXforms[m.id] = {
      z, ox, oy_, sc, arRef, sxAdj, cosR, sinR,
      mapPt: (px, py) => {
        const dx = (px - 0.5) * sc * sxAdj, dy = (py - 0.5) * sc * arRef;
        const rx = dx * cosR - dy * sinR, ry = dx * sinR + dy * cosR;
        return [(0.5 + ox) + rx, arRef * (0.5 + oy_) + ry];
      },
      invMapPt: (wx, wy) => {
        const rx = wx - (0.5 + ox);
        const ry = wy - arRef * (0.5 + oy_);
        const dx =  rx * cosR + ry * sinR;
        const dy = -rx * sinR + ry * cosR;
        return [dx / (sc * sxAdj) + 0.5, dy / (sc * arRef) + 0.5];
      },
    };
  }

  // ── Build SVG ───────────────────────────────────────────────────────────────
  const LEGEND_H = sortedIsoLevels.length * 30 + 24;
  const buildTuneSVG = (focusZ) => {
    const slabWZ = 18 / _fg;
    const maxIsoZ = sortedIsoLevels.length ? sortedIsoLevels[sortedIsoLevels.length - 1] : 0;
    const viewY = Math.min(0, CY - maxIsoZ * _fg - 50);
    const HTOTAL = BASE_H + LEGEND_H - viewY;
    let s = `<svg viewBox="0 ${viewY} ${W} ${HTOTAL}" xmlns="http://www.w3.org/2000/svg" width="100%" style="max-height:${HTOTAL}px;display:block;font-family:system-ui,sans-serif">`;
    s += `<rect x="0" y="${viewY}" width="${W}" height="${HTOTAL}" fill="#071008"/>`;

    // Floor patterns
    s += `<defs>`;
    sortedIsoLevels.forEach((z2, li) => {
      const c2 = levelColor(z2);
      if (li === 0) {
        s += `<pattern id="tpat_${li}" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">`;
        s += `<path d="M12,2 C16,2 19,6 19,11 C19,16 16,21 12,22 C8,21 5,16 5,11 C5,6 8,2 12,2 Z" fill="none" stroke="${c2}" stroke-width="0.7" opacity="0.14"/>`;
        s += `<path d="M12,2 C13.5,0 15.5,0.5 14.5,2.5 C13.5,1.5 12,2 12,2 Z" fill="${c2}" opacity="0.11"/>`;
        s += `<circle cx="12" cy="15" r="1.4" fill="${c2}" opacity="0.1"/>`;
        s += `</pattern>`;
      } else if (li === 2) {
        s += `<pattern id="tpat_${li}" x="0" y="0" width="12" height="12" patternUnits="userSpaceOnUse">`;
        s += `<line x1="0" y1="12" x2="12" y2="0" stroke="${c2}" stroke-width="0.6" opacity="0.18"/>`;
        s += `<line x1="0" y1="0" x2="12" y2="12" stroke="${c2}" stroke-width="0.6" opacity="0.18"/>`;
        s += `</pattern>`;
      } else if (li >= 3) {
        s += `<pattern id="tpat_${li}" x="0" y="0" width="16" height="13.86" patternUnits="userSpaceOnUse">`;
        s += `<circle cx="0" cy="0" r="1.5" fill="${c2}" opacity="0.14"/>`;
        s += `<circle cx="8" cy="6.93" r="1.5" fill="${c2}" opacity="0.14"/>`;
        s += `<circle cx="16" cy="0" r="1.5" fill="${c2}" opacity="0.14"/>`;
        s += `<circle cx="0" cy="13.86" r="1.5" fill="${c2}" opacity="0.14"/>`;
        s += `<circle cx="16" cy="13.86" r="1.5" fill="${c2}" opacity="0.14"/>`;
        s += `</pattern>`;
      }
    });
    s += `</defs>`;

    if (!sorted.length) {
      s += `<text x="${W / 2}" y="${BASE_H / 2}" text-anchor="middle" fill="#4a6052" font-size="13">All layers hidden</text>`;
      s += `</svg>`; return s;
    }

    // Floor slabs + room polygons + receivers
    for (const [z, group] of [...byLevel.entries()].sort((a, b) => a[0] - b[0])) {
      const isFocused = focusZ === null || (Array.isArray(focusZ) ? focusZ.includes(z) : focusZ === z);
      const go = isFocused ? 1.0 : 0.1;
      const lyrColor = levelColor(z);
      const lidx = sortedIsoLevels.indexOf(z);

      // Bounding box for all maps at this level
      let x0 = Infinity, y0_ = Infinity, x1 = -Infinity, y1_ = -Infinity;
      for (const m of group) {
        const xf = mapXforms[m.id]; if (!xf) continue;
        const stk = m.stack || {}, ox2 = stk.x_offset || 0, oy2 = stk.y_offset || 0, sc2 = stk.scale || 1.0;
        const ar2 = (m.image?.height || 600) / (m.image?.width || 800);
        const arRefBB = stk.ref_ar || ar2, sxAdjBB = stk.scale_x_adj || 1.0;
        const rot2 = (stk.rotation || 0) * Math.PI / 180;
        const bbPt = (px, py) => {
          const dx = (px - 0.5) * sc2 * sxAdjBB, dy = (py - 0.5) * sc2 * arRefBB;
          const rx = dx * Math.cos(rot2) - dy * Math.sin(rot2), ry = dx * Math.sin(rot2) + dy * Math.cos(rot2);
          return [(0.5 + ox2) + rx, arRefBB * (0.5 + oy2) + ry];
        };
        for (const [cx, cy] of [[0, 0], [1, 0], [1, 1], [0, 1]]) {
          const [wx, wy] = bbPt(cx, cy);
          x0 = Math.min(x0, wx); y0_ = Math.min(y0_, wy); x1 = Math.max(x1, wx); y1_ = Math.max(y1_, wy);
        }
      }
      if (!isFinite(x0)) { x0 = 0; y0_ = 0; x1 = 1; y1_ = 0.75; }

      const TL = iso(x0, y0_, z), TR = iso(x1, y0_, z), BR = iso(x1, y1_, z), BL = iso(x0, y1_, z);
      const TR_b = iso(x1, y0_, z - slabWZ), BR_b = iso(x1, y1_, z - slabWZ), BL_b = iso(x0, y1_, z - slabWZ);

      s += `<g opacity="${go}">`;
      s += `<polygon points="${pts([TR, BR, BR_b, TR_b])}" fill="#0d2318" fill-opacity="0.35" stroke="#253e2e" stroke-width="0.8"/>`;
      s += `<polygon points="${pts([BL, BR, BR_b, BL_b])}" fill="#0a1a12" fill-opacity="0.3" stroke="#253e2e" stroke-width="0.8"/>`;
      s += `<polygon points="${pts([TL, TR, BR, BL])}" fill="#0f2017" fill-opacity="0.06" stroke="${lyrColor}" stroke-width="1.5" stroke-dasharray="10,5" opacity="0.5"/>`;
      if (lidx !== 1) { s += `<polygon points="${pts([TL, TR, BR, BL])}" fill="url(#tpat_${lidx})" stroke="none"/>`; }

      // Room polygons + labels
      for (const m of group) {
        const xf = mapXforms[m.id]; if (!xf) continue;
        for (const [room, b] of Object.entries(m.room_bounds || {})) {
          if (!b || b.type !== "poly" || !Array.isArray(b.points) || b.points.length < 3) continue;
          const color = roomColorFn(room);
          const pp = b.points.map(p => { const [wx, wy] = xf.mapPt(p[0], p[1]); return pt(iso(wx, wy, z)); }).join(" ");
          s += `<polygon points="${pp}" fill="${color}" fill-opacity="0.2" stroke="${color}" stroke-width="1.5" opacity="0.9"/>`;
          const cx2 = b.points.reduce((a, p) => a + p[0], 0) / b.points.length;
          const cy2 = b.points.reduce((a, p) => a + p[1], 0) / b.points.length;
          const [lwx, lwy] = xf.mapPt(cx2, cy2);
          const [lix, liy] = iso(lwx, lwy, z);
          s += `<text x="${Math.round(lix)}" y="${Math.round(liy) + lidx * 2}" text-anchor="middle" dominant-baseline="middle" fill="${color}" font-size="7">${_esc(room)}</text>`;
        }

        // Receiver markers (draggable)
        const draft = ts.draftReceivers[m.id] || [];
        for (const r of draft) {
          const [wx, wy] = xf.mapPt(r.x || 0, r.y || 0);
          const [px, py] = iso(wx, wy, z);
          const isSel = ts.selectedRx && ts.selectedRx.mapId === m.id && ts.selectedRx.rxId === r.id;
          const rx = Math.round(px), ry = Math.round(py);
          const lbl = (r.label || r.id || "R").substring(0, 6);
          const tip = `${r.label || r.id || "Receiver"}${r.room ? " | Room: " + r.room : ""} | x: ${(r.x * 100).toFixed(1)}% y: ${(r.y * 100).toFixed(1)}%`;

          s += `<g data-rx-id="${_esc(r.id)}" data-map-id="${_esc(m.id)}" data-z="${z}" data-tip="${_esc(tip)}" style="cursor:grab">`;
          // Selection highlight
          if (isSel) s += `<circle cx="${rx}" cy="${ry}" r="22" fill="none" stroke="#fbbf24" stroke-width="2" stroke-dasharray="4,3" opacity="0.9"/>`;
          // Outer pulse ring
          s += `<circle cx="${rx}" cy="${ry}" r="16" fill="none" stroke="#52b788" stroke-width="1.2" opacity="0.35"/>`;
          // Middle ring
          s += `<circle cx="${rx}" cy="${ry}" r="10" fill="none" stroke="#52b788" stroke-width="1.8" opacity="0.7"/>`;
          // Center dot
          s += `<circle cx="${rx}" cy="${ry}" r="5" fill="#52b788" opacity="0.95"/>`;
          // Label below
          const lblW = Math.min(lbl.length * 7 + 8, 60);
          s += `<rect x="${rx - lblW / 2}" y="${ry + 18}" width="${lblW}" height="13" rx="3" fill="#071008" opacity="0.8"/>`;
          s += `<text x="${rx}" y="${ry + 28}" text-anchor="middle" fill="#52b788" font-size="9" font-weight="600">${_esc(lbl)}</text>`;
          s += `</g>`;
        }
      }

      // Layer index dot
      s += `<circle cx="${Math.round(BL[0])}" cy="${Math.round(BL[1])}" r="15" fill="${lyrColor}" opacity="0.95"/>`;
      s += `<text x="${Math.round(BL[0])}" y="${Math.round(BL[1]) + 6}" text-anchor="middle" fill="#071008" font-size="14" font-weight="700">${lidx + 1}</text>`;
      s += `</g>`;
    }

    // Legend
    s += `<line x1="10" y1="${BASE_H + 4}" x2="${W - 10}" y2="${BASE_H + 4}" stroke="#1b3526" stroke-width="0.8"/>`;
    sortedIsoLevels.forEach((z, i) => {
      const ly = BASE_H + 10 + i * 30;
      const color = levelColor(z);
      const groupLabel = byLevel.get(z).map(m => m.name || m.id).join(" + ");
      s += `<circle cx="18" cy="${ly + 11}" r="11" fill="${color}" opacity="0.9"/>`;
      s += `<text x="18" y="${ly + 15}" text-anchor="middle" fill="#071008" font-size="12" font-weight="700">${i + 1}</text>`;
      s += `<text x="36" y="${ly + 15}" fill="${color}" font-size="18" font-weight="500">${_esc(groupLabel)}</text>`;
    });

    s += `</svg>`;
    return s;
  };

  // ── DOM: SVG container ──────────────────────────────────────────────────────
  const isoWrap = document.createElement("div");
  isoWrap.style.cssText = "position:relative;margin-top:6px";

  const isoDiv = document.createElement("div");
  isoDiv.style.cssText = "overflow:auto;border-radius:8px;background:#071008;padding:8px";
  isoDiv.innerHTML = buildTuneSVG(_getFocusZ(ts.focusIdx));

  // Hover tooltip
  const tipEl = document.createElement("div");
  tipEl.style.cssText = "position:absolute;top:8px;left:8px;background:rgba(7,16,8,0.92);" +
    "border:1px solid #2d6a4f;border-radius:8px;padding:6px 10px;font-size:11px;color:#a7f3d0;" +
    "pointer-events:none;white-space:pre-line;max-width:min(260px,calc(100vw - 40px));z-index:5;display:none;" +
    "font-family:ui-monospace,SFMono-Regular,Consolas,monospace;line-height:1.5";
  isoWrap.appendChild(isoDiv);
  isoWrap.appendChild(tipEl);

  isoDiv.addEventListener("mouseover", e => {
    const g = e.target.closest("[data-tip]");
    if (g) {
      tipEl.textContent = "";
      g.getAttribute("data-tip").split("|").forEach((line, i) => {
        if (i > 0) tipEl.appendChild(document.createElement("br"));
        tipEl.appendChild(document.createTextNode(line));
      });
      tipEl.style.display = "block";
    }
  });
  isoDiv.addEventListener("mouseout", e => {
    const g = e.target.closest("[data-tip]");
    if (!g || !isoDiv.contains(e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest("[data-tip]")))
      tipEl.style.display = "none";
  });

  // ── Drag interaction ────────────────────────────────────────────────────────
  let _dragging = null; // {mapId, rxId, z, svgEl}

  isoDiv.addEventListener("pointerdown", e => {
    const g = e.target.closest("[data-rx-id]");
    if (!g) return;
    e.preventDefault();
    const mapId = g.getAttribute("data-map-id");
    const rxId = g.getAttribute("data-rx-id");
    const z = Number(g.getAttribute("data-z") || 0);
    ts.selectedRx = { mapId, rxId };
    _dragging = { mapId, rxId, z };
    isoDiv.setPointerCapture(e.pointerId);
    isoDiv.style.cursor = "grabbing";
    // Update selection highlight
    _refreshSVG();
    _refreshInfo();
  });

  isoDiv.addEventListener("pointermove", e => {
    if (!_dragging) return;
    e.preventDefault();
    const svgNode = isoDiv.querySelector("svg");
    if (!svgNode) return;

    // Convert client coords → SVG coords using getScreenCTM
    const ctm = svgNode.getScreenCTM();
    if (!ctm) return;
    const inv = ctm.inverse();
    const sx = e.clientX * inv.a + e.clientY * inv.c + inv.e;
    const sy = e.clientX * inv.b + e.clientY * inv.d + inv.f;

    // SVG coords → world coords (at this floor's z-level)
    const [wx, wy] = invIso(sx, sy, _dragging.z);

    // World coords → normalized image coords for this map
    const xf = mapXforms[_dragging.mapId];
    if (!xf) return;
    const [nx, ny] = xf.invMapPt(wx, wy);

    // Clamp to [0, 1]
    const cx = Math.max(0, Math.min(1, nx));
    const cy = Math.max(0, Math.min(1, ny));

    // Update draft
    const draft = ts.draftReceivers[_dragging.mapId];
    if (!draft) return;
    const rx = draft.find(r => r.id === _dragging.rxId);
    if (!rx) return;
    rx.x = cx;
    rx.y = cy;
    ts.dirtyMaps[_dragging.mapId] = true;

    // Re-render SVG for live feedback
    _refreshSVG();
    _refreshInfo();
  });

  isoDiv.addEventListener("pointerup", e => {
    if (_dragging) {
      _dragging = null;
      isoDiv.releasePointerCapture(e.pointerId);
      isoDiv.style.cursor = "";
      _refreshDirtyLabel();
    }
  });

  // Click to select (without drag)
  isoDiv.addEventListener("click", e => {
    if (_dragging) return;
    const g = e.target.closest("[data-rx-id]");
    if (g) {
      ts.selectedRx = { mapId: g.getAttribute("data-map-id"), rxId: g.getAttribute("data-rx-id") };
      _refreshSVG();
      _refreshInfo();
    }
  });

  // ── Helper: rebuild SVG without losing scroll ─────────────────────────────
  function _refreshSVG() {
    const scrollTop = isoDiv.scrollTop, scrollLeft = isoDiv.scrollLeft;
    isoDiv.innerHTML = buildTuneSVG(_getFocusZ(ts.focusIdx));
    isoDiv.scrollTop = scrollTop;
    isoDiv.scrollLeft = scrollLeft;
  }

  // ── Controls row ──────────────────────────────────────────────────────────
  const ctrlRow = document.createElement("div");
  ctrlRow.style.cssText = "display:flex;align-items:center;gap:10px;flex-wrap:wrap";

  // Floor focus
  const focusLbl = document.createElement("span");
  focusLbl.style.cssText = "font-size:12px;color:#94a3b8;min-width:80px;display:inline-block";
  focusLbl.textContent = _getFocusLbl(ts.focusIdx);
  const focusSlider = document.createElement("input");
  focusSlider.type = "range"; focusSlider.min = "0"; focusSlider.max = String(_isoPos.length - 1);
  focusSlider.style.cssText = "width:130px;accent-color:#52b788;vertical-align:middle;cursor:pointer";
  focusSlider.value = String(ts.focusIdx);
  focusSlider.addEventListener("input", () => {
    ts.focusIdx = parseInt(focusSlider.value, 10);
    focusLbl.textContent = _getFocusLbl(ts.focusIdx);
    _refreshSVG();
  });

  const floorLbl = document.createElement("span");
  floorLbl.style.cssText = "font-size:12px;color:#94a3b8";
  floorLbl.textContent = "Floor:";
  ctrlRow.appendChild(floorLbl);
  ctrlRow.appendChild(focusSlider);
  ctrlRow.appendChild(focusLbl);

  // Spacing slider
  const gapLbl = document.createElement("span");
  gapLbl.style.cssText = "font-size:12px;color:#94a3b8;min-width:36px;display:inline-block;text-align:right";
  gapLbl.textContent = String(ts.fg);
  const gapSlider = document.createElement("input");
  gapSlider.type = "range"; gapSlider.min = "60"; gapSlider.max = "340"; gapSlider.step = "10";
  gapSlider.style.cssText = "width:110px;accent-color:#52b788;vertical-align:middle;cursor:pointer";
  gapSlider.value = String(ts.fg);
  gapSlider.addEventListener("input", () => {
    ts.fg = parseInt(gapSlider.value, 10);
    _fg = ts.fg;
    gapLbl.textContent = String(ts.fg);
    _refreshSVG();
  });
  const spacingLbl = document.createElement("span");
  spacingLbl.style.cssText = "font-size:12px;color:#94a3b8;margin-left:8px";
  spacingLbl.textContent = "Spacing:";
  ctrlRow.appendChild(spacingLbl);
  ctrlRow.appendChild(gapSlider);
  ctrlRow.appendChild(gapLbl);

  // L/R slider
  const hgLbl = document.createElement("span");
  hgLbl.style.cssText = "font-size:12px;color:#94a3b8;min-width:36px;display:inline-block;text-align:right";
  hgLbl.textContent = String(ts.hg);
  const hgSlider = document.createElement("input");
  hgSlider.type = "range"; hgSlider.min = "-120"; hgSlider.max = "120"; hgSlider.step = "10";
  hgSlider.style.cssText = "width:110px;accent-color:#52b788;vertical-align:middle;cursor:pointer";
  hgSlider.value = String(ts.hg);
  hgSlider.addEventListener("input", () => {
    ts.hg = parseInt(hgSlider.value, 10);
    _hg = ts.hg;
    hgLbl.textContent = String(ts.hg);
    _refreshSVG();
  });
  const lrLbl = document.createElement("span");
  lrLbl.style.cssText = "font-size:12px;color:#94a3b8;margin-left:8px";
  lrLbl.textContent = "L/R:";
  ctrlRow.appendChild(lrLbl);
  ctrlRow.appendChild(hgSlider);
  ctrlRow.appendChild(hgLbl);

  // Save button
  const statusLbl = document.createElement("span");
  statusLbl.style.cssText = "font-size:11px;color:#94a3b8;min-width:90px";
  const saveBtn = document.createElement("button");
  saveBtn.className = "btn inline";
  saveBtn.style.cssText = "padding:2px 10px;font-size:12px";
  saveBtn.textContent = "Save";
  saveBtn.title = "Save updated receiver positions to all modified maps";
  saveBtn.addEventListener("click", async () => {
    const dirtyIds = Object.keys(ts.dirtyMaps).filter(id => ts.dirtyMaps[id]);
    if (!dirtyIds.length) { statusLbl.textContent = "No changes"; setTimeout(() => { statusLbl.textContent = ""; }, 2000); return; }
    saveBtn.disabled = true;
    statusLbl.textContent = "Saving...";
    try {
      for (const mapId of dirtyIds) {
        const origMap = maps_list.find(m => m.id === mapId);
        if (!origMap) continue;
        await ctx.actions.mapsUpdate({
          map_id: mapId,
          receivers: ts.draftReceivers[mapId],
          calibration: origMap.calibration || {},
          notes: origMap.notes || "",
        });
      }
      ts.dirtyMaps = {};
      // Update stamp so we don't re-sync over our own save
      const freshMaps = (ctx.state.maps && ctx.state.maps.list) ? ctx.state.maps.list : [];
      ts._mapsStamp = freshMaps.map(m => `${m.id}:${m.updated||""}:${(m.receivers||[]).length}`).join("|");
      statusLbl.textContent = "Saved ✓";
      ctx.toast("Receiver positions saved");
      setTimeout(() => { statusLbl.textContent = ""; }, 2500);
      _refreshDirtyLabel();
    } catch (e) {
      statusLbl.textContent = "Error saving";
      ctx.toast("Save failed: " + String(e), true);
    }
    saveBtn.disabled = false;
  });

  // Reset button
  const resetBtn = document.createElement("button");
  resetBtn.className = "btn inline";
  resetBtn.style.cssText = "padding:2px 10px;font-size:12px";
  resetBtn.textContent = "Reset";
  resetBtn.title = "Discard unsaved changes and reload receiver positions";
  resetBtn.addEventListener("click", () => {
    ts.draftReceivers = {};
    for (const m of maps_list) {
      ts.draftReceivers[m.id] = (m.receivers || []).map(r => ({
        id: r.id || "", label: r.label || "", x: Number(r.x || 0), y: Number(r.y || 0), room: r.room || "", source: r.source || ""
      }));
    }
    ts.dirtyMaps = {};
    ts.selectedRx = null;
    ts.fg = ctx.state.settings?.overview_iso_floor_gap ?? 150;
    ts.hg = ctx.state.settings?.overview_iso_horiz_gap ?? 0;
    ts.focusIdx = 0;
    _fg = ts.fg; _hg = ts.hg;
    gapSlider.value = String(ts.fg); gapLbl.textContent = String(ts.fg);
    hgSlider.value = String(ts.hg); hgLbl.textContent = String(ts.hg);
    focusSlider.value = "0"; focusLbl.textContent = "All floors";
    statusLbl.textContent = "Reset ✓";
    setTimeout(() => { statusLbl.textContent = ""; }, 2000);
    _refreshSVG();
    _refreshInfo();
    _refreshDirtyLabel();
  });

  ctrlRow.appendChild(saveBtn);
  ctrlRow.appendChild(resetBtn);
  ctrlRow.appendChild(statusLbl);

  // Dirty indicator
  const dirtyLbl = document.createElement("span");
  dirtyLbl.style.cssText = "font-size:11px;color:#f59e0b;font-weight:600;margin-left:auto";
  function _refreshDirtyLabel() {
    const n = Object.keys(ts.dirtyMaps).filter(id => ts.dirtyMaps[id]).length;
    dirtyLbl.textContent = n ? `${n} map${n > 1 ? "s" : ""} unsaved` : "";
  }
  _refreshDirtyLabel();
  ctrlRow.appendChild(dirtyLbl);

  // ── Selected receiver info panel ──────────────────────────────────────────
  const infoCard = document.createElement("div");
  infoCard.style.cssText = "background:#0d1f14;border:1px solid #1b3526;border-radius:8px;padding:10px 14px;font-size:12px;color:#a7f3d0;min-height:24px";
  function _refreshInfo() {
    if (!ts.selectedRx) {
      infoCard.textContent = "Click a receiver marker to select it, then drag to reposition.";
      return;
    }
    const draft = ts.draftReceivers[ts.selectedRx.mapId] || [];
    const rx = draft.find(r => r.id === ts.selectedRx.rxId);
    if (!rx) { infoCard.textContent = "Receiver not found."; return; }
    const mapObj = maps_list.find(m => m.id === ts.selectedRx.mapId);
    infoCard.innerHTML = "";
    const lines = [
      `<b style="color:#52b788">${_esc(rx.label || rx.id)}</b>`,
      `Map: ${_esc(mapObj?.name || ts.selectedRx.mapId)}`,
      `Room: ${_esc(rx.room || "—")}`,
      `Position: x ${(rx.x * 100).toFixed(1)}%, y ${(rx.y * 100).toFixed(1)}%`,
    ];
    infoCard.innerHTML = lines.join(" &nbsp;·&nbsp; ");
  }
  _refreshInfo();

  // ── Unplaced radios list ──────────────────────────────────────────────────
  const unplacedCard = document.createElement("div");
  unplacedCard.className = "card";
  function _refreshUnplaced() {
    unplacedCard.innerHTML = "";
    // Gather all placed receiver ids/labels across all maps
    const placedIds = new Set();
    const placedLabels = new Set();
    for (const recs of Object.values(ts.draftReceivers)) {
      for (const r of recs) {
        if (r.id) placedIds.add(r.id);
        if (r.source) placedIds.add(r.source);
        if (r.label) placedLabels.add(r.label);
      }
    }
    // Find live radios not yet placed on any map
    const unplaced = _liveRadios.filter(rd => {
      const src = rd.source || "";
      const nm = rd.name || "";
      return !placedIds.has(src) && !placedLabels.has(nm);
    });
    if (!unplaced.length) { unplacedCard.style.display = "none"; return; }
    unplacedCard.style.display = "";
    const hdr = document.createElement("div");
    hdr.style.cssText = "font-weight:700;font-size:13px;margin-bottom:8px;color:#52b788";
    hdr.textContent = `Unplaced Radios (${unplaced.length})`;
    unplacedCard.appendChild(hdr);
    const hint = document.createElement("div");
    hint.style.cssText = "font-size:11px;color:#94a3b8;margin-bottom:8px";
    hint.textContent = "Click a radio to place it on a map at the center. Drag to reposition after placing.";
    unplacedCard.appendChild(hint);

    for (const rd of unplaced) {
      const row = document.createElement("div");
      row.style.cssText = "display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:6px;cursor:pointer;transition:background 0.15s";
      row.addEventListener("mouseenter", () => { row.style.background = "#0d2818"; });
      row.addEventListener("mouseleave", () => { row.style.background = ""; });
      // Green circle icon
      const icon = document.createElement("div");
      icon.style.cssText = "width:14px;height:14px;border-radius:50%;border:2px solid #52b788;background:rgba(82,183,136,0.2);flex-shrink:0;display:flex;align-items:center;justify-content:center";
      const dot = document.createElement("div");
      dot.style.cssText = "width:6px;height:6px;border-radius:50%;background:#52b788";
      icon.appendChild(dot);
      row.appendChild(icon);
      const lbl = document.createElement("span");
      lbl.style.cssText = "flex:1;font-size:12px;color:#d1d5db";
      const area = rd.area_name ? ` (${rd.area_name})` : "";
      lbl.textContent = `${rd.name || rd.source || "Unknown"}${area}`;
      row.appendChild(lbl);
      const placeBtn = document.createElement("button");
      placeBtn.className = "btn inline";
      placeBtn.style.cssText = "font-size:11px;padding:2px 10px;color:#52b788;border-color:#52b788";
      placeBtn.textContent = "Place";

      // Map picker for this radio
      const mapPick = document.createElement("select");
      mapPick.style.cssText = "font-size:11px;max-width:120px;";
      for (const m of sorted.length ? sorted : maps_list) {
        const opt = document.createElement("option");
        opt.value = m.id;
        opt.textContent = (m.name || m.id).substring(0, 20);
        mapPick.appendChild(opt);
      }
      row.appendChild(mapPick);

      placeBtn.addEventListener("click", (ev) => {
        ev.stopPropagation();
        const targetMapId = mapPick.value;
        if (!targetMapId) return;
        const newRx = {
          id: rd.source || rd.name || ("rx_" + Math.random().toString(16).slice(2, 10)),
          label: rd.name || rd.source || "",
          x: 0.5,
          y: 0.5,
          room: rd.area_name || "",
          source: rd.source || "",
        };
        if (!ts.draftReceivers[targetMapId]) ts.draftReceivers[targetMapId] = [];
        ts.draftReceivers[targetMapId].push(newRx);
        ts.dirtyMaps[targetMapId] = true;
        ts.selectedRx = { mapId: targetMapId, rxId: newRx.id };
        _refreshSVG();
        _refreshInfo();
        _refreshDirtyLabel();
        _refreshUnplaced();
      });
      row.addEventListener("click", () => { placeBtn.click(); });
      row.appendChild(placeBtn);
      unplacedCard.appendChild(row);
    }
  }
  _refreshUnplaced();

  // ── Assemble ──────────────────────────────────────────────────────────────
  wrap.appendChild(ctrlRow);
  wrap.appendChild(isoWrap);
  wrap.appendChild(infoCard);
  wrap.appendChild(unplacedCard);

  return wrap;
}

function _detectRoom(x, y, mapData) {
  const bounds = mapData?.room_bounds || {};
  for (const [room, b] of Object.entries(bounds)) {
    if (b.type === "poly" && _pointInPoly(x, y, b.points)) return room;
    if (b.type === "circle") {
      const dx = x - b.cx, dy = y - b.cy;
      if (Math.sqrt(dx * dx + dy * dy) <= b.r) return room;
    }
  }
  return "";
}

// ── Beacon Tune tab — 3D iso map with draggable beacon markers ───────────────
function _beaconTuneTab(ctx, el, cs, calData) {
  const wrap = el("div", { style: "display:flex;flex-direction:column;gap:10px" });
  const snap = (ctx.state.live && ctx.state.live.snapshot) || null;
  const maps_list = (ctx.state.maps && ctx.state.maps.list) ? ctx.state.maps.list : [];

  if (!maps_list.length) {
    wrap.appendChild(el("div", { class: "card" }, [
      el("div", { style: "font-weight:700;font-size:14px;margin-bottom:6px;color:#52b788" }, "No Maps Uploaded"),
      el("div", { style: "font-size:12px;color:#94a3b8" },
        "Upload floor plan images in the Maps tab first, then return here to pin beacons on your floor plans."),
    ]));
    return wrap;
  }

  // ── Experimental badge + explainer ────────────────────────────────────
  wrap.appendChild(el("div", { class: "card", style: "border-color:#f59e0b" }, [
    el("div", { style: "display:flex;align-items:center;gap:8px;margin-bottom:6px" }, [
      el("span", { style: "background:#f59e0b;color:#000;font-weight:700;font-size:11px;padding:2px 8px;border-radius:4px" }, "EXPERIMENTAL"),
      el("span", { style: "font-weight:700;font-size:14px;color:#f59e0b" }, "Beacon Tune"),
    ]),
    el("div", { style: "font-size:12px;color:#94a3b8;line-height:1.5" },
      "Pin stationary beacons (AirTags, Tiles, key fobs) at their physical locations on the 3D floor stack. Drag teal diamonds to position. Green circles show scanner positions for reference."),
  ]));

  // ── Constants & state ─────────────────────────────────────────────────────
  const TILE = 220, CX = 380, CY = 590, W = 760, BASE_H = 940;
  const LAYER_PAL = ["#52b788","#f59e0b","#60a5fa","#e879f9","#fb923c","#34d399","#f87171","#a78bfa"];
  const _esc = s => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  const roomColorFn = ctx.helpers.roomColor || (name => {
    let h = 0; const s = String(name || "");
    for (let i = 0; i < s.length; i++) { h = Math.imul(h ^ s.charCodeAt(i), 16777619); }
    return `hsl(${(h >>> 0) % 360} 70% 55%)`;
  });

  if (!ctx.state._calibBeacon) ctx.state._calibBeacon = {
    fg: ctx.state.settings?.overview_iso_floor_gap ?? 150,
    hg: ctx.state.settings?.overview_iso_horiz_gap ?? 0,
    focusIdx: 0,
    draftBeacons: {},    // mapId → [{id, label, key, kind, x, y}]
    dirtyMaps: {},       // mapId → true
    selectedBk: null,    // {mapId, bkId}
    _mapsStamp: null,
  };
  const bs = ctx.state._calibBeacon;

  // Build stamp and sync draft beacons from maps data
  const mapsStamp = maps_list.map(m => `${m.id}:${m.updated||""}:${(m.beacons||[]).length}`).join("|");
  const hasDirty = Object.values(bs.dirtyMaps).some(Boolean);
  if (!Object.keys(bs.draftBeacons).length || (mapsStamp !== bs._mapsStamp && !hasDirty)) {
    for (const m of maps_list) {
      bs.draftBeacons[m.id] = (m.beacons || []).map(bk => ({
        id: bk.id || "", label: bk.label || "", key: bk.key || "",
        kind: bk.kind || "", x: Number(bk.x || 0), y: Number(bk.y || 0),
      }));
    }
    for (const id of Object.keys(bs.draftBeacons)) {
      if (!maps_list.find(m => m.id === id)) delete bs.draftBeacons[id];
    }
    bs._mapsStamp = mapsStamp;
  }

  let _fg = bs.fg, _hg = bs.hg;

  // ── Transforms ────────────────────────────────────────────────────────────
  const iso = (wx, wy, wz) => [CX + (wx - wy) * TILE * 0.866 + wz * _hg, CY + (wx + wy) * TILE * 0.5 - wz * _fg];
  const pt  = c => `${Math.round(c[0])},${Math.round(c[1])}`;
  const pts = cs2 => cs2.map(pt).join(" ");

  const invIso = (sx, sy, z) => {
    const ax = sx - CX - z * _hg;
    const ay = sy - CY + z * _fg;
    const A = TILE * 0.866, B = TILE * 0.5;
    const wx = (ax / A + ay / B) / 2;
    const wy = (ay / B - ax / A) / 2;
    return [wx, wy];
  };

  // Filter & sort maps
  const hiddenIds = ctx.state.maps._hiddenMapIds || new Set();
  const sorted = [...maps_list].filter(m => !hiddenIds.has(m.id)).sort((a, b) => (a.stack?.z_level || 0) - (b.stack?.z_level || 0));
  const byLevel = new Map();
  for (const m of sorted) { const z = m.stack?.z_level ?? 0; if (!byLevel.has(z)) byLevel.set(z, []); byLevel.get(z).push(m); }
  const sortedIsoLevels = [...byLevel.keys()].sort((a, b) => a - b);
  const levelColor = z => LAYER_PAL[sortedIsoLevels.indexOf(z) % LAYER_PAL.length];

  // Floor focus slider positions
  const _isoPos = [null];
  for (let i = 0; i < sortedIsoLevels.length; i++) {
    _isoPos.push(sortedIsoLevels[i]);
    if (i < sortedIsoLevels.length - 1) _isoPos.push([sortedIsoLevels[i], sortedIsoLevels[i + 1]]);
  }
  bs.focusIdx = Math.max(0, Math.min(bs.focusIdx, _isoPos.length - 1));
  const _getFocusZ = idx => _isoPos[Math.max(0, Math.min(idx, _isoPos.length - 1))];
  const _getFocusLbl = idx => {
    const pos = _getFocusZ(idx);
    if (pos === null) return "All floors";
    const fl = ctx.state.model?.floors || [];
    const zArr = Array.isArray(pos) ? pos : [pos];
    return zArr.map(z => { const f = fl.find(x => x.level === z); return f ? (f.name || `L${z}`) : `L${z}`; }).join(" + ");
  };

  // Per-map forward+inverse transforms
  const mapXforms = {};
  for (const m of sorted) {
    const stk = m.stack || {}, z = stk.z_level || 0, ox = stk.x_offset || 0, oy_ = stk.y_offset || 0, sc = stk.scale || 1.0;
    const ar = (m.image?.height || 600) / (m.image?.width || 800);
    const arRef = stk.ref_ar || ar, sxAdj = stk.scale_x_adj || 1.0;
    const rotRad = (stk.rotation || 0) * Math.PI / 180;
    const cosR = Math.cos(rotRad), sinR = Math.sin(rotRad);
    mapXforms[m.id] = {
      z, ox, oy_, sc, arRef, sxAdj, cosR, sinR,
      mapPt: (px, py) => {
        const dx = (px - 0.5) * sc * sxAdj, dy = (py - 0.5) * sc * arRef;
        const rx = dx * cosR - dy * sinR, ry = dx * sinR + dy * cosR;
        return [(0.5 + ox) + rx, arRef * (0.5 + oy_) + ry];
      },
      invMapPt: (wx, wy) => {
        const rx = wx - (0.5 + ox);
        const ry = wy - arRef * (0.5 + oy_);
        const dx =  rx * cosR + ry * sinR;
        const dy = -rx * sinR + ry * cosR;
        return [dx / (sc * sxAdj) + 0.5, dy / (sc * arRef) + 0.5];
      },
    };
  }

  // ── Build SVG ───────────────────────────────────────────────────────────────
  const LEGEND_H = sortedIsoLevels.length * 30 + 24;
  const buildBeaconSVG = (focusZ) => {
    const slabWZ = 18 / _fg;
    const maxIsoZ = sortedIsoLevels.length ? sortedIsoLevels[sortedIsoLevels.length - 1] : 0;
    const viewY = Math.min(0, CY - maxIsoZ * _fg - 50);
    const HTOTAL = BASE_H + LEGEND_H - viewY;
    let s = `<svg viewBox="0 ${viewY} ${W} ${HTOTAL}" xmlns="http://www.w3.org/2000/svg" width="100%" style="max-height:${HTOTAL}px;display:block;font-family:system-ui,sans-serif">`;
    s += `<rect x="0" y="${viewY}" width="${W}" height="${HTOTAL}" fill="#071008"/>`;

    // Floor patterns
    s += `<defs>`;
    sortedIsoLevels.forEach((z2, li) => {
      const c2 = levelColor(z2);
      if (li === 0) {
        s += `<pattern id="bpat_${li}" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">`;
        s += `<path d="M12,2 C16,2 19,6 19,11 C19,16 16,21 12,22 C8,21 5,16 5,11 C5,6 8,2 12,2 Z" fill="none" stroke="${c2}" stroke-width="0.7" opacity="0.14"/>`;
        s += `<path d="M12,2 C13.5,0 15.5,0.5 14.5,2.5 C13.5,1.5 12,2 12,2 Z" fill="${c2}" opacity="0.11"/>`;
        s += `<circle cx="12" cy="15" r="1.4" fill="${c2}" opacity="0.1"/>`;
        s += `</pattern>`;
      } else if (li === 2) {
        s += `<pattern id="bpat_${li}" x="0" y="0" width="12" height="12" patternUnits="userSpaceOnUse">`;
        s += `<line x1="0" y1="12" x2="12" y2="0" stroke="${c2}" stroke-width="0.6" opacity="0.18"/>`;
        s += `<line x1="0" y1="0" x2="12" y2="12" stroke="${c2}" stroke-width="0.6" opacity="0.18"/>`;
        s += `</pattern>`;
      } else if (li >= 3) {
        s += `<pattern id="bpat_${li}" x="0" y="0" width="16" height="13.86" patternUnits="userSpaceOnUse">`;
        s += `<circle cx="0" cy="0" r="1.5" fill="${c2}" opacity="0.14"/>`;
        s += `<circle cx="8" cy="6.93" r="1.5" fill="${c2}" opacity="0.14"/>`;
        s += `<circle cx="16" cy="0" r="1.5" fill="${c2}" opacity="0.14"/>`;
        s += `<circle cx="0" cy="13.86" r="1.5" fill="${c2}" opacity="0.14"/>`;
        s += `<circle cx="16" cy="13.86" r="1.5" fill="${c2}" opacity="0.14"/>`;
        s += `</pattern>`;
      }
    });
    s += `</defs>`;

    if (!sorted.length) {
      s += `<text x="${W / 2}" y="${BASE_H / 2}" text-anchor="middle" fill="#4a6052" font-size="13">All layers hidden</text>`;
      s += `</svg>`; return s;
    }

    // Floor slabs + room polygons + receivers (reference) + beacons (draggable)
    for (const [z, group] of [...byLevel.entries()].sort((a, b) => a[0] - b[0])) {
      const isFocused = focusZ === null || (Array.isArray(focusZ) ? focusZ.includes(z) : focusZ === z);
      const go = isFocused ? 1.0 : 0.1;
      const lyrColor = levelColor(z);
      const lidx = sortedIsoLevels.indexOf(z);

      // Bounding box for all maps at this level
      let x0 = Infinity, y0_ = Infinity, x1 = -Infinity, y1_ = -Infinity;
      for (const m of group) {
        const xf = mapXforms[m.id]; if (!xf) continue;
        const stk = m.stack || {}, ox2 = stk.x_offset || 0, oy2 = stk.y_offset || 0, sc2 = stk.scale || 1.0;
        const ar2 = (m.image?.height || 600) / (m.image?.width || 800);
        const arRefBB = stk.ref_ar || ar2, sxAdjBB = stk.scale_x_adj || 1.0;
        const rot2 = (stk.rotation || 0) * Math.PI / 180;
        const bbPt = (px, py) => {
          const dx = (px - 0.5) * sc2 * sxAdjBB, dy = (py - 0.5) * sc2 * arRefBB;
          const rx = dx * Math.cos(rot2) - dy * Math.sin(rot2), ry = dx * Math.sin(rot2) + dy * Math.cos(rot2);
          return [(0.5 + ox2) + rx, arRefBB * (0.5 + oy2) + ry];
        };
        for (const [cx2, cy2] of [[0, 0], [1, 0], [1, 1], [0, 1]]) {
          const [wx, wy] = bbPt(cx2, cy2);
          x0 = Math.min(x0, wx); y0_ = Math.min(y0_, wy); x1 = Math.max(x1, wx); y1_ = Math.max(y1_, wy);
        }
      }
      if (!isFinite(x0)) { x0 = 0; y0_ = 0; x1 = 1; y1_ = 0.75; }

      const TL = iso(x0, y0_, z), TR = iso(x1, y0_, z), BR = iso(x1, y1_, z), BL = iso(x0, y1_, z);
      const TR_b = iso(x1, y0_, z - slabWZ), BR_b = iso(x1, y1_, z - slabWZ), BL_b = iso(x0, y1_, z - slabWZ);

      s += `<g opacity="${go}">`;
      // 3D slab sides
      s += `<polygon points="${pts([TR, BR, BR_b, TR_b])}" fill="#0d2318" fill-opacity="0.35" stroke="#253e2e" stroke-width="0.8"/>`;
      s += `<polygon points="${pts([BL, BR, BR_b, BL_b])}" fill="#0a1a12" fill-opacity="0.3" stroke="#253e2e" stroke-width="0.8"/>`;
      // Top face
      s += `<polygon points="${pts([TL, TR, BR, BL])}" fill="#0f2017" fill-opacity="0.06" stroke="${lyrColor}" stroke-width="1.5" stroke-dasharray="10,5" opacity="0.5"/>`;
      if (lidx !== 1) { s += `<polygon points="${pts([TL, TR, BR, BL])}" fill="url(#bpat_${lidx})" stroke="none"/>`; }

      // Room polygons + labels
      for (const m of group) {
        const xf = mapXforms[m.id]; if (!xf) continue;
        for (const [room, b] of Object.entries(m.room_bounds || {})) {
          if (!b || b.type !== "poly" || !Array.isArray(b.points) || b.points.length < 3) continue;
          const color = roomColorFn(room);
          const pp = b.points.map(p => { const [wx, wy] = xf.mapPt(p[0], p[1]); return pt(iso(wx, wy, z)); }).join(" ");
          s += `<polygon points="${pp}" fill="${color}" fill-opacity="0.2" stroke="${color}" stroke-width="1.5" opacity="0.9"/>`;
          const rcx = b.points.reduce((a, p) => a + p[0], 0) / b.points.length;
          const rcy = b.points.reduce((a, p) => a + p[1], 0) / b.points.length;
          const [lwx, lwy] = xf.mapPt(rcx, rcy);
          const [lix, liy] = iso(lwx, lwy, z);
          s += `<text x="${Math.round(lix)}" y="${Math.round(liy) + lidx * 2}" text-anchor="middle" dominant-baseline="middle" fill="${color}" font-size="7">${_esc(room)}</text>`;
        }

        // Receiver markers (non-draggable green reference) — skip stale
        const _liveRadios = snap?.ble?.radios || [];
        for (const r of (m.receivers || [])) {
          const _lr = _liveRadios.find(rd => rd.name === (r.label || "") || rd.source === (r.id || ""));
          if (!_lr) continue; // stale receiver — scanner no longer exists
          const [wx, wy] = xf.mapPt(r.x || 0, r.y || 0);
          const [px, py] = iso(wx, wy, z);
          const rx = Math.round(px), ry = Math.round(py);
          const lbl = (r.label || r.id || "R").substring(0, 6);
          const tip = `Scanner: ${r.label || r.id || "Receiver"}${r.room ? " | Room: " + r.room : ""}`;
          s += `<g data-tip="${_esc(tip)}" style="cursor:default;opacity:0.6">`;
          s += `<circle cx="${rx}" cy="${ry}" r="10" fill="none" stroke="#52b788" stroke-width="1.2" opacity="0.5"/>`;
          s += `<circle cx="${rx}" cy="${ry}" r="5" fill="#52b788" opacity="0.6"/>`;
          const lblW = Math.min(lbl.length * 6 + 6, 50);
          s += `<rect x="${rx - lblW / 2}" y="${ry + 12}" width="${lblW}" height="11" rx="3" fill="#071008" opacity="0.7"/>`;
          s += `<text x="${rx}" y="${ry + 21}" text-anchor="middle" fill="#52b788" font-size="7" opacity="0.7">${_esc(lbl)}</text>`;
          s += `</g>`;
        }

        // Beacon markers (draggable teal diamonds)
        const draft = bs.draftBeacons[m.id] || [];
        for (const bk of draft) {
          const [wx, wy] = xf.mapPt(bk.x || 0, bk.y || 0);
          const [px, py] = iso(wx, wy, z);
          const isSel = bs.selectedBk && bs.selectedBk.mapId === m.id && bs.selectedBk.bkId === bk.id;
          const bx = Math.round(px), by = Math.round(py);
          const lbl = (bk.label || bk.key || "B").substring(0, 8);
          const detectedRoom = _detectRoom(bk.x, bk.y, m);
          const tip = `${bk.label || bk.key || "Beacon"}${detectedRoom ? " | Room: " + detectedRoom : ""} | x: ${(bk.x * 100).toFixed(1)}% y: ${(bk.y * 100).toFixed(1)}%`;

          s += `<g data-bk-id="${_esc(bk.id)}" data-map-id="${_esc(m.id)}" data-z="${z}" data-tip="${_esc(tip)}" style="cursor:grab">`;
          // Selection highlight
          if (isSel) s += `<circle cx="${bx}" cy="${by}" r="22" fill="none" stroke="#fbbf24" stroke-width="2" stroke-dasharray="4,3" opacity="0.9"/>`;
          // Pulse ring
          s += `<circle cx="${bx}" cy="${by}" r="16" fill="#5eead4" opacity="0.2"/>`;
          // Diamond (rotated square)
          s += `<rect x="${bx - 8}" y="${by - 8}" width="16" height="16" rx="2" transform="rotate(45 ${bx} ${by})" fill="#5eead4" stroke="#071008" stroke-width="1.5" opacity="0.95"/>`;
          // Center dot
          s += `<circle cx="${bx}" cy="${by}" r="3" fill="#071008" opacity="0.7"/>`;
          // Label below
          const lblW = Math.min(lbl.length * 7 + 8, 70);
          s += `<rect x="${bx - lblW / 2}" y="${by + 18}" width="${lblW}" height="13" rx="3" fill="#071008" opacity="0.8"/>`;
          s += `<text x="${bx}" y="${by + 28}" text-anchor="middle" fill="#5eead4" font-size="9" font-weight="600">${_esc(lbl)}</text>`;
          s += `</g>`;
        }
      }

      // Layer index dot
      s += `<circle cx="${Math.round(BL[0])}" cy="${Math.round(BL[1])}" r="15" fill="${lyrColor}" opacity="0.95"/>`;
      s += `<text x="${Math.round(BL[0])}" y="${Math.round(BL[1]) + 6}" text-anchor="middle" fill="#071008" font-size="14" font-weight="700">${lidx + 1}</text>`;
      s += `</g>`;
    }

    // Legend
    s += `<line x1="10" y1="${BASE_H + 4}" x2="${W - 10}" y2="${BASE_H + 4}" stroke="#1b3526" stroke-width="0.8"/>`;
    sortedIsoLevels.forEach((z, i) => {
      const ly = BASE_H + 10 + i * 30;
      const color = levelColor(z);
      const groupLabel = byLevel.get(z).map(m => m.name || m.id).join(" + ");
      s += `<circle cx="18" cy="${ly + 11}" r="11" fill="${color}" opacity="0.9"/>`;
      s += `<text x="18" y="${ly + 15}" text-anchor="middle" fill="#071008" font-size="12" font-weight="700">${i + 1}</text>`;
      s += `<text x="36" y="${ly + 15}" fill="${color}" font-size="18" font-weight="500">${_esc(groupLabel)}</text>`;
    });

    s += `</svg>`;
    return s;
  };

  // ── Beacon picker row ─────────────────────────────────────────────────
  const allPinnedKeys = new Set();
  for (const bks of Object.values(bs.draftBeacons)) {
    for (const bk of bks) if (bk.key) allPinnedKeys.add(bk.key);
  }
  const availObjs = (snap?.objects?.list || [])
    .filter(o => (o.user_label || o.identified) && !allPinnedKeys.has(o.key))
    .sort((a, b) => (a.user_label || a.name || "").localeCompare(b.user_label || b.name || ""));

  const pickerRow = el("div", { style: "display:flex;gap:8px;align-items:center;flex-wrap:wrap" });

  // Map selector for beacon placement
  const bkMapSel = document.createElement("select");
  bkMapSel.style.cssText = "min-width:120px;";
  for (const m of sorted) {
    const opt = document.createElement("option");
    opt.value = m.id;
    opt.textContent = m.name || m.id;
    bkMapSel.appendChild(opt);
  }

  const bkSel = document.createElement("select");
  bkSel.style.cssText = "flex:1;min-width:160px;";
  const ph = document.createElement("option");
  ph.value = "";
  ph.textContent = availObjs.length ? "\u2014 select beacon to add \u2014" : "\u2014 no available beacons \u2014";
  bkSel.appendChild(ph);
  for (const o of availObjs) {
    const opt = document.createElement("option");
    opt.value = o.key;
    const kindBadge = o.kind === "ibeacon" ? " [iBeacon]" : o.kind === "private_ble" ? " [Private BLE]" : " [BLE]";
    opt.textContent = (o.user_label || o.name || o.key) + kindBadge;
    bkSel.appendChild(opt);
  }

  const addBtn = el("button", { class: "btn inline" }, "Add to map");
  addBtn.addEventListener("click", () => {
    const selKey = bkSel.value;
    if (!selKey) return;
    const obj = (snap?.objects?.list || []).find(o => o.key === selKey);
    if (!obj) return;
    const targetMapId = bkMapSel.value;
    const newBk = {
      id: "bk_" + Math.random().toString(16).slice(2, 10),
      label: obj.user_label || obj.name || selKey,
      key: selKey,
      kind: obj.kind || "ble",
      x: 0.5,
      y: 0.5,
    };
    if (!bs.draftBeacons[targetMapId]) bs.draftBeacons[targetMapId] = [];
    bs.draftBeacons[targetMapId].push(newBk);
    bs.dirtyMaps[targetMapId] = true;
    bs.selectedBk = { mapId: targetMapId, bkId: newBk.id };
    _refreshSVG();
    _refreshInfo();
    _refreshDirtyLabel();
    _refreshBeaconList();
  });

  pickerRow.appendChild(el("span", { style: "font-weight:600;font-size:13px" }, "Beacon:"));
  pickerRow.appendChild(bkSel);
  pickerRow.appendChild(el("span", { style: "font-size:12px;color:#94a3b8" }, "on"));
  pickerRow.appendChild(bkMapSel);
  pickerRow.appendChild(addBtn);
  wrap.appendChild(pickerRow);

  // ── Controls row ──────────────────────────────────────────────────────────
  const ctrlRow = document.createElement("div");
  ctrlRow.style.cssText = "display:flex;align-items:center;gap:10px;flex-wrap:wrap";

  // Floor focus
  const focusLbl = document.createElement("span");
  focusLbl.style.cssText = "font-size:12px;color:#94a3b8;min-width:80px;display:inline-block";
  focusLbl.textContent = _getFocusLbl(bs.focusIdx);
  const focusSlider = document.createElement("input");
  focusSlider.type = "range"; focusSlider.min = "0"; focusSlider.max = String(_isoPos.length - 1);
  focusSlider.style.cssText = "width:130px;accent-color:#5eead4;vertical-align:middle;cursor:pointer";
  focusSlider.value = String(bs.focusIdx);
  focusSlider.addEventListener("input", () => {
    bs.focusIdx = parseInt(focusSlider.value, 10);
    focusLbl.textContent = _getFocusLbl(bs.focusIdx);
    _refreshSVG();
  });

  const floorLbl = document.createElement("span");
  floorLbl.style.cssText = "font-size:12px;color:#94a3b8";
  floorLbl.textContent = "Floor:";
  ctrlRow.appendChild(floorLbl);
  ctrlRow.appendChild(focusSlider);
  ctrlRow.appendChild(focusLbl);

  // Spacing slider
  const gapLbl = document.createElement("span");
  gapLbl.style.cssText = "font-size:12px;color:#94a3b8;min-width:36px;display:inline-block;text-align:right";
  gapLbl.textContent = String(bs.fg);
  const gapSlider = document.createElement("input");
  gapSlider.type = "range"; gapSlider.min = "60"; gapSlider.max = "340"; gapSlider.step = "10";
  gapSlider.style.cssText = "width:110px;accent-color:#5eead4;vertical-align:middle;cursor:pointer";
  gapSlider.value = String(bs.fg);
  gapSlider.addEventListener("input", () => {
    bs.fg = parseInt(gapSlider.value, 10);
    _fg = bs.fg;
    gapLbl.textContent = String(bs.fg);
    _refreshSVG();
  });
  const spacingLbl = document.createElement("span");
  spacingLbl.style.cssText = "font-size:12px;color:#94a3b8;margin-left:8px";
  spacingLbl.textContent = "Spacing:";
  ctrlRow.appendChild(spacingLbl);
  ctrlRow.appendChild(gapSlider);
  ctrlRow.appendChild(gapLbl);

  // L/R slider
  const hgLbl = document.createElement("span");
  hgLbl.style.cssText = "font-size:12px;color:#94a3b8;min-width:36px;display:inline-block;text-align:right";
  hgLbl.textContent = String(bs.hg);
  const hgSlider = document.createElement("input");
  hgSlider.type = "range"; hgSlider.min = "-120"; hgSlider.max = "120"; hgSlider.step = "10";
  hgSlider.style.cssText = "width:110px;accent-color:#5eead4;vertical-align:middle;cursor:pointer";
  hgSlider.value = String(bs.hg);
  hgSlider.addEventListener("input", () => {
    bs.hg = parseInt(hgSlider.value, 10);
    _hg = bs.hg;
    hgLbl.textContent = String(bs.hg);
    _refreshSVG();
  });
  const lrLbl = document.createElement("span");
  lrLbl.style.cssText = "font-size:12px;color:#94a3b8;margin-left:8px";
  lrLbl.textContent = "L/R:";
  ctrlRow.appendChild(lrLbl);
  ctrlRow.appendChild(hgSlider);
  ctrlRow.appendChild(hgLbl);

  // Save button
  const statusLbl = document.createElement("span");
  statusLbl.style.cssText = "font-size:11px;color:#94a3b8;min-width:90px";
  const saveBtn = document.createElement("button");
  saveBtn.className = "btn inline";
  saveBtn.style.cssText = "padding:2px 10px;font-size:12px";
  saveBtn.textContent = "Save";
  saveBtn.title = "Save updated beacon positions to all modified maps";
  saveBtn.addEventListener("click", async () => {
    const dirtyIds = Object.keys(bs.dirtyMaps).filter(id => bs.dirtyMaps[id]);
    if (!dirtyIds.length) { statusLbl.textContent = "No changes"; setTimeout(() => { statusLbl.textContent = ""; }, 2000); return; }
    saveBtn.disabled = true;
    statusLbl.textContent = "Saving...";
    try {
      for (const mapId of dirtyIds) {
        const origMap = maps_list.find(m => m.id === mapId);
        if (!origMap) continue;
        await ctx.actions.mapsUpdate({
          map_id: mapId,
          beacons: bs.draftBeacons[mapId] || [],
          receivers: origMap.receivers || [],
          calibration: origMap.calibration || {},
          notes: origMap.notes || "",
        });
      }
      bs.dirtyMaps = {};
      const freshMaps = (ctx.state.maps && ctx.state.maps.list) ? ctx.state.maps.list : [];
      bs._mapsStamp = freshMaps.map(m => `${m.id}:${m.updated||""}:${(m.beacons||[]).length}`).join("|");
      statusLbl.textContent = "Saved \u2713";
      ctx.toast("Beacon positions saved");
      setTimeout(() => { statusLbl.textContent = ""; }, 2500);
      _refreshDirtyLabel();
    } catch (e) {
      statusLbl.textContent = "Error saving";
      ctx.toast("Save failed: " + String(e), true);
    }
    saveBtn.disabled = false;
  });

  // Reset button
  const resetBtn = document.createElement("button");
  resetBtn.className = "btn inline";
  resetBtn.style.cssText = "padding:2px 10px;font-size:12px";
  resetBtn.textContent = "Reset";
  resetBtn.title = "Discard unsaved changes and reload beacon positions";
  resetBtn.addEventListener("click", () => {
    bs.draftBeacons = {};
    for (const m of maps_list) {
      bs.draftBeacons[m.id] = (m.beacons || []).map(bk => ({
        id: bk.id || "", label: bk.label || "", key: bk.key || "",
        kind: bk.kind || "", x: Number(bk.x || 0), y: Number(bk.y || 0),
      }));
    }
    bs.dirtyMaps = {};
    bs.selectedBk = null;
    bs.fg = ctx.state.settings?.overview_iso_floor_gap ?? 150;
    bs.hg = ctx.state.settings?.overview_iso_horiz_gap ?? 0;
    bs.focusIdx = 0;
    _fg = bs.fg; _hg = bs.hg;
    gapSlider.value = String(bs.fg); gapLbl.textContent = String(bs.fg);
    hgSlider.value = String(bs.hg); hgLbl.textContent = String(bs.hg);
    focusSlider.value = "0"; focusLbl.textContent = "All floors";
    statusLbl.textContent = "Reset \u2713";
    setTimeout(() => { statusLbl.textContent = ""; }, 2000);
    _refreshSVG();
    _refreshInfo();
    _refreshDirtyLabel();
    _refreshBeaconList();
  });

  ctrlRow.appendChild(saveBtn);
  ctrlRow.appendChild(resetBtn);

  // Auto-calibrate toggle
  const autoCal = ctx.state.settings?.beacon_auto_calibrate !== false;
  const toggleLbl = document.createElement("span");
  toggleLbl.style.cssText = "font-size:12px;color:#94a3b8;margin-left:4px";
  toggleLbl.textContent = "Auto-Cal:";
  const toggleBtn = document.createElement("button");
  toggleBtn.className = "btn inline";
  toggleBtn.style.cssText = `font-size:11px;padding:2px 10px;${autoCal ? "background:#5eead4;color:#071008;border-color:#5eead4;" : ""}`;
  toggleBtn.textContent = autoCal ? "ON" : "OFF";
  toggleBtn.addEventListener("click", () => {
    ctx.actions.settingsSet({ beacon_auto_calibrate: !autoCal });
  });
  ctrlRow.appendChild(toggleLbl);
  ctrlRow.appendChild(toggleBtn);

  ctrlRow.appendChild(statusLbl);

  // Dirty indicator
  const dirtyLbl = document.createElement("span");
  dirtyLbl.style.cssText = "font-size:11px;color:#f59e0b;font-weight:600;margin-left:auto";
  function _refreshDirtyLabel() {
    const n = Object.keys(bs.dirtyMaps).filter(id => bs.dirtyMaps[id]).length;
    dirtyLbl.textContent = n ? `${n} map${n > 1 ? "s" : ""} unsaved` : "";
  }
  _refreshDirtyLabel();
  ctrlRow.appendChild(dirtyLbl);

  // ── DOM: SVG container ──────────────────────────────────────────────────────
  const isoWrap = document.createElement("div");
  isoWrap.style.cssText = "position:relative;margin-top:6px";

  const isoDiv = document.createElement("div");
  isoDiv.style.cssText = "overflow:auto;border-radius:8px;background:#071008;padding:8px";
  isoDiv.innerHTML = buildBeaconSVG(_getFocusZ(bs.focusIdx));

  // Hover tooltip
  const tipEl = document.createElement("div");
  tipEl.style.cssText = "position:absolute;top:8px;left:8px;background:rgba(7,16,8,0.92);" +
    "border:1px solid #2d6a4f;border-radius:8px;padding:6px 10px;font-size:11px;color:#a7f3d0;" +
    "pointer-events:none;white-space:pre-line;max-width:min(260px,calc(100vw - 40px));z-index:5;display:none;" +
    "font-family:ui-monospace,SFMono-Regular,Consolas,monospace;line-height:1.5";
  isoWrap.appendChild(isoDiv);
  isoWrap.appendChild(tipEl);

  isoDiv.addEventListener("mouseover", e => {
    const g = e.target.closest("[data-tip]");
    if (g) {
      tipEl.textContent = "";
      g.getAttribute("data-tip").split("|").forEach((line, i) => {
        if (i > 0) tipEl.appendChild(document.createElement("br"));
        tipEl.appendChild(document.createTextNode(line));
      });
      tipEl.style.display = "block";
    }
  });
  isoDiv.addEventListener("mouseout", e => {
    const g = e.target.closest("[data-tip]");
    if (!g || !isoDiv.contains(e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest("[data-tip]")))
      tipEl.style.display = "none";
  });

  // ── Drag interaction ────────────────────────────────────────────────────────
  let _dragging = null; // {mapId, bkId, z}

  isoDiv.addEventListener("pointerdown", e => {
    const g = e.target.closest("[data-bk-id]");
    if (!g) return;
    e.preventDefault();
    const mapId = g.getAttribute("data-map-id");
    const bkId = g.getAttribute("data-bk-id");
    const z = Number(g.getAttribute("data-z") || 0);
    bs.selectedBk = { mapId, bkId };
    _dragging = { mapId, bkId, z };
    isoDiv.setPointerCapture(e.pointerId);
    isoDiv.style.cursor = "grabbing";
    _refreshSVG();
    _refreshInfo();
  });

  isoDiv.addEventListener("pointermove", e => {
    if (!_dragging) return;
    e.preventDefault();
    const svgNode = isoDiv.querySelector("svg");
    if (!svgNode) return;

    const ctm = svgNode.getScreenCTM();
    if (!ctm) return;
    const inv = ctm.inverse();
    const sx = e.clientX * inv.a + e.clientY * inv.c + inv.e;
    const sy = e.clientX * inv.b + e.clientY * inv.d + inv.f;

    const [wx, wy] = invIso(sx, sy, _dragging.z);

    const xf = mapXforms[_dragging.mapId];
    if (!xf) return;
    const [nx, ny] = xf.invMapPt(wx, wy);

    const cx2 = Math.max(0, Math.min(1, nx));
    const cy2 = Math.max(0, Math.min(1, ny));

    const draft = bs.draftBeacons[_dragging.mapId];
    if (!draft) return;
    const bk = draft.find(b => b.id === _dragging.bkId);
    if (!bk) return;
    bk.x = cx2;
    bk.y = cy2;
    bs.dirtyMaps[_dragging.mapId] = true;

    _refreshSVG();
    _refreshInfo();
  });

  isoDiv.addEventListener("pointerup", e => {
    if (_dragging) {
      _dragging = null;
      isoDiv.releasePointerCapture(e.pointerId);
      isoDiv.style.cursor = "";
      _refreshDirtyLabel();
    }
  });

  // Click to select (without drag)
  isoDiv.addEventListener("click", e => {
    if (_dragging) return;
    const g = e.target.closest("[data-bk-id]");
    if (g) {
      bs.selectedBk = { mapId: g.getAttribute("data-map-id"), bkId: g.getAttribute("data-bk-id") };
      _refreshSVG();
      _refreshInfo();
    }
  });

  // ── Helper: rebuild SVG without losing scroll ─────────────────────────────
  function _refreshSVG() {
    const scrollTop = isoDiv.scrollTop, scrollLeft = isoDiv.scrollLeft;
    isoDiv.innerHTML = buildBeaconSVG(_getFocusZ(bs.focusIdx));
    isoDiv.scrollTop = scrollTop;
    isoDiv.scrollLeft = scrollLeft;
  }

  // ── Selected beacon info panel ──────────────────────────────────────────
  const infoCard = document.createElement("div");
  infoCard.style.cssText = "background:#0d1f14;border:1px solid #1b3526;border-radius:8px;padding:10px 14px;font-size:12px;color:#a7f3d0;min-height:24px";
  function _refreshInfo() {
    if (!bs.selectedBk) {
      infoCard.textContent = "Click a beacon diamond to select it, then drag to reposition.";
      return;
    }
    const draft = bs.draftBeacons[bs.selectedBk.mapId] || [];
    const bk = draft.find(b => b.id === bs.selectedBk.bkId);
    if (!bk) { infoCard.textContent = "Beacon not found."; return; }
    const mapObj = maps_list.find(m => m.id === bs.selectedBk.mapId);
    const detectedRoom = mapObj ? _detectRoom(bk.x, bk.y, mapObj) : "";
    const obj = (snap?.objects?.list || []).find(o => o.key === bk.key);
    const lastRssi = obj?.rssi != null ? `${obj.rssi} dBm` : "\u2014";
    infoCard.innerHTML = "";
    const lines = [
      `<b style="color:#5eead4">${_esc(bk.label || bk.key)}</b>`,
      `Map: ${_esc(mapObj?.name || bs.selectedBk.mapId)}`,
      `Room: ${_esc(detectedRoom || "\u2014")}`,
      `Position: x ${(bk.x * 100).toFixed(1)}%, y ${(bk.y * 100).toFixed(1)}%`,
      `RSSI: ${lastRssi}`,
      `Kind: ${_esc(bk.kind || "ble")}`,
    ];
    infoCard.innerHTML = lines.join(" &nbsp;\u00b7&nbsp; ");
  }
  _refreshInfo();

  // ── Pinned beacons list ───────────────────────────────────────────────
  const beaconListCard = document.createElement("div");
  beaconListCard.className = "card";
  function _refreshBeaconList() {
    beaconListCard.innerHTML = "";
    // Gather all beacons across all maps
    let totalCount = 0;
    const allEntries = [];
    for (const m of sorted) {
      const bks = bs.draftBeacons[m.id] || [];
      for (const bk of bks) {
        allEntries.push({ bk, map: m });
        totalCount++;
      }
    }
    if (!totalCount) {
      beaconListCard.style.display = "none";
      return;
    }
    beaconListCard.style.display = "";
    const hdr = document.createElement("div");
    hdr.style.cssText = "font-weight:700;font-size:13px;margin-bottom:8px";
    hdr.textContent = `Pinned Beacons (${totalCount})`;
    beaconListCard.appendChild(hdr);

    for (const { bk, map } of allEntries) {
      const isSel = bs.selectedBk && bs.selectedBk.mapId === map.id && bs.selectedBk.bkId === bk.id;
      const row = document.createElement("div");
      row.style.cssText = `display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:6px;cursor:pointer;${isSel ? "background:#0d2818;" : ""}`;
      // Teal diamond icon
      const icon = document.createElement("div");
      icon.style.cssText = "width:12px;height:12px;background:#5eead4;transform:rotate(45deg);border-radius:2px;flex-shrink:0;";
      row.appendChild(icon);
      const lbl = document.createElement("span");
      lbl.style.cssText = "flex:1;font-size:12px;color:#d1d5db";
      lbl.textContent = `${bk.label || bk.key} \u2014 ${map.name || map.id} \u2014 x:${(bk.x*100).toFixed(1)}% y:${(bk.y*100).toFixed(1)}%`;
      row.appendChild(lbl);
      const rmBtn = document.createElement("button");
      rmBtn.className = "btn inline";
      rmBtn.style.cssText = "font-size:11px;padding:2px 8px;color:#f87171;border-color:#f87171;";
      rmBtn.textContent = "Remove";
      rmBtn.addEventListener("click", (ev) => {
        ev.stopPropagation();
        bs.draftBeacons[map.id] = (bs.draftBeacons[map.id] || []).filter(b => b.id !== bk.id);
        bs.dirtyMaps[map.id] = true;
        if (bs.selectedBk?.bkId === bk.id) bs.selectedBk = null;
        _refreshSVG();
        _refreshInfo();
        _refreshDirtyLabel();
        _refreshBeaconList();
      });
      row.appendChild(rmBtn);
      row.addEventListener("click", () => {
        bs.selectedBk = { mapId: map.id, bkId: bk.id };
        _refreshSVG();
        _refreshInfo();
        _refreshBeaconList();
      });
      beaconListCard.appendChild(row);
    }
  }
  _refreshBeaconList();

  // ── Assemble ──────────────────────────────────────────────────────────────
  wrap.appendChild(ctrlRow);
  wrap.appendChild(isoWrap);
  wrap.appendChild(infoCard);
  wrap.appendChild(beaconListCard);

  return wrap;
}


function _pointInPoly(px, py, points) {
  let inside = false;
  const n = points.length;
  for (let i = 0, j = n - 1; i < n; j = i++) {
    const xi = points[i][0], yi = points[i][1];
    const xj = points[j][0], yj = points[j][1];
    if ((yi > py) !== (yj > py) && px < ((xj - xi) * (py - yi)) / (yj - yi) + xi) {
      inside = !inside;
    }
  }
  return inside;
}
