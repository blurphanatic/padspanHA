"""
PadSpan HA — Presence Coordinator
===================================
A DataUpdateCoordinator that polls the live snapshot and provides
{key: object_dict} data to sensor and device_tracker entities.

Each key is either "ble:AA:BB:CC:DD:EE:FF" or "entity:domain.entity_id".
Only labelled BLE objects (user_label set) get entities created for them.
"""
from __future__ import annotations

import logging
from datetime import timedelta
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

_LOGGER = logging.getLogger(__name__)

# Entities update every 10 s — fast enough for automations, avoids redundant load
# (the panel already polls the same snapshot independently every 5 s).
_SCAN_INTERVAL = timedelta(seconds=10)


class PresenceCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Periodically fetches the live BLE snapshot and exposes room data to HA entities."""

    def __init__(self, hass: HomeAssistant) -> None:
        super().__init__(
            hass,
            _LOGGER,
            name="PadSpan HA Presence",
            update_interval=_SCAN_INTERVAL,
        )

    async def _async_update_data(self) -> dict[str, Any]:
        """Return {key: object_dict} for all objects in the current live snapshot."""
        # Imported here to avoid a circular import at module load time.
        from .websocket import _live_snapshot  # noqa: PLC0415

        try:
            snap = await _live_snapshot(self.hass)
        except Exception as err:
            raise UpdateFailed(f"PadSpan snapshot error: {err}") from err

        objects: list[dict[str, Any]] = (snap.get("objects") or {}).get("list") or []
        return {obj["key"]: obj for obj in objects if obj.get("key")}
