"""
PadSpan HA — Presence Coordinator
===================================
A DataUpdateCoordinator that polls the live snapshot and provides
{key: object_dict} data to sensor and device_tracker entities.

KEY BEHAVIOUR: devices that disappear from the live snapshot are NOT dropped
from the result dict.  Instead they are carried forward as "stale" entries with
a synthetic age_s computed from the time they were last seen.  This allows
device_tracker and sensor entities to transition to "not_home" rather than
flipping to "unavailable" every time a device walks out of BLE range.

Stale entries are kept indefinitely (they never expire) because "not_home" is
a permanently valid state for a device tracker.  If a device is re-detected,
its entry is refreshed with live data.
"""
from __future__ import annotations

import logging
import time
from datetime import timedelta
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

_LOGGER = logging.getLogger(__name__)

# Entity poll rate — 10 s is fast enough for automation triggers and avoids
# double-loading the snapshot (the panel already polls independently every 5 s).
_SCAN_INTERVAL = timedelta(seconds=10)


class PresenceCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Periodically fetches the live BLE snapshot and exposes room data to HA entities."""

    def __init__(self, hass: HomeAssistant) -> None:
        super().__init__(
            hass,
            _LOGGER,
            name="PadSpan HA Presence",
            update_interval=_SCAN_INTERVAL,
        )
        # {key: monotonic_timestamp} — when each object was last present in a snapshot
        self._last_seen: dict[str, float] = {}
        # {key: object_dict} — most recent live copy of each object
        self._known_objs: dict[str, dict[str, Any]] = {}

    async def _async_update_data(self) -> dict[str, Any]:
        """
        Fetch live snapshot and return {key: object_dict}.

        For objects currently visible: return their live data as-is.
        For objects that have disappeared: return a synthetic copy with an
        age_s computed from (now - last_seen_timestamp) so entities can
        independently decide whether to report a room or "not_home".
        """
        from .websocket import _live_snapshot  # noqa: PLC0415  (avoid circular import)

        try:
            snap = await _live_snapshot(self.hass)
        except Exception as err:
            raise UpdateFailed(f"PadSpan snapshot error: {err}") from err

        now = time.monotonic()
        objects: list[dict[str, Any]] = (snap.get("objects") or {}).get("list") or []

        # 1. Refresh cache with live objects
        result: dict[str, Any] = {}
        for obj in objects:
            key = obj.get("key", "")
            if not key:
                continue
            self._last_seen[key] = now
            self._known_objs[key] = dict(obj)
            result[key] = obj

        # 2. Carry forward objects no longer in the snapshot with updated age_s.
        #    This keeps device_tracker / sensor entities at "not_home" rather than
        #    "unavailable" after the device leaves Bluetooth range.
        for key, last_obj in self._known_objs.items():
            if key in result:
                continue  # already present as live data
            elapsed = now - self._last_seen.get(key, now)
            stale = dict(last_obj)
            stale["age_s"] = elapsed          # grows every poll cycle
            stale["_stale"] = True            # flag so callers can distinguish
            result[key] = stale

        return result
