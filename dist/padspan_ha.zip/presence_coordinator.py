# PadSpan HA — BLE Room-Presence Tracking for Home Assistant
# Copyright (C) 2026 Garry Broeckling
# Licensed under the GNU General Public License v3.0
# See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
"""
PadSpan HA — Presence Coordinator
===================================
A DataUpdateCoordinator that polls the live snapshot and provides
{key: object_dict} data to sensor and device_tracker entities.

SMOOTHING PIPELINE (BLE objects only)
──────────────────────────────────────
Raw BLE RSSI is extremely noisy — a device standing still can swing ±10 dBm
between consecutive advertisements.  Without smoothing, the "current room" flickers
between adjacent rooms every few seconds.

Three-stage pipeline applied each poll cycle:

  Stage 1 — Kalman-filtered RSSI per source
    Replaces the fixed-alpha EMA with an adaptive Kalman filter that adjusts
    its gain based on estimated uncertainty.  This makes the filter more
    responsive to genuine movement while still rejecting momentary RF spikes.

    Kalman update per (device, scanner) pair:
        K = P / (P + R)                  # Kalman gain
        x = x + K * (rssi_raw - x)       # filtered estimate
        P = (1 - K) * P + Q              # error covariance

    Q (process noise) — how much the true RSSI is expected to vary per poll.
      Default 0.125.  Increase for faster response; decrease for more smoothing.
    R (measurement noise) — how noisy the raw measurement is.
      Default 8.0.  Increase for more smoothing; decrease for faster response.

    Sources that stop reporting are decayed toward -100 dBm and pruned when they
    fall below -95 dBm (~4–5 polls after last seen).

  Stage 1.5 — Gaussian room scoring (replaces winner-takes-all max RSSI)
    Each scanner's Kalman RSSI is converted to an estimated distance via the
    path-loss formula, then scored with a Gaussian weight exp(−(d/σ)²) where
    σ is the configurable room_sigma_m (default 4 m).  The room with the highest
    max-score across its assigned scanners becomes the candidate.  This penalises
    scanners on the far side of a wall more proportionally than raw RSSI comparison.

    Optional k-NN override: if calibration fingerprint data (≥5 points) exists and
    the k-NN confidence exceeds 0.30, the fingerprint result replaces the Gaussian
    candidate.  Also provides sub-room (x_frac, y_frac) for map dot positioning.

  Stage 2 — Majority-vote window
    At each poll, the candidate room (from Gaussian scoring or k-NN) is added to
    a rolling window of VOTE_WINDOW (5) entries.  The confirmed room only changes
    when one room appears ≥ VOTE_THRESHOLD (3) times in the window.
    At 10 s/poll this means a room switch requires ~30 s of consistent dominance.

    The vote window is cleared when a device re-appears after being away, preventing
    stale votes from the previous location from influencing re-entry assignment.

HOME/AWAY PERSISTENCE
─────────────────────
Devices that disappear from the live snapshot are kept in the result dict with a
synthetic age_s that grows each poll.  A 2-poll grace period (≈20 s) prevents a
momentary signal gap from triggering an away event.  Devices with confident
presence (room_confidence ≥ 0.6) get an extended grace period controlled by the
signal_loss_linger_s setting (default 90 s / ~9 polls) so that brief BLE dropouts
don't erase established presence.  Entities read age_s and return "not_home" when
it exceeds the configured away timeout (Settings → Presence → Away timeout;
default 300 s / 5 min).  Entities never go "unavailable" — "not_home" is a
permanently valid HA state.

When ALL scanners go silent simultaneously (total signal dropout), the Kalman
filter decays toward -95 dBm instead of -100 dBm, preserving state ~3× longer
(~200-250 s vs ~70-80 s).  When some scanners are still active (genuine movement),
losing scanners still decay rapidly at -100 dBm for fast room switching.  The vote
window also skips None candidates during total silence, preserving the last
confirmed room assignment.

CONFIDENCE SCORE
─────────────────
Each poll computes room_confidence ∈ [0, 1] based on how decisive the vote window is:
    confidence = top_room_vote_count / vote_window_size
At 1.0 the device has been in the same room for every poll in the window.
At 0.33 (with window=3) only one poll agreed.  Surface in automations via the
extra_state_attributes of sensor.{device}_area.
"""
from __future__ import annotations

import logging
import math
import time
from collections import deque
from datetime import timedelta
from typing import Any

import voluptuous as vol
from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .const import (
    DOMAIN, DATA_SETTINGS, DATA_CALIBRATION, DATA_ADAPTIVE, DATA_MODEL,
    DATA_OBJECTS, OUTSIDE_FLOOR_ID,
    DEFAULT_KALMAN_Q, DEFAULT_KALMAN_R,
    DEFAULT_REF_POWER, DEFAULT_PATH_LOSS_EXP, DEFAULT_ROOM_SIGMA_M,
)

_LOGGER = logging.getLogger(__name__)

_SCAN_INTERVAL = timedelta(seconds=10)

# ── Kalman / smoothing constants ─────────────────────────────────────────────
# Defaults — overridable via Settings → Presence → Signal Filter
_KALMAN_Q: float = DEFAULT_KALMAN_Q   # process noise
_KALMAN_R: float = DEFAULT_KALMAN_R   # measurement noise

# Rolling window for majority-vote room confirmation.
# Candidate room must win VOTE_THRESHOLD out of the last VOTE_WINDOW polls.
# At 10s/poll, window=5 means a room switch needs ~30s of consistent dominance.
_VOTE_WINDOW: int = 5
_VOTE_THRESHOLD: int = 3

# RSSI threshold below which a silent source is pruned from the Kalman cache.
# Relaxed from -95 to -98 to preserve Kalman state longer across silent periods,
# giving ~7-8 polls (~70-80s) of memory instead of ~4-5 polls.
_EMA_PRUNE_DBM: float = -98.0

# Phantom RSSI injected each poll for sources that have gone silent (drives decay).
_EMA_SILENCE_DBM: float = -100.0

# Number of consecutive missed polls before a device starts accumulating age_s.
# Grace period = _AWAY_GRACE_POLLS * _SCAN_INTERVAL = 12 * 10s = 120s.
_AWAY_GRACE_POLLS: int = 12

# ── Velocity gate ────────────────────────────────────────────────────────────
# Prevents "teleportation" — objects jumping to non-adjacent rooms faster than
# physically possible.  After a room change is confirmed, any subsequent change
# within the cooldown window requires UNANIMOUS vote agreement (all votes must
# agree) instead of the normal majority threshold.  This makes it progressively
# harder to hop rooms in rapid succession.
#
# The distance component uses room centroids: distant rooms (centroid distance
# > _VG_ADJACENT_THRESHOLD in normalised [0,1] coords) also require unanimous
# agreement regardless of timing.  This catches slow-drift teleportation where
# a device creeps across the building over 30+ seconds without passing through
# intermediate rooms.
_VG_RAPID_COOLDOWN_S: float = 15.0    # seconds after a room change during which the next change is gated
_VG_ADJACENT_THRESHOLD: float = 0.30  # normalised centroid distance — rooms within this are "adjacent"
_VG_ADJACENT_THRESHOLD_M: float = 8.0  # metres — Phase 2 real-world adjacency threshold
_ADJACENCY_SIGMOID_MID_M: float = 8.0  # metres — Phase 2 adjacency prior sigmoid midpoint

# ── Outdoor / isolated scanner penalties ─────────────────────────────────
_OUTDOOR_SCORE_DAMPING: float = 0.30  # multiply outdoor room scores by this when device is indoors
_ISOLATED_SCANNER_DAMPING: float = 0.50  # damping for scanners that are the only one on their floor
_ISOLATED_SCANNER_STRONG_DBM: float = -65.0  # RSSI above this = strong enough to override isolation damping

# ── Per-scanner reliability scoring (Phase 3) ────────────────────────────────
# Each scanner accumulates a rolling "disagreement" count — how often its best
# RSSI implies a different room than the consensus (confirmed room).
# reliability = 1 / (1 + disagreement_rate)  where rate ∈ [0, 1].
# Used as a weight multiplier on each scanner's Gaussian score.
_RELIABILITY_WINDOW: int = 30         # rolling window size (polls)
_RELIABILITY_MIN_POLLS: int = 6       # min observations before weight differs from 1.0
_RELIABILITY_FLOOR: float = 0.15      # minimum weight — never zero-out a scanner entirely

# ── k-NN live fingerprint gating ─────────────────────────────────────────────
# Minimum calibration points before k-NN is consulted for live room assignment.
_KNN_MIN_POINTS: int = 5
# Minimum k-NN confidence [0, 1] required to override the Gaussian candidate.
# With the normalized confidence formula (mean-sq-error / REF_VARIANCE), a
# per-scanner RMS error of ~8 dBm gives ~28% confidence, ~5 dBm gives ~50%.
_KNN_LIVE_THRESHOLD: float = 0.15


# _room_centroids_from_maps and _room_from_bounds removed.
# Fabric is the sole authority: model.room_centroids_m() and model.beacon_room_from_geometry().


def _segments_intersect(
    ax: float, ay: float, bx: float, by: float,
    cx: float, cy: float, dx: float, dy: float,
) -> bool:
    """Return True if segment AB crosses segment CD."""
    def _cross(o1x: float, o1y: float, o2x: float, o2y: float, o3x: float, o3y: float) -> float:
        return (o2x - o1x) * (o3y - o1y) - (o2y - o1y) * (o3x - o1x)
    d1 = _cross(cx, cy, dx, dy, ax, ay)
    d2 = _cross(cx, cy, dx, dy, bx, by)
    d3 = _cross(ax, ay, bx, by, cx, cy)
    d4 = _cross(ax, ay, bx, by, dx, dy)
    if ((d1 > 0 and d2 < 0) or (d1 < 0 and d2 > 0)) and \
       ((d3 > 0 and d4 < 0) or (d3 < 0 and d4 > 0)):
        return True
    return False


def _barrier_attenuation(
    sx: float, sy: float, s_floor: str,
    rx: float, ry: float, r_floor: str,
    barriers: list[dict],
) -> float:
    """Compute total RF attenuation (dBm) for barriers crossing the line from
    point (sx,sy) to point (rx,ry). Only considers barriers on the same floor."""
    total = 0.0
    for bar in barriers:
        _bar_floor = bar.get("floor_id") or bar.get("map_id", "")
        if _bar_floor != s_floor:
            continue
        pts = bar["points"]
        for i in range(len(pts) - 1):
            if _segments_intersect(sx, sy, rx, ry, pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1]):
                total += bar["attenuation_dbm"]
                break  # one crossing per barrier is enough
    return total


class PresenceCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Central BLE room-presence engine for PadSpan HA.

    Polls the live BLE snapshot every 10 seconds and runs each advertisement
    through a multi-stage pipeline:
        1. Kalman filter (per-scanner RSSI smoothing)
        2. Gaussian room scoring (distance-weighted room assignment)
        3. Majority-vote window (temporal stabilization)

    The result dict maps object keys to enriched dicts containing the
    confirmed room, confidence scores, and optional k-NN sub-room position.
    Sensor and device_tracker entities consume this via HA's coordinator
    pattern (async_config_entry_first_refresh / async_add_listener).
    """

    def __init__(self, hass: HomeAssistant) -> None:
        super().__init__(
            hass,
            _LOGGER,
            name="PadSpan HA Presence",
            update_interval=_SCAN_INTERVAL,
        )
        # ── home/away persistence ────────────────────────────────────────────
        # {key: monotonic_ts}  — when each object was last in the live snapshot
        self._last_seen: dict[str, float] = {}
        # {key: obj_dict}  — most recent live copy of each object
        self._known_objs: dict[str, dict[str, Any]] = {}
        # {key: int}  — consecutive polls the object has been absent
        self._away_miss: dict[str, int] = {}

        # ── Kalman smoothing state (keyed by addr/key) ───────────────────────
        # {addr: {source: filtered_rssi}}  — Kalman state estimate x
        self._ema_rssi: dict[str, dict[str, float]] = {}
        # {addr: {source: error_covariance}}  — Kalman state P
        self._kalman_p: dict[str, dict[str, float]] = {}
        # {addr: {source: consecutive_miss_count}} — silence grace tracking
        self._silence_miss: dict[str, dict[str, int]] = {}
        # (key, old_room, new_room) tuples accumulated during a poll cycle;
        # reset at the top of _async_update_data, but initialised here too so
        # _smooth_room is safe to call before the first poll.
        self._pending_room_changes: list[tuple[str, str | None, str]] = []

        # ── Room-vote state (keyed by object key) ────────────────────────────
        # {key: deque of recent candidate rooms}
        self._room_votes: dict[str, deque] = {}
        # {key: confirmed_room | None}  — the current stable room assignment
        self._confirmed_room: dict[str, str | None] = {}
        # {key: float}  — vote-window confidence ∈ [0, 1]
        self._room_confidence: dict[str, float] = {}
        # {key: float}  — RSSI margin confidence ∈ [0, 1] (gap between best and 2nd-best scanner)
        self._rssi_margin_confidence: dict[str, float] = {}
        # {key: dict}  — latest k-NN fingerprint result (x_frac, y_frac, confidence, nearest_room)
        self._knn_position: dict[str, dict] = {}
        # {key: (x, y)}  — EMA-smoothed position for k-NN (stable map display)
        self._smooth_xy: dict[str, tuple[float, float]] = {}
        # {key: dict}  — spatial IDW centroid position (independent of k-NN)
        self._spatial_position: dict[str, dict] = {}
        # {key: (x, y)}  — EMA-smoothed position for spatial (independent of k-NN)
        self._spatial_smooth_xy: dict[str, tuple[float, float]] = {}
        # {key: str}  — spatial debug info (why centroid succeeded/failed)
        self._spatial_debug: dict[str, str] = {}
        # {key: dict}  — last candidate info for diagnostics
        self._last_candidate: dict[str, dict[str, Any]] = {}
        # Throttle: {key: monotonic_ts} — last alert sent time per object
        self._alert_last_sent: dict[str, float] = {}
        _ALERT_COOLDOWN_S = 60  # min seconds between alerts for same device

        # ── Beacon auto-calibration rate-limit ──────────────────────────────────
        # {key: monotonic_ts} — last auto-calibration injection time per beacon
        self._beacon_autocal_last: dict[str, float] = {}

        # ── Velocity gate state ────────────────────────────────────────────────
        # {key: monotonic_ts} — when each device last changed rooms
        self._last_room_change_mono: dict[str, float] = {}
        # {key: monotonic_ts} — when each device entered its current confirmed room
        self._room_dwell_start: dict[str, float] = {}
        # {key: monotonic_ts} — when each device arrived on its current floor
        self._floor_dwell_start: dict[str, float] = {}
        # {key: floor_id} — each device's current confirmed floor
        self._device_floor: dict[str, str] = {}
        # {room_name: (cx, cy, map_id)} — room centroids (rebuilt each poll)
        self._room_centroids: dict[str, tuple[float, float, str]] = {}
        # RF barrier data for Gaussian scoring penalty (rebuilt each poll)
        # {scanner_source: (x, y, map_id)} — scanner positions from map receivers
        self._scanner_positions: dict[str, tuple[float, float, str]] = {}
        # List of barrier dicts: [{points, attenuation_dbm, map_id}, ...]
        self._rf_barriers: list[dict] = []
        # Phase 2: True when spatial data is in metres (not map fractions)
        self._use_metres: bool = False

        # ── Per-scanner reliability (Phase 3) ─────────────────────────────────
        # {source: deque of bools} — True = scanner agreed with consensus this poll
        self._scanner_agree: dict[str, deque] = {}
        # {source: float} — cached reliability weight ∈ [_RELIABILITY_FLOOR, 1.0]
        self._scanner_reliability: dict[str, float] = {}

        # ── Adjacency co-visibility learning (Phase 1) ────────────────────────
        # Accumulates scanner co-visibility counts between rooms.
        # Key: frozenset({roomA, roomB}), value: count of polls where both rooms
        # heard the same device with RSSI > -80.
        self._co_visible: dict[frozenset, int] = {}
        # Poll counter for adjacency learning (compute every 50 polls)
        self._adj_learn_polls: int = 0

        # ── Adaptive learning rate-limit ───────────────────────────────────────
        # {key: monotonic_ts} — last adaptive observation time per device
        self._adaptive_last_obs: dict[str, float] = {}
        # Save counter — only persist to disk every N observations (not every poll)
        self._adaptive_save_counter: int = 0
        # ── Automation tracking ───────────────────────────────────────────────
        # Set of device keys present in the previous poll result (for arrive/depart)
        self._prev_present: set[str] = set()

        # Suspend: when set, use only raw radio + spatial centroid (no k-NN, no adaptive)
        self._suspend_until: float = 0.0  # monotonic timestamp when suspend ends
        self._suspend_permanent: bool = False  # persisted via settings store

        # Restore persistent suspend from settings
        try:
            _st_init = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            if _st_init and _st_init.data.get("databases_suspended"):
                self._suspend_permanent = True
                _LOGGER.info("Databases suspended (restored from settings)")
        except Exception:
            pass

    # ── Suspend / reset smoothing state ─────────────────────────────────────

    @property
    def suspended(self) -> bool:
        """True when databases are suspended — raw radio + spatial only."""
        return self._suspend_permanent or time.monotonic() < self._suspend_until

    def suspend_databases(self, minutes: int = 60) -> None:
        """Suspend all learned/cached databases for N minutes.

        Clears all smoothing state and disables k-NN, adaptive learning,
        and scanner reliability for the duration.  Only raw radio RSSI +
        spatial weighted centroid is used for positioning.

        Also persists the flag so it survives HA restarts.
        """
        self.clear_smoothing_state()
        self._suspend_permanent = True
        self._suspend_until = time.monotonic() + minutes * 60
        # Persist so it survives restarts
        try:
            _st = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            if _st:
                _st.data["databases_suspended"] = True
                self.hass.async_create_task(_st.store.async_save(_st.data))
        except Exception:
            pass
        _LOGGER.info(
            "Databases suspended for %d minutes — raw radio + spatial centroid only",
            minutes,
        )

    def unsuspend_databases(self) -> None:
        """End suspension early — resume normal pipeline."""
        self._suspend_until = 0.0
        self._suspend_permanent = False
        self.clear_smoothing_state()  # start fresh when resuming too
        # Persist
        try:
            _st = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            if _st:
                _st.data.pop("databases_suspended", None)
                self.hass.async_create_task(_st.store.async_save(_st.data))
        except Exception:
            pass
        _LOGGER.info("Database suspension ended — full pipeline resumed")

    def clear_smoothing_state(self) -> None:
        """Wipe all accumulated smoothing state — fresh start from raw radio.

        Clears: Kalman RSSI, vote windows, confirmed rooms, k-NN cache,
        smooth XY, scanner reliability, velocity gate, silence tracking.
        Persistent stores (calibration, adaptive learning) are NOT touched.
        """
        self._ema_rssi.clear()
        self._kalman_p.clear()
        self._silence_miss.clear()
        self._room_votes.clear()
        self._confirmed_room.clear()
        self._room_confidence.clear()
        self._rssi_margin_confidence.clear()
        self._knn_position.clear()
        self._smooth_xy.clear()
        self._spatial_position.clear()
        self._spatial_smooth_xy.clear()
        self._scanner_agree.clear()
        self._scanner_reliability.clear()
        self._last_room_change_mono.clear()
        self._room_dwell_start.clear()
        self._floor_dwell_start.clear()
        self._device_floor.clear()
        self._co_visible.clear()
        self._adj_learn_polls = 0
        self._adaptive_last_obs.clear()
        _LOGGER.info("Smoothing state cleared — fresh positioning from raw radio")

    # ── main update ──────────────────────────────────────────────────────────

    async def _async_update_data(self) -> dict[str, Any]:
        """Main poll loop — called every _SCAN_INTERVAL (10s) by HA's coordinator.

        High-level flow:
          1. Fetch the live BLE snapshot (advertisements + radios + objects)
          2. Resolve rotating private addresses (RPA) to canonical IDs
          3. Build per-device, per-scanner RSSI maps and source-to-area lookups
          4. For each BLE/iBeacon object, run the smoothing pipeline (_smooth_room)
          5. Apply pinned-beacon overrides for beacons with known map positions
          6. Carry forward stale objects for home/away persistence
          7. Fire follow-alerts and record movement history for room changes

        Returns {object_key: enriched_obj_dict} consumed by HA entities.
        """
        from .websocket import _live_snapshot  # noqa: PLC0415  (circular-import guard)
        from .private_ble_resolver import get_resolver  # noqa: PLC0415

        try:
            snap = await _live_snapshot(self.hass)
        except Exception as err:
            raise UpdateFailed(f"PadSpan snapshot error: {err}") from err

        now = time.monotonic()

        # ── Dynamic poll interval from settings ──────────────────────────────
        try:
            _st_pi = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            _pi = int((_st_pi.data if _st_pi else {}).get("presence_poll_interval_s") or 10)
            _pi = max(1, min(60, _pi))
            _new_interval = timedelta(seconds=_pi)
            if self.update_interval != _new_interval:
                self.update_interval = _new_interval
        except Exception:
            pass

        # Accumulates (key, old_room, new_room) tuples during this poll cycle;
        # processed at the end for alerts, movement history, and HA tag events.
        self._pending_room_changes: list[tuple[str, str | None, str]] = []

        # ── Resolve rotating MACs to canonical IDs ────────────────────────────
        # Build a mapping {raw_addr_upper → canonical_key} so that all rotating
        # MACs from the same phone merge into one Kalman state entry.
        resolver = await get_resolver(self.hass)
        _rpa_map: dict[str, str] = {}  # raw_addr → canonical_key
        if resolver.has_devices():
            for ad in (snap.get("ble") or {}).get("advertisements") or []:
                raw = str(ad.get("address") or "").upper()
                if raw and raw not in _rpa_map:
                    res = resolver.resolve_address(raw)
                    if res:
                        _rpa_map[raw] = str(res["canonical_id"]).upper()

        # ── Build per-device RSSI maps from raw advertisements ────────────
        # addr_src_rssi: {canonical_addr: {scanner_source: best_rssi}}
        # addr_tx_power: {canonical_addr: tx_power_level}
        # For resolved RPAs, the canonical_id is the key so all rotating MACs
        # from the same physical phone share one Kalman filter state.
        addr_src_rssi: dict[str, dict[str, float]] = {}
        addr_tx_power: dict[str, int] = {}
        for ad in (snap.get("ble") or {}).get("advertisements") or []:
            raw_addr = str(ad.get("address") or "").upper()
            addr = _rpa_map.get(raw_addr, raw_addr)  # canonical or raw
            src  = ad.get("source")
            rssi = ad.get("rssi")
            if addr and src and rssi is not None:
                existing = addr_src_rssi.setdefault(addr, {})
                # For merged RPAs, keep the strongest RSSI per source
                if str(src) not in existing or float(rssi) > existing[str(src)]:
                    existing[str(src)] = float(rssi)
            # Capture TX Power Level from the advertisement (BLE AD type 0x0A)
            tx_pwr = ad.get("tx_power")
            if addr and tx_pwr is not None and addr not in addr_tx_power:
                addr_tx_power[addr] = int(tx_pwr)

        # ── Build source-to-area and source-to-floor lookups ──────────────
        # Phase 1: read from the positioning fabric (ModelStore) when available.
        # In auto mode, also write-back any new radios from the snapshot.
        source_to_area: dict[str, str] = {}
        source_to_floor: dict[str, str] = {}
        _model = self.hass.data.get(DOMAIN, {}).get(DATA_MODEL)
        if _model:
            # In auto mode, sync snapshot radios into the fabric
            _radios = (snap.get("ble") or {}).get("radios") or []
            if _model.sync_mode() == "auto" and _radios:
                try:
                    await _model.async_sync_from_snapshot(_radios)
                    # One-time prune: remove ha_sync entries that aren't actual radios
                    if not getattr(self, "_fabric_pruned", False):
                        _radio_srcs = {str(r.get("source")) for r in _radios if r.get("source")}
                        _pruned = await _model.async_prune_non_radio_scanners(_radio_srcs)
                        self._fabric_pruned = True
                        if _pruned:
                            _LOGGER.info("Fabric: pruned %d non-radio scanner entries", _pruned)
                except Exception as _sync_err:
                    _LOGGER.warning("Fabric sync error: %s", _sync_err)
            # Read scanner mappings from fabric (includes both ha_sync and manual)
            source_to_area, source_to_floor = _model.get_scanner_mappings()

        # Fallback: if fabric has no scanners yet, build from snapshot directly
        # (first poll before fabric is populated)
        if not source_to_area:
            _area_to_floor: dict[str, str] = {}
            try:
                from homeassistant.helpers import area_registry as _ar_reg  # noqa: PLC0415
                for _a in _ar_reg.async_get(self.hass).async_list_areas():
                    _fl = getattr(_a, "floor_id", None)
                    if _a.name and _fl:
                        _area_to_floor[_a.name] = str(_fl)
            except Exception as _area_err:
                _LOGGER.debug("Area registry floor lookup: %s", _area_err)
            for r in (snap.get("ble") or {}).get("radios") or []:
                src  = r.get("source")
                area = r.get("area_name") or r.get("area")
                if src and area:
                    source_to_area[str(src)] = str(area)
                    fl = _area_to_floor.get(str(area))
                    if fl:
                        source_to_floor[str(src)] = fl

        # ── Apply per-scanner RSSI calibration offsets ────────────────────
        # Users can set per-scanner dBm offsets in Settings → Presence to
        # compensate for hardware differences between ESPHome boards.
        try:
            _st = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            _scanner_offsets: dict[str, float] = ((_st.data if _st else {}).get("scanner_offsets") or {})
            if _scanner_offsets:
                for _am in addr_src_rssi.values():
                    for _src in _am:
                        _off = _scanner_offsets.get(_src)
                        if _off:
                            _am[_src] = _am[_src] + float(_off)
        except Exception as _off_err:
            _LOGGER.debug("Scanner offset application: %s", _off_err)

        # ── Dynamic vote-window sizing from room_change_delay_s setting ───
        # The user sets a desired delay in seconds; we convert that to a
        # vote window size and simple-majority threshold.  E.g. 20s at 10s
        # poll → window=2, threshold=2 (must win 2 of last 2 polls).
        try:
            _st2 = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            _delay_s = float(((_st2.data if _st2 else {}).get("room_change_delay_s") or 20.0))
            _delay_s = max(0.0, min(300.0, _delay_s))
            _dyn_vote_window = max(1, round(_delay_s / self.update_interval.total_seconds()))
            _dyn_vote_threshold = max(1, (_dyn_vote_window + 1) // 2)
        except Exception:
            _dyn_vote_window = _VOTE_WINDOW
            _dyn_vote_threshold = _VOTE_THRESHOLD

        objects: list[dict[str, Any]] = (snap.get("objects") or {}).get("list") or []
        result: dict[str, Any] = {}

        # ── Load pinned beacons from fabric (floor-based, no maps) ─────────
        _pinned: dict[str, dict[str, Any]] = {}
        try:
            if _model:
                for _bk_key, _bk_pos in _model.beacon_positions_m().items():
                    if not isinstance(_bk_pos, dict):
                        continue
                    _pinned[_bk_key] = {
                        "room": _bk_pos.get("room", ""),
                        "floor_id": _bk_pos.get("floor_id", ""),
                        "x_m": _bk_pos.get("x_m"),
                        "y_m": _bk_pos.get("y_m"),
                    }
        except Exception:
            pass

        # Floor-based room set from fabric geometry
        _fabric_rooms: set[str] = set()
        if _model:
            _fabric_rooms = set(_model.data.get("room_geometry_m", {}).keys())

        # ── Spatial data from fabric (metre-space, floor-based, no maps) ──
        self._use_metres = False
        try:
            if _model:
                self._room_centroids = _model.room_centroids_m()
                self._scanner_positions = {
                    src: (pos["x_m"], pos["y_m"], pos.get("floor_id", ""))
                    for src, pos in _model.scanner_positions_m().items()
                }
                _mb = _model.rf_barriers_m()
                self._rf_barriers = [
                    {
                        "points": [(float(p[0]), float(p[1])) for p in (b.get("points_m") or [])],
                        "attenuation_dbm": float(b.get("attenuation_dbm", 6)),
                        "material": str(b.get("material", "custom")),
                        "floor_id": str(b.get("floor_id", "")),
                    }
                    for b in _mb if len(b.get("points_m") or []) >= 2
                ]
                if self._room_centroids or self._scanner_positions:
                    self._use_metres = True
        except Exception:
            pass

        for obj in objects:
            key = obj.get("key", "")
            if not key:
                continue

            # ── Re-entry detection: clear stale smoothing state ──────────────
            # If this device was absent (stale) in the previous poll and is now
            # back, reset the vote window and Kalman state so old-location votes
            # don't slow down re-assignment.
            if self._known_objs.get(key, {}).get("_stale"):
                self._room_votes.pop(key, None)
                self._room_confidence.pop(key, None)
                self._knn_position.pop(key, None)
                self._smooth_xy.pop(key, None)
                self._spatial_position.pop(key, None)
                self._spatial_smooth_xy.pop(key, None)
                if obj.get("kind") in ("ble", "private_ble"):
                    # For private_ble, use canonical_id as Kalman key
                    _raw_addr = str(obj.get("address") or "").upper()
                    addr_clear = _rpa_map.get(_raw_addr, _raw_addr)
                    self._ema_rssi.pop(addr_clear, None)
                    self._kalman_p.pop(addr_clear, None)
                elif obj.get("kind") == "ibeacon":
                    self._ema_rssi.pop(key, None)
                    self._kalman_p.pop(key, None)

            # ── No-signal detection ───────────────────────────────────────
            # An object is "no-signal" when it has no live BLE advertisements
            # this cycle (carried forward from history cache) OR when its best
            # current RSSI is at or below the -110 dBm no-signal sentinel.
            # Threshold -110 dBm sits safely below the -100 dBm silence-decay
            # floor so it never incorrectly mutes a weak-but-live device.
            # The primary check uses addr_src_rssi (built from this cycle's
            # actual advertisements) so a cached object with frozen rssi=-127
            # is caught by the "no live ads" branch, not just the RSSI branch.
            _NO_SIGNAL_DBM: float = -110.0
            _obj_no_signal: bool = False
            _obj_kind = obj.get("kind", "")
            if _obj_kind in ("ble", "private_ble"):
                _ns_raw_addr = str(obj.get("address") or "").upper()
                _ns_smooth_addr = _rpa_map.get(_ns_raw_addr, _ns_raw_addr)
                _ns_live = addr_src_rssi.get(_ns_smooth_addr) or {}
                if not _ns_live:
                    # No live advertisements from this device this cycle
                    _obj_no_signal = True
                elif max(_ns_live.values()) <= _NO_SIGNAL_DBM:
                    # All live sources report sentinel-level RSSI
                    _obj_no_signal = True
            elif _obj_kind == "ibeacon":
                _ns_addrs = obj.get("all_addresses") or []
                _ns_any_live = any(
                    (addr_src_rssi.get(str(a).upper()) or {})
                    for a in _ns_addrs
                )
                _ns_live_vals: list[float] = [
                    r
                    for a in _ns_addrs
                    for r in (addr_src_rssi.get(str(a).upper()) or {}).values()
                ]
                if not _ns_any_live:
                    _obj_no_signal = True
                elif _ns_live_vals and max(_ns_live_vals) <= _NO_SIGNAL_DBM:
                    _obj_no_signal = True
            else:
                # Entity-based trackers: treat as no-signal if rssi is sentinel
                _ns_rssi = obj.get("rssi")
                if _ns_rssi is not None and float(_ns_rssi) <= _NO_SIGNAL_DBM:
                    _obj_no_signal = True

            # Cache the live copy for home/away persistence
            self._last_seen[key] = now
            if not _obj_no_signal:
                # Device is genuinely heard: reset grace counter so it isn't
                # counted as missing and doesn't accumulate away-miss ticks.
                self._away_miss[key] = 0
            else:
                # Device has no usable live signal: clear any frozen confident-
                # room state so the away-miss counter can accumulate toward the
                # away timeout.  The object stays in result for UI awareness but
                # with zeroed confidence; it will be evicted once grace expires.
                self._confirmed_room.pop(key, None)
                self._room_confidence.pop(key, None)
                if key in self._room_votes:
                    self._room_votes[key].clear()

            self._known_objs[key] = dict(obj)

            # ── Fast path: cache-resurrected objects with no live signal ────
            # Objects resurrected from the multi-day history cache (_stale)
            # with no live advertisements gain nothing from the Kalman/k-NN
            # pipeline, yet running it for every device-ever-seen made
            # per-poll CPU scale with history size instead of live devices.
            # Short-circuit them straight to the away/no-signal presentation
            # the full pipeline would produce anyway.
            if _obj_no_signal and obj.get("_stale") and key not in _pinned:
                obj = dict(obj)
                obj["room"] = None
                obj["room_confidence"] = 0.0
                obj["_no_signal"] = True
                self._known_objs[key] = dict(obj)
                result[key] = obj
                continue

            # ── Per-object smoothing pipeline ──────────────────────────────
            # Only BLE and iBeacon objects go through our Kalman + Gaussian +
            # vote pipeline.  Entity-based trackers (e.g. Bermuda) arrive
            # pre-smoothed from their own integration.
            if obj.get("kind") in ("ble", "private_ble"):
                obj = dict(obj)  # copy — don't mutate the snapshot list in place
                raw_addr = str(obj.get("address") or "").upper()
                # For private_ble, use canonical_id as Kalman state key so all
                # rotating MACs share one continuous smoothing state.
                smooth_addr = _rpa_map.get(raw_addr, raw_addr)
                smoothed_room = self._smooth_room(
                    key, smooth_addr, addr_src_rssi, source_to_area,
                    _dyn_vote_window, _dyn_vote_threshold, source_to_floor,
                    _fabric_rooms)
                if smoothed_room:
                    obj["room"] = smoothed_room
                obj["_smoothed"] = True
                obj["room_confidence"] = self._room_confidence.get(key, 0.0)
                obj["rssi_margin_confidence"] = self._rssi_margin_confidence.get(key, 0.0)
                # Propagate sub-room position — prefer spatial (real-time geometry)
                # over k-NN (historical calibration that may be stale).
                _pos = self._spatial_position.get(key) or self._knn_position.get(key)
                if _pos:
                    obj["x_frac"] = _pos.get("x_frac")
                    obj["y_frac"] = _pos.get("y_frac")
                    obj["knn_confidence"] = _pos.get("confidence")
                    if _pos.get("map_id"):
                        obj["knn_map_id"] = _pos["map_id"]
                    if _pos.get("x_m") is not None:
                        obj["x_m"] = _pos["x_m"]
                        obj["y_m"] = _pos["y_m"]
                # Store Kalman-smoothed per-source RSSI for scanner distance sensors
                obj["_source_rssi"] = dict(self._ema_rssi.get(smooth_addr, {}))
                # Propagate TX power if seen in advertisements
                if smooth_addr in addr_tx_power:
                    obj.setdefault("tx_power", addr_tx_power[smooth_addr])
                elif raw_addr in addr_tx_power:
                    obj.setdefault("tx_power", addr_tx_power[raw_addr])
                self._known_objs[key] = dict(obj)  # refresh with smoothed data
            elif obj.get("kind") == "ibeacon":
                obj = dict(obj)
                # iBeacons may advertise from multiple MAC addresses (rotation).
                # Merge RSSI across all known addresses, keeping the strongest
                # per scanner, then feed the merged dict into _smooth_room under
                # the UUID-based key (not a MAC address).
                merged_src: dict[str, float] = {}
                for a in (obj.get("all_addresses") or []):
                    for src, rssi in addr_src_rssi.get(str(a).upper(), {}).items():
                        if src not in merged_src or rssi > merged_src[src]:
                            merged_src[src] = rssi
                # Pass merged RSSI under the UUID key as a synthetic single-addr dict
                synthetic = {key: merged_src} if merged_src else {}
                smoothed_room = self._smooth_room(
                    key, key, synthetic, source_to_area,
                    _dyn_vote_window, _dyn_vote_threshold, source_to_floor,
                    _fabric_rooms)
                if smoothed_room:
                    obj["room"] = smoothed_room
                obj["_smoothed"] = True
                obj["room_confidence"] = self._room_confidence.get(key, 0.0)
                obj["rssi_margin_confidence"] = self._rssi_margin_confidence.get(key, 0.0)
                # Propagate sub-room position — prefer spatial over k-NN
                _pos_ib = self._spatial_position.get(key) or self._knn_position.get(key)
                if _pos_ib:
                    obj["x_frac"] = _pos_ib.get("x_frac")
                    obj["y_frac"] = _pos_ib.get("y_frac")
                    obj["knn_confidence"] = _pos_ib.get("confidence")
                    if _pos_ib.get("map_id"):
                        obj["knn_map_id"] = _pos_ib["map_id"]
                    if _pos_ib.get("x_m") is not None:
                        obj["x_m"] = _pos_ib["x_m"]
                        obj["y_m"] = _pos_ib["y_m"]
                # Store Kalman-smoothed per-source RSSI for scanner distance sensors
                obj["_source_rssi"] = dict(self._ema_rssi.get(key, {}))
                self._known_objs[key] = dict(obj)  # refresh with smoothed data

            # ── Pinned beacon room override ──────────────────────────────────
            if key in _pinned:
                _pin = _pinned[key]
                if _pin["room"]:
                    obj = dict(obj) if not isinstance(obj, dict) else obj
                    obj["room"] = _pin["room"]
                    self._confirmed_room[key] = _pin["room"]
                obj["_pinned"] = True

            # ── No-signal room suppression ────────────────────────────────────
            # After smoothing, if the object has no live signal, force room and
            # room_confidence to empty/zero so the UI shows "away" (not a
            # confidently-present ghost).  Pinned beacons are exempt — their room
            # comes from a known physical position, not from RSSI.
            if _obj_no_signal and key not in _pinned:
                obj = dict(obj) if not isinstance(obj, dict) else obj
                obj["room"] = None
                obj["room_confidence"] = 0.0
                obj["_no_signal"] = True

            result[key] = obj

        # ── Auto-calibration from pinned beacons ─────────────────────────────
        if _pinned:
            await self._inject_beacon_calibration(now, _pinned, result)

        # ── Grace period for missing objects ──────────────────────────────────
        # Devices that vanish from BLE get a 120s grace period (12 polls) to
        # cover normal BLE advertisement gaps.  After grace expires, the device
        # is evicted immediately — no lingering stale objects on the map.
        _evict_keys: list[str] = []
        for key, last_obj in list(self._known_objs.items()):
            if key in result:
                continue
            miss = self._away_miss.get(key, 0) + 1
            self._away_miss[key] = miss
            if miss < _AWAY_GRACE_POLLS:
                # Grace period — treat as still present
                grace = dict(last_obj)
                grace["age_s"] = 0.0
                result[key] = grace
                continue
            # Grace expired — evict
            _evict_keys.append(key)
        for key in _evict_keys:
            self._evict_object(key)

        # ── PadSpan automations: arrive/depart triggers ──────────────────────
        _cur_present = set(result.keys())
        _arrived = _cur_present - self._prev_present
        _departed = set(_evict_keys)  # keys that just got evicted = departed
        self._prev_present = _cur_present

        if _arrived or _departed:
            try:
                await self._run_automations(_arrived, _departed, result)
            except Exception as _auto_err:
                _LOGGER.warning("Automations error (non-fatal): %s", _auto_err)

        # ── Adjacency co-visibility learning (Phase 1) ────────────────────────
        # In auto mode, when no map-derived adjacency exists, learn room
        # adjacency from scanner co-visibility patterns.
        if _model and _model.sync_mode() == "auto" and not self._room_centroids:
            _CO_VIS_RSSI_THRESHOLD = -80.0
            for _addr, _src_rssi in addr_src_rssi.items():
                # Collect rooms that heard this device strongly
                _heard_rooms: set[str] = set()
                for _src, _rssi in _src_rssi.items():
                    if _rssi > _CO_VIS_RSSI_THRESHOLD:
                        _rm = source_to_area.get(_src)
                        if _rm:
                            _heard_rooms.add(_rm)
                # Every pair of rooms that heard the same device = co-visible
                _rl = sorted(_heard_rooms)
                for _i in range(len(_rl)):
                    for _j in range(_i + 1, len(_rl)):
                        _pair = frozenset({_rl[_i], _rl[_j]})
                        self._co_visible[_pair] = self._co_visible.get(_pair, 0) + 1

            self._adj_learn_polls += 1
            if self._adj_learn_polls >= 50:
                self._adj_learn_polls = 0
                # Compute adjacency from co-visibility counts above median
                if self._co_visible:
                    _counts = sorted(self._co_visible.values())
                    _median = _counts[len(_counts) // 2] if _counts else 0
                    _learned_adj: dict[str, list[str]] = {}
                    for _pair, _cnt in self._co_visible.items():
                        if _cnt >= max(_median, 2):  # at least 2 observations
                            _rooms = list(_pair)
                            _learned_adj.setdefault(_rooms[0], []).append(_rooms[1])
                            _learned_adj.setdefault(_rooms[1], []).append(_rooms[0])
                    # Write to ModelStore (only if we learned something)
                    if _learned_adj:
                        for _rm_name, _neighbors in _learned_adj.items():
                            try:
                                await _model.async_set_adjacency(_rm_name, sorted(set(_neighbors)))
                            except Exception:
                                pass
                    self._co_visible.clear()

        # ── Fire follow-alerts for room changes ────────────────────────────────
        if self._pending_room_changes:
            await self._process_room_alerts(now, result)
            await self._record_movement(result)
            # Emit HA tag events for room changes (Feature 1)
            try:
                from .const import DATA_TAG_INTEGRATION
                tag_int = self.hass.data.get(DOMAIN, {}).get(DATA_TAG_INTEGRATION)
                if tag_int:
                    await tag_int.async_emit_room_changes(
                        self._pending_room_changes, result
                    )
            except Exception:
                pass
            self._pending_room_changes.clear()

        # ── Proactive state cleanup ─────────────────────────────────────────────
        # Every 100 polls (~16 min at 10s interval), sweep all per-object state
        # dicts and evict keys that haven't been seen recently. This prevents
        # unbounded memory growth from transient BLE devices.
        if not hasattr(self, "_cleanup_counter"):
            self._cleanup_counter = 0
        self._cleanup_counter += 1
        if self._cleanup_counter >= 100:
            self._cleanup_counter = 0
            _stale_keys = []
            _cutoff = time.monotonic() - 1800.0  # 30 min
            for _k, _ts in list(self._last_seen.items()):
                if _ts < _cutoff and _k not in result:
                    _stale_keys.append(_k)
            for _k in _stale_keys:
                self._evict_object(_k)
            if _stale_keys:
                _LOGGER.debug("Proactive cleanup: evicted %d stale objects", len(_stale_keys))

        # ── Scanner health summary (Phase 3) ──────────────────────────────────
        # Expose per-scanner reliability weights for the UI to display.
        # Stored under a special key that won't collide with object keys.
        _sh: dict[str, Any] = {}
        for _src, _rel in self._scanner_reliability.items():
            _q = self._scanner_agree.get(_src)
            _polls = len(_q) if _q else 0
            _agree_pct = round(sum(_q) / _polls * 100, 0) if _polls else 100
            _sh[_src] = {
                "reliability": _rel,
                "agree_pct": _agree_pct,
                "polls": _polls,
                "room": source_to_area.get(_src, ""),
            }
        result["__scanner_health__"] = _sh

        # ── Experimental MQTT publishing ─────────────────────────────────────
        await self._async_mqtt_publish(result)

        return result

    # ── MQTT publishing (experimental) ───────────────────────────────────────

    async def _async_mqtt_publish(self, result: dict[str, Any]) -> None:
        """Publish device state to MQTT topics if enabled in settings.

        Publishes to padspan/devices/{slug}/state (JSON), /area, and /distance
        with retain=True so MQTT consumers get the last known state on connect.
        Only devices with a user_label are published (unlabeled devices are
        typically not interesting for external automation).
        Errors are silently logged — MQTT is optional and must never break the
        presence pipeline.
        """
        try:
            st = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            if not st or not (st.data or {}).get("mqtt_publish_enabled", False):
                return
            from homeassistant.components.mqtt import async_publish  # noqa: PLC0415
            import json as _json  # noqa: PLC0415
            for key, obj in result.items():
                label = obj.get("user_label")
                if not label:
                    continue
                slug = label.lower().replace(" ", "_")
                topic_base = f"padspan/devices/{slug}"
                # State JSON
                payload = {
                    "room": obj.get("room"),
                    "rssi": obj.get("rssi"),
                    "age_s": obj.get("age_s"),
                    "home": not (isinstance(obj.get("age_s"), (int, float)) and obj["age_s"] > 300),
                    "room_confidence": obj.get("room_confidence"),
                }
                await async_publish(self.hass, f"{topic_base}/state", _json.dumps(payload), retain=True)
                await async_publish(self.hass, f"{topic_base}/area", obj.get("room") or "unknown", retain=True)
                dist = obj.get("distance")
                if dist is not None:
                    await async_publish(self.hass, f"{topic_base}/distance", str(dist), retain=True)
        except ImportError:
            _LOGGER.debug("MQTT component not available — skipping MQTT publish")
        except Exception:
            _LOGGER.debug("MQTT publish error", exc_info=True)

    # ── smoothing helpers ─────────────────────────────────────────────────────

    def _smooth_room(
        self,
        key: str,
        addr: str,
        addr_src_rssi: dict[str, dict[str, float]],
        source_to_area: dict[str, str],
        vote_window: int = _VOTE_WINDOW,
        vote_threshold: int = _VOTE_THRESHOLD,
        source_to_floor: dict[str, str] | None = None,
        fabric_rooms: set[str] | None = None,
    ) -> str | None:
        """Run one poll cycle of the full smoothing pipeline for a single BLE device.

        Pipeline stages executed in order:
          1. Kalman filter — smooth raw RSSI per (device, scanner) pair
          2. Gaussian room scoring — convert smoothed RSSI to distance-weighted
             room scores, with hysteresis to prevent boundary flickering
          3. Floor stickiness — require extra margin for cross-floor transitions
          4. Adaptive blend — mix in learned fingerprint similarity (if enabled)
          5. k-NN override — use calibration fingerprints when confident enough
          6. Majority vote — temporal window for final room confirmation

        Args:
            key: Object key (used for vote state and confidence tracking)
            addr: Kalman state key (canonical address or UUID for iBeacons)
            addr_src_rssi: Full {addr: {source: rssi}} map for this poll cycle
            source_to_area: {scanner_source: HA_area_name}
            vote_window / vote_threshold: Dynamic sizing from room_change_delay_s
            source_to_floor: {scanner_source: floor_id} for cross-floor logic
            fabric_rooms: Room names from fabric geometry (tie-breaking)
            (Map-centric parameters removed — fabric is the sole authority)

        Returns the confirmed (stable) room name, or None if not yet established.
        Side-effects: updates self._room_confidence, _rssi_margin_confidence,
        _knn_position, _confirmed_room, and _room_votes for this key.
        """
        # Phase 1/2: resolve ModelStore for fabric adjacency + metre thresholds
        _model = self.hass.data.get(DOMAIN, {}).get(DATA_MODEL)

        # Build room→floor lookup for outdoor/floor logic
        _room_to_floor: dict[str, str] = {}
        if source_to_floor:
            for _src2, _area2 in source_to_area.items():
                _fl2 = source_to_floor.get(_src2)
                if _fl2 and _area2 not in _room_to_floor:
                    _room_to_floor[_area2] = _fl2

        # Count scanners per floor (for isolated scanner detection)
        _scanners_per_floor: dict[str, int] = {}
        if source_to_floor:
            for _src2 in source_to_area:
                _fl2 = source_to_floor.get(_src2, "")
                if _fl2:
                    _scanners_per_floor[_fl2] = _scanners_per_floor.get(_fl2, 0) + 1

        live_srcs = addr_src_rssi.get(addr, {})

        # ── Stage 1: Kalman-filtered RSSI per source ─────────────────────────
        if addr not in self._ema_rssi:
            self._ema_rssi[addr] = {}
        if addr not in self._kalman_p:
            self._kalman_p[addr] = {}
        ema = self._ema_rssi[addr]
        kp  = self._kalman_p[addr]

        # Read Q/R from settings (allows runtime tuning without restart)
        try:
            _st = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            _d = (_st.data if _st else {}) or {}
            _Q = float(_d.get("kalman_q", _KALMAN_Q))
            _R = float(_d.get("kalman_r", _KALMAN_R))
        except Exception:
            _Q = _KALMAN_Q
            _R = _KALMAN_R

        # Kalman update for sources that reported this poll.
        # K (Kalman gain) adapts automatically: high P (uncertainty) → K≈1
        # (trust new measurement); low P → K≈0 (trust existing estimate).
        for src, rssi in live_srcs.items():
            if src in ema:
                p = kp.get(src, _R)
                K = p / (p + _R)                        # Kalman gain
                ema[src] = ema[src] + K * (rssi - ema[src])  # state update
                kp[src] = (1.0 - K) * p + _Q            # covariance update
            else:
                ema[src] = rssi   # first observation — seed directly
                kp[src] = _R      # initialize at max uncertainty

        # Decay sources that did NOT report.  BLE advertisements are probabilistic
        # — a scanner can miss 1-2 polls even when the device is stationary nearby.
        # To prevent phantom room switches from normal BLE jitter, we only start
        # decaying after a source has been silent for _SILENCE_GRACE consecutive
        # polls.  This means a single missed advertisement doesn't affect scoring.
        #
        # Total silence (no scanners reporting) uses a gentler -95 dBm target;
        # partial silence (some scanners active = possible movement) uses -100 dBm.
        _SILENCE_GRACE = 2  # consecutive missed polls before decay starts
        if addr not in self._silence_miss:
            self._silence_miss[addr] = {}
        _miss = self._silence_miss[addr]

        _all_silent = len(live_srcs) == 0 and len(ema) > 0
        _decay_target = -95.0 if _all_silent else _EMA_SILENCE_DBM

        # Reset miss counter for sources that reported this poll
        for src in live_srcs:
            _miss.pop(src, None)

        for src in list(ema):
            if src not in live_srcs:
                _miss[src] = _miss.get(src, 0) + 1
                if _miss[src] < _SILENCE_GRACE:
                    continue  # grace period — hold RSSI steady, don't decay
                p = kp.get(src, _R)
                K = p / (p + _R)
                ema[src] = ema[src] + K * (_decay_target - ema[src])
                kp[src] = (1.0 - K) * p + _Q
                if ema[src] < _EMA_PRUNE_DBM:
                    del ema[src]
                    kp.pop(src, None)
                    _miss.pop(src, None)
        # Once every source is pruned, drop the empty per-address outer dicts
        # too — they otherwise accumulate one permanent entry per MAC.
        if not ema:
            self._ema_rssi.pop(addr, None)
            self._kalman_p.pop(addr, None)
            self._silence_miss.pop(addr, None)

        # ── Stage 1.5 prep: read path-loss model parameters ────────────────
        # ref_power: RSSI at 1 meter (typically -59 to -65 dBm)
        # path_loss_exp: environment factor (2.0 = free space, 3-4 = indoors)
        # room_sigma_m: Gaussian width — controls how quickly score drops with distance
        try:
            _st_pl = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            _d_pl  = (_st_pl.data if _st_pl else {}) or {}
            _ref   = float(_d_pl.get("ref_power",    DEFAULT_REF_POWER))
            _n_exp = float(_d_pl.get("path_loss_exp", DEFAULT_PATH_LOSS_EXP))
            _sigma = float(_d_pl.get("room_sigma_m",  DEFAULT_ROOM_SIGMA_M))
            _floor_on = bool(_d_pl.get("adaptive_floor_detection", False))
        except Exception:
            _ref   = DEFAULT_REF_POWER
            _n_exp = DEFAULT_PATH_LOSS_EXP
            _sigma = DEFAULT_ROOM_SIGMA_M
            _floor_on = False

        # ── Room scoring ──────────────────────────────────────────────────
        # Two scoring paths:
        #   A) Spatial: when scanner positions + room geometry are available,
        #      estimate the device's (x, y) via inverse-distance-weighted
        #      centroid of scanner positions, then check which room polygon
        #      contains that point.  This is true indoor positioning — it
        #      works even for rooms without a dedicated scanner.
        #   B) Fallback: strongest effective RSSI per room (original method).
        # Both paths feed into the same hysteresis + vote pipeline below.
        candidate: str | None = None
        rssi_margin_confidence: float = 0.0
        room_scores: dict[str, float] = {}
        _spatial_xy: tuple[float, float, str] | None = None  # (x_m, y_m, floor_id)
        _spatial_candidate: str | None = None  # room from geometry check
        _cur_confirmed = self._confirmed_room.get(key)
        if ema:
            # RSSI margin confidence (for entity attributes)
            sorted_vals = sorted(ema.values(), reverse=True)
            if len(sorted_vals) >= 2:
                rssi_margin_confidence = round(
                    min(1.0, max(0.0, (sorted_vals[0] - sorted_vals[1]) / 15.0)), 2
                )
            else:
                rssi_margin_confidence = 1.0

            # ── Path A: spatial positioning via weighted centroid ─────────
            # Requires ≥3 scanners with known positions and live RSSI.
            # Converts RSSI → distance via path-loss model, then computes
            # inverse-distance² weighted centroid of scanner positions.
            if not (self._use_metres and self._scanner_positions and _model):
                self._spatial_debug[key] = f"disabled:metres={self._use_metres},pos={len(self._scanner_positions)},model={bool(_model)}"
            if self._use_metres and self._scanner_positions and _model:
                # Collect scanners with known positions
                _src_list: list[tuple[str, float, float, float, str]] = []
                for _src, _rssi in ema.items():
                    _sp = self._scanner_positions.get(_src)
                    if not _sp:
                        continue
                    _src_list.append((_src, _sp[0], _sp[1], _rssi, _sp[2]))

                if len(_src_list) < 3:
                    self._spatial_debug[key] = f"need_3_pos_scanners:got_{len(_src_list)}_of_{len(ema)}_ema"
                if len(_src_list) >= 3:
                    # Determine which floor the device is on by strongest
                    # RSSI, not most scanners.  A garage scanner at -60 dBm
                    # on floor B beats 10 living room scanners at -75 dBm
                    # on floor A.
                    _floor_best_rssi: dict[str, float] = {}
                    _floor_scanners: dict[str, list[tuple[str, float, float, float]]] = {}
                    for _src, _sx, _sy, _rssi, _sf in _src_list:
                        _floor_scanners.setdefault(_sf, []).append((_src, _sx, _sy, _rssi))
                        if _sf not in _floor_best_rssi or _rssi > _floor_best_rssi[_sf]:
                            _floor_best_rssi[_sf] = _rssi
                    _best_floor = max(_floor_best_rssi, key=lambda f: _floor_best_rssi[f])

                    # Use ALL scanners for centroid, but penalize cross-floor
                    # scanners with a floor attenuation (their RSSI includes
                    # floor/ceiling loss the path-loss model doesn't know about).
                    _CROSS_FLOOR_PENALTY = 10.0  # dBm penalty for different floor
                    _all_scanners: list[tuple[str, float, float, float]] = []
                    for _src, _sx, _sy, _rssi, _sf in _src_list:
                        _adj_rssi = _rssi
                        if _sf != _best_floor:
                            _adj_rssi -= _CROSS_FLOOR_PENALTY
                        _all_scanners.append((_src, _sx, _sy, _adj_rssi))

                    if len(_all_scanners) >= 2:
                        # ── Two-pass IDW centroid with RF barrier correction ──
                        def _idw_centroid(scanners, ref_pt=None):
                            _wx = 0.0; _wy = 0.0; _wt = 0.0
                            for _, _sx, _sy, _rssi in scanners:
                                _eff = _rssi
                                if ref_pt and self._rf_barriers:
                                    _eff -= _barrier_attenuation(
                                        _sx, _sy, _best_floor,
                                        ref_pt[0], ref_pt[1], _best_floor,
                                        self._rf_barriers,
                                    )
                                _d = 10.0 ** ((_ref - _eff) / (10.0 * _n_exp))
                                _d = max(0.3, min(_d, 50.0))
                                _w = 1.0 / (_d * _d + 0.01)
                                _wx += _sx * _w
                                _wy += _sy * _w
                                _wt += _w
                            return (_wx / _wt, _wy / _wt) if _wt > 0 else None

                        _p1 = _idw_centroid(_all_scanners)
                        if _p1:
                            _p2 = _idw_centroid(_all_scanners, ref_pt=_p1) if self._rf_barriers else _p1
                            _est_x, _est_y = _p2 or _p1
                            _spatial_xy = (_est_x, _est_y, _best_floor)
                            self._spatial_debug[key] = f"computed:({_est_x:.1f},{_est_y:.1f})@{_best_floor}"

                            _geo_room = _model.beacon_room_from_geometry(
                                _est_x, _est_y, _best_floor
                            )
                            if _geo_room:
                                _spatial_candidate = _geo_room
                                self._spatial_debug[key] += f">{_geo_room}"
                            else:
                                # Position outside all room polygons — do NOT
                                # guess via nearest centroid.  Let RSSI scoring
                                # decide; it uses ALL scanners (not just those
                                # with positions) and has hysteresis/penalties.
                                self._spatial_debug[key] += ">NO_GEOMETRY_HIT"
                        else:
                            self._spatial_debug[key] = "idw_returned_none"

            # ── Path B: RSSI-based room scoring (always computed) ────────
            # This provides the fallback and also feeds the debug log.
            for _src, _rssi in ema.items():
                _room = source_to_area.get(_src)
                if not _room:
                    continue
                _eff_rssi = _rssi
                # Cross-floor attenuation
                if _floor_on and source_to_floor:
                    _src_fl = source_to_floor.get(_src, "")
                    _room_fl = _room_to_floor.get(_room, "")
                    if _src_fl and _room_fl and _src_fl != _room_fl:
                        _applied_floor_atten = False
                        try:
                            _ad_s = self.hass.data.get(DOMAIN, {}).get(DATA_ADAPTIVE)
                            if _ad_s:
                                _learned_delta = _ad_s.learned_floor_attenuation(_room_fl, _src_fl)
                                if _learned_delta is not None:
                                    _eff_rssi += _learned_delta
                                    _applied_floor_atten = True
                        except Exception as _fl_err:
                            _LOGGER.debug("Floor attenuation error: %s", _fl_err)
                        if not _applied_floor_atten:
                            _eff_rssi -= 10.0  # default cross-floor penalty
                # Scanner reliability penalty (convert to dBm: low reliability = weaker)
                # Skip when suspended — reliability scores may be poisoned
                _rel = 1.0 if self.suspended else self._scanner_reliability.get(_src, 1.0)
                if _rel < 0.8:
                    _eff_rssi -= (1.0 - _rel) * 10.0  # up to -5 dBm for worst scanners
                # Outdoor penalty: -15 dBm for indoor→outdoor transitions only.
                # Skip when device has no confirmed room yet (first placement)
                # so outdoor devices aren't forced indoors on initial detection.
                _cur_confirmed = self._confirmed_room.get(key)
                _cur_floor_id = _room_to_floor.get(_cur_confirmed, "") if _cur_confirmed else ""
                if _cur_confirmed and _cur_floor_id != OUTSIDE_FLOOR_ID and _room_to_floor.get(_room) == OUTSIDE_FLOOR_ID:
                    _eff_rssi -= 15.0
                # Keep best per room
                if _room not in room_scores or _eff_rssi > room_scores[_room]:
                    room_scores[_room] = _eff_rssi

            # ── Merge spatial + RSSI scoring ─────────────────────────────
            # Spatial positioning (Path A) is preferred when available —
            # it uses actual geometry instead of just nearest-scanner.
            # Fall back to RSSI scoring (Path B) when spatial can't resolve.
            _cur_confirmed = self._confirmed_room.get(key)
            if _spatial_candidate:
                # Spatial centroid resolved a position inside a room polygon.
                # This is the primary positioning path — geometry-based.
                # Goes through the vote window like everything else.
                candidate = _spatial_candidate
            elif room_scores:
                # RSSI-only fallback: strongest signal per room with hysteresis
                _best_room = max(room_scores, key=lambda r: room_scores[r])
                if _cur_confirmed and _cur_confirmed in room_scores and _best_room != _cur_confirmed:
                    _hyst = 3.0  # base dBm hysteresis
                    _best_fl = _room_to_floor.get(_best_room, "")
                    _cur_fl = _room_to_floor.get(_cur_confirmed, "")
                    if _best_fl and _cur_fl and _best_fl != _cur_fl:
                        if OUTSIDE_FLOOR_ID in {_best_fl, _cur_fl}:
                            _hyst = 8.0  # indoor↔outdoor
                        else:
                            _hyst = 5.0  # cross-floor
                    else:
                        # Same floor — increase hysteresis for distant rooms
                        _c_cur = self._room_centroids.get(_cur_confirmed)
                        _c_best = self._room_centroids.get(_best_room)
                        if _c_cur and _c_best and _c_cur[2] == _c_best[2]:
                            _dx = _c_cur[0] - _c_best[0]
                            _dy = _c_cur[1] - _c_best[1]
                            _d = math.sqrt(_dx * _dx + _dy * _dy)
                            if not self._use_metres:
                                _d *= 20.0
                            if _d > 6.0:
                                _hyst = 5.0
                    _best_rssi = room_scores.get(_best_room)
                    _cur_rssi = room_scores.get(_cur_confirmed)
                    if _best_rssi is not None and _cur_rssi is not None:
                        if _best_rssi - _cur_rssi < _hyst:
                            candidate = _cur_confirmed
                        else:
                            candidate = _best_room
                    else:
                        candidate = _cur_confirmed if _cur_confirmed else _best_room
                else:
                    candidate = _best_room

        # ── Comprehensive diagnostic for labelled devices ─────────────────────
        _obj_label = (self._known_objs.get(key) or {}).get("user_label")
        if _obj_label:
            # Scanner data: which scanners see this device, their RSSI, position, floor, room
            _scanner_detail = []
            for _src, _rssi in sorted(ema.items(), key=lambda x: -x[1]) if ema else []:
                _sp = self._scanner_positions.get(_src)
                _rm = source_to_area.get(_src, "?")
                _fl = source_to_floor.get(_src, "?") if source_to_floor else "?"
                _pos_str = f"({_sp[0]:.1f},{_sp[1]:.1f})" if _sp else "NO_POS"
                _scanner_detail.append(f"{_src[:18]}={_rssi:.0f}dBm pos={_pos_str} fl={_fl} rm={_rm}")

            # Spatial centroid details
            _spatial_detail = "NONE"
            if _spatial_xy:
                _spatial_detail = f"({_spatial_xy[0]:.1f},{_spatial_xy[1]:.1f}) floor={_spatial_xy[2]} room={_spatial_candidate or 'OUTSIDE_ALL_ROOMS'}"

            # Room geometry check
            _geo_rooms = []
            if _model and _spatial_xy:
                for _rn, _geo in (_model.data.get("room_geometry_m") or {}).items():
                    if isinstance(_geo, dict) and _geo.get("floor_id") == _spatial_xy[2]:
                        _geo_rooms.append(_rn)

            _LOGGER.debug(
                "DIAG [%s] label=%s | scanners(%d): %s",
                key[:30], _obj_label, len(_scanner_detail),
                " | ".join(_scanner_detail[:8]),
            )
            _LOGGER.debug(
                "DIAG [%s] spatial=%s | rooms_on_floor=%s | barriers=%d | "
                "use_metres=%s | scanner_positions=%d | candidate=%s | confirmed=%s",
                key[:30], _spatial_detail,
                ",".join(_geo_rooms) if _geo_rooms else "NONE",
                len(self._rf_barriers),
                self._use_metres, len(self._scanner_positions),
                candidate, _cur_confirmed,
            )
            if room_scores:
                _top5 = sorted(room_scores.items(), key=lambda x: -x[1])[:5]
                _LOGGER.debug(
                    "DIAG [%s] rssi_scores: %s",
                    key[:30],
                    ", ".join(f"{r}={s:.0f}dBm" for r, s in _top5),
                )

        # ── Adaptive tie-break ────────────────────────────────────────────────
        # Adaptive learning is consulted ONLY as a tie-breaker when the
        # Gaussian scorer can't decide (candidate == current because margin
        # wasn't met).  This prevents the learned model from overriding
        # physics — it can only help when physics is ambiguous.
        try:
            _st_ad = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            _d_ad = (_st_ad.data if _st_ad else {}) or {}
            _adaptive_on = bool(_d_ad.get("adaptive_learning_enabled", False))
        except Exception:
            _adaptive_on = False
        if self.suspended:
            _adaptive_on = False

        if _adaptive_on and ema and room_scores and candidate == _cur_confirmed:
            try:
                _ad_store = self.hass.data.get(DOMAIN, {}).get(DATA_ADAPTIVE)
                if _ad_store and _ad_store.maturity() > 0.20:
                    _ad_scores = _ad_store.score_rooms(dict(ema), source_to_area)
                    if _ad_scores:
                        _ad_best = max(_ad_scores, key=lambda r: _ad_scores[r])
                        # Only override if adaptive strongly favors a different room
                        # AND the Gaussian scorer had that room as a close second
                        # Adaptive tie-break: room_scores are now dBm, so check
                        # that the adaptive candidate is within 3 dBm of current
                        _ad_rssi_gap = room_scores.get(_ad_best, -999) - room_scores.get(candidate, -999)
                        if (_ad_best != candidate
                                and _ad_best in room_scores
                                and _ad_scores.get(_ad_best, 0) > 0.7
                                and _ad_rssi_gap > -3.0):
                            candidate = _ad_best
            except Exception as _ad_err:
                _LOGGER.warning("Adaptive tie-break error for %s: %s", key[:30], _ad_err, exc_info=True)

        # ── Fingerprint positioning (k-NN or Random Forest) ─────────────────
        # When the user has collected calibration data (>= _KNN_MIN_POINTS),
        # the system can use fingerprint matching instead of (or on top of)
        # the Gaussian model.  k-NN compares the current RSSI vector against
        # calibration points and returns the nearest match with a confidence
        # score.  If confidence >= _KNN_LIVE_THRESHOLD (15%), the fingerprint
        # result overrides the Gaussian candidate.
        #
        # This also provides sub-room positioning (x_frac, y_frac) for the
        # map dot display.  The position is EMA-smoothed to prevent jumping.
        #
        # Room boundary check: the k-NN (x, y) is tested against the correct
        # map's room_bounds (not necessarily the master) since coordinates are
        # in the calibration map's coordinate space.
        try:
            _calib = self.hass.data.get(DOMAIN, {}).get(DATA_CALIBRATION)
            if _calib and not self.suspended and len(_calib.data.get("points", [])) >= _KNN_MIN_POINTS:
                # Choose algorithm based on setting
                _st2 = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
                _algo = ((_st2.data if _st2 else {}).get("positioning_algorithm") or "knn")
                if _algo == "rf" and _calib.rf_trained:
                    _knn = _calib.rf_locate(dict(ema))
                else:
                    _knn = _calib.knn_locate(dict(ema))
                # Periodic debug log (first object each cycle)
                if not hasattr(self, "_knn_log_count"):
                    self._knn_log_count = 0
                self._knn_log_count += 1
                if self._knn_log_count <= 10 or self._knn_log_count % 50 == 0:
                    _cal_srcs = set()
                    for _cp in _calib.data.get("points", []):
                        for _cr in (_cp.get("scanner_readings") or []):
                            if _cr.get("source"):
                                _cal_srcs.add(_cr["source"])
                    _overlap = set(ema.keys()) & _cal_srcs
                    _LOGGER.debug(
                        "k-NN [%s] addr=%s: ema=%d, cal_src=%d, overlap=%d, "
                        "result=%s, conf=%s, room=%s, positions_stored=%d",
                        key[:30], addr[:20], len(ema), len(_cal_srcs),
                        len(_overlap),
                        "yes" if _knn else "None",
                        _knn.get("confidence") if _knn else "N/A",
                        _knn.get("nearest_room", "") if _knn else "N/A",
                        len(self._knn_position),
                    )
                _knn_conf = _knn.get("confidence", 0.0) if _knn else 0.0
                if _knn and _knn_conf >= _KNN_LIVE_THRESHOLD:
                    _knn_room = _knn.get("nearest_room") or ""
                    # Room boundary check using fabric geometry (metres)
                    if _knn.get("x_m") is not None and _model:
                        _knn_fl = _knn.get("floor_id", "")
                        _geo_room = _model.beacon_room_from_geometry(
                            float(_knn["x_m"]), float(_knn["y_m"]), _knn_fl
                        )
                        if _geo_room:
                            _knn_room = _geo_room
                    # EMA smooth in metre space (floor-based)
                    _has_metres = _knn.get("x_m") is not None
                    if _has_metres:
                        _raw_x = float(_knn["x_m"])
                        _raw_y = float(_knn["y_m"])
                    else:
                        _raw_x = float(_knn.get("x_frac", 0.0))
                        _raw_y = float(_knn.get("y_frac", 0.0))
                    _prev = self._smooth_xy.get(key)
                    _prev_fl = (self._knn_position.get(key) or {}).get("floor_id", "")
                    _new_fl = _knn.get("floor_id", "")
                    _conf = float(_knn.get("confidence", 0.0))
                    _base_alpha = 0.15 + 0.35 * min(_conf, 1.0)
                    if _prev is not None and _prev_fl == _new_fl:
                        # Velocity-aware alpha: if the raw position is very close
                        # to the smoothed position (< 0.8m), the device is likely
                        # stationary and the difference is k-NN jitter.  Use a
                        # much lower alpha (0.03) to prevent noise accumulation.
                        _dx = _raw_x - _prev[0]
                        _dy = _raw_y - _prev[1]
                        _raw_dist = (_dx * _dx + _dy * _dy) ** 0.5
                        if _raw_dist < 0.8:
                            _alpha = 0.03  # near-stationary: heavy damping
                        elif _raw_dist < 1.5:
                            _alpha = _base_alpha * 0.5  # slow movement: moderate damping
                        else:
                            _alpha = _base_alpha  # real movement: normal tracking
                        _sx = _prev[0] + _alpha * (_raw_x - _prev[0])
                        _sy = _prev[1] + _alpha * (_raw_y - _prev[1])
                    else:
                        _sx, _sy = _raw_x, _raw_y  # new floor or first time
                    self._smooth_xy[key] = (_sx, _sy)
                    _knn_smoothed = dict(_knn)
                    if _has_metres:
                        _knn_smoothed["x_m"] = round(_sx, 3)
                        _knn_smoothed["y_m"] = round(_sy, 3)
                        # Derive fracs for UI rendering
                        if _model:
                            for _mid, _t in (_model.data.get("map_transforms") or {}).items():
                                if _t.get("floor_id") == _new_fl:
                                    _fracs = _model.metres_to_map_frac(_sx, _sy, _mid)
                                    if _fracs and 0.0 <= _fracs[0] <= 1.0 and 0.0 <= _fracs[1] <= 1.0:
                                        _knn_smoothed["x_frac"] = round(_fracs[0], 4)
                                        _knn_smoothed["y_frac"] = round(_fracs[1], 4)
                                        _knn_smoothed["map_id"] = _mid
                                        break
                    else:
                        _knn_smoothed["x_frac"] = round(_sx, 4)
                        _knn_smoothed["y_frac"] = round(_sy, 4)
                    self._knn_position[key] = _knn_smoothed
                    # k-NN room override: only when spatial didn't resolve.
                    # Spatial (IDW centroid + room geometry) is the primary
                    # positioning method.  k-NN uses historical calibration
                    # data which may be stale — it should not fight spatial.
                    # k-NN still provides sub-room (x,y) position above.
                    if _knn_room and _knn_conf >= 0.30 and not _spatial_candidate:
                        candidate = _knn_room
                else:
                    self._knn_position.pop(key, None)
                    self._smooth_xy.pop(key, None)
            else:
                self._knn_position.pop(key, None)
                self._smooth_xy.pop(key, None)
        except Exception as _knn_err:
            _LOGGER.warning("k-NN error for %s: %s", key[:30], _knn_err, exc_info=True)
            self._knn_position.pop(key, None)
            self._smooth_xy.pop(key, None)

        # ── Spatial position: independent from k-NN ─────────────────────
        # Spatial uses real-time RSSI + known scanner geometry.  It writes
        # to its own dict so k-NN failure/success never destroys spatial
        # state and vice versa.  The propagation code prefers spatial over
        # k-NN for dot rendering (spatial is real-time, k-NN can be stale).
        if _spatial_xy:
            _sx_est, _sy_est, _sf_est = _spatial_xy
            # EMA-smooth using spatial's own smooth state
            _prev_sp = self._spatial_smooth_xy.get(key)
            if _prev_sp:
                _sp_alpha = 0.15  # heavier smoothing for RSSI-derived position
                _sx_est = _prev_sp[0] + _sp_alpha * (_sx_est - _prev_sp[0])
                _sy_est = _prev_sp[1] + _sp_alpha * (_sy_est - _prev_sp[1])
            self._spatial_smooth_xy[key] = (_sx_est, _sy_est)
            _sp_entry: dict[str, Any] = {
                "x_m": round(_sx_est, 3),
                "y_m": round(_sy_est, 3),
                "floor_id": _sf_est,
                "confidence": rssi_margin_confidence,
                "room": _spatial_candidate or "",
                "source": "spatial",
            }
            # Convert metres to map fracs for rendering
            if _model:
                for _mid, _t in (_model.data.get("map_transforms") or {}).items():
                    if _t.get("floor_id") == _sf_est:
                        _fracs = _model.metres_to_map_frac(_sx_est, _sy_est, _mid)
                        if _fracs and 0.0 <= _fracs[0] <= 1.0 and 0.0 <= _fracs[1] <= 1.0:
                            _sp_entry["x_frac"] = round(_fracs[0], 4)
                            _sp_entry["y_frac"] = round(_fracs[1], 4)
                            _sp_entry["map_id"] = _mid
                            break
            self._spatial_position[key] = _sp_entry
        else:
            # No spatial data — clear stale spatial position
            self._spatial_position.pop(key, None)
            self._spatial_smooth_xy.pop(key, None)

        # ── Store candidate info for diagnostics ─────────────────────────────
        _cand_source = "none"
        if candidate == _spatial_candidate and _spatial_candidate:
            _cand_source = "spatial"
        elif candidate and self._knn_position.get(key) and candidate == (self._knn_position[key].get("room") or self._knn_position[key].get("nearest_room")):
            _cand_source = "knn"
        elif candidate:
            _cand_source = "rssi"
        _rssi_best = max(room_scores, key=lambda r: room_scores[r]) if room_scores else None
        self._last_candidate[key] = {
            "candidate": candidate,
            "source": _cand_source,
            "spatial_room": _spatial_candidate,
            "spatial_xy": _spatial_xy,
            "rssi_best": _rssi_best,
            "rssi_top3": sorted(room_scores.items(), key=lambda x: -x[1])[:3] if room_scores else [],
        }

        # ── Stage 2: majority-vote room confirmation ──────────────────────────
        # ALL candidates (spatial, k-NN, or RSSI-based) go through the vote
        # window.  This provides temporal stabilization — a room must win a
        # majority of recent polls before it becomes the confirmed room.
        existing = self._room_votes.get(key)
        if existing is None or existing.maxlen != vote_window:
            prev = list(existing) if existing else []
            self._room_votes[key] = deque(prev[-vote_window:], maxlen=vote_window)
        votes = self._room_votes[key]

        # Skip None candidates (total signal dropout) — preserves the last
        # known room instead of diluting the window with empty votes.
        if candidate is not None:
            votes.append(candidate)

        # Count votes per room and check if any room meets the threshold
        counts: dict[str, int] = {}
        for v in votes:
            if v:
                counts[v] = counts.get(v, 0) + 1

        confirmed = self._confirmed_room.get(key)
        confidence = 0.0
        if counts:
            top_room = max(counts, key=lambda r: counts[r])
            top_count = counts[top_room]
            # Confidence = fraction of window agreeing on the top room (0.0–1.0)
            confidence = round(top_count / len(votes), 2)
            if top_count >= vote_threshold:
                if top_room != confirmed:
                    # ── Velocity gate ────────────────────────────────────
                    # Three checks prevent teleportation:
                    #  1. Rapid-fire: if device changed rooms very recently,
                    #     require UNANIMOUS vote (all votes agree).
                    #  2. Distance: if rooms are far apart (non-adjacent),
                    #     also require unanimous vote.
                    #  3. Indoor↔outdoor: crossing the outdoor boundary
                    #     always requires unanimous vote.
                    # All checks are soft: they raise the bar for evidence,
                    # not block transitions entirely.
                    _vg_block = False
                    if confirmed is not None:
                        _now_mono = time.monotonic()
                        # Check 1: dwell-proportional transition gate
                        # Short dwell (<30s): require unanimous (just arrived, likely noise)
                        # Medium dwell (30-120s): require supermajority
                        # Long dwell (>120s): normal threshold (device is settled)
                        _last_change = self._last_room_change_mono.get(key, 0.0)
                        _elapsed = _now_mono - _last_change if _last_change else 999.0
                        _dwell = _now_mono - self._room_dwell_start.get(key, 0.0) if self._room_dwell_start.get(key) else 999.0
                        _is_rapid = _dwell < 30.0  # short dwell = high bar
                        # Check 2: room distance (non-adjacent)
                        _is_distant = False
                        _c1 = self._room_centroids.get(confirmed)
                        _c2 = self._room_centroids.get(top_room)
                        if _c1 and _c2:
                            # Centroid-based distance check
                            if _c1[2] == _c2[2]:
                                _dx = _c1[0] - _c2[0]
                                _dy = _c1[1] - _c2[1]
                                _cdist = math.sqrt(_dx * _dx + _dy * _dy)
                                _vg_thresh = _VG_ADJACENT_THRESHOLD_M if self._use_metres else _VG_ADJACENT_THRESHOLD
                                _is_distant = _cdist > _vg_thresh
                            else:
                                _is_distant = True  # different maps → always "distant"
                        elif _model:
                            # Fallback: fabric adjacency list (no map needed)
                            _vg_adj = _model.adjacency()
                            if _vg_adj and confirmed in _vg_adj:
                                _is_distant = top_room not in _vg_adj[confirmed]
                            # else: no adjacency data → _is_distant stays False (no gate)
                        # Check 3: indoor↔outdoor transition
                        _is_outdoor_cross = False
                        _conf_fl = _room_to_floor.get(confirmed, "")
                        _top_fl = _room_to_floor.get(top_room, "")
                        if _conf_fl and _top_fl:
                            _conf_outside = _conf_fl == OUTSIDE_FLOOR_ID
                            _top_outside = _top_fl == OUTSIDE_FLOOR_ID
                            if _conf_outside != _top_outside:
                                _is_outdoor_cross = True

                        # Cross-floor transitions: require higher evidence when dwell is short
                        _is_cross_floor = False
                        if _conf_fl and _top_fl and _conf_fl != _top_fl:
                            _is_cross_floor = True
                        # Determine required vote count based on dwell + context.
                        # When spatial centroid agrees with the new room, relax
                        # requirements — geometry-confirmed transitions shouldn't
                        # need unanimous votes to escape the current room.
                        _spatial_confirms_new = (_spatial_candidate == top_room) if _spatial_candidate else False
                        if _is_outdoor_cross:
                            _required = len(votes) if not _spatial_confirms_new else vote_threshold
                        elif _is_cross_floor and _dwell < 60.0:
                            _required = len(votes) if not _spatial_confirms_new else vote_threshold + 1
                        elif _is_rapid or _is_distant:
                            _required = len(votes) if not _spatial_confirms_new else vote_threshold
                        elif _is_cross_floor and _dwell < 120.0:
                            _required = min(len(votes), vote_threshold + 1)
                        else:
                            _required = vote_threshold  # normal
                        if top_count < _required:
                            _vg_block = True
                            _LOGGER.debug(
                                "Velocity gate blocked %s: %s → %s (dwell=%.0fs, rapid=%s, distant=%s, cross_floor=%s, votes=%d/%d need %d)",
                                key[:30], confirmed, top_room, _dwell,
                                _is_rapid, _is_distant, _is_cross_floor, top_count, len(votes), _required,
                            )
                    if not _vg_block:
                        _LOGGER.debug(
                            "Room confirmed for %s: %s → %s (votes %s, confidence %.0f%%)",
                            key, confirmed, top_room, dict(counts), confidence * 100,
                        )
                        # Track room change for alert processing
                        self._pending_room_changes.append((key, confirmed, top_room))
                        _change_mono = time.monotonic()
                        self._last_room_change_mono[key] = _change_mono
                        self._room_dwell_start[key] = _change_mono
                        # Floor transition learning
                        _old_fl = _room_to_floor.get(confirmed, "")
                        _new_fl = _room_to_floor.get(top_room, "")
                        if _old_fl and _new_fl and _old_fl != _new_fl:
                            _fl_dwell = _change_mono - self._floor_dwell_start.get(key, _change_mono)
                            self._floor_dwell_start[key] = _change_mono
                            self._device_floor[key] = _new_fl
                            # Record to adaptive store for learning
                            try:
                                _ad = self.hass.data.get(DOMAIN, {}).get(DATA_ADAPTIVE)
                                if _ad:
                                    _ad.record_floor_transition(_old_fl, _new_fl, _fl_dwell)
                            except Exception:
                                pass
                        elif _new_fl:
                            self._device_floor[key] = _new_fl
                        confirmed = top_room

        self._confirmed_room[key] = confirmed
        self._room_confidence[key] = confidence
        self._rssi_margin_confidence[key] = rssi_margin_confidence

        # ── Phase 3: per-scanner reliability update ──────────────────────────
        # Only learn reliability when we're VERY confident the confirmed room
        # is correct: high vote confidence AND spatial centroid agrees.
        # This prevents the negative feedback loop where a wrong room assignment
        # poisons scanner reliability scores, making it impossible to recover.
        # Skip when suspended — don't pollute reliability with potentially wrong data.
        _spatial_agrees = (_spatial_candidate == confirmed) if _spatial_candidate else False
        if confirmed and confidence >= 0.9 and _spatial_agrees and ema and not self.suspended:
            for _src in ema:
                _src_room = source_to_area.get(_src)
                if not _src_room:
                    continue
                _agreed = (_src_room == confirmed)
                _q = self._scanner_agree.get(_src)
                if _q is None:
                    _q = deque(maxlen=_RELIABILITY_WINDOW)
                    self._scanner_agree[_src] = _q
                _q.append(_agreed)
                if len(_q) >= _RELIABILITY_MIN_POLLS:
                    _agree_rate = sum(_q) / len(_q)
                    _disagree = 1.0 - _agree_rate
                    _w = 1.0 / (1.0 + _disagree)
                    self._scanner_reliability[_src] = max(_RELIABILITY_FLOOR, round(_w, 3))
                else:
                    self._scanner_reliability[_src] = 1.0

        # ── Adaptive learning: record observation ────────────────────────────
        # Feed confirmed room assignments back into the adaptive store so it
        # can improve over time.  Only record from identified devices (phones
        # with IRK, labelled objects) — random BLE devices at random positions
        # inflate variance and make the fingerprint useless.
        # Also require confidence >= 0.7 (stable) and rate-limit to 1 per
        # device per 5 min to keep data compact.
        _obj_for_adaptive = self._known_objs.get(key, {})
        _is_identified_device = bool(
            _obj_for_adaptive.get("user_label")
            or _obj_for_adaptive.get("identified")
            or _obj_for_adaptive.get("kind") == "private_ble"  # phone with IRK
        )
        if _adaptive_on and confirmed and confidence >= 0.7 and ema and _is_identified_device:
            try:
                _now_mono = time.monotonic()
                _last = self._adaptive_last_obs.get(key, 0.0)
                if _now_mono - _last >= 300.0:
                    self._adaptive_last_obs[key] = _now_mono
                    _ad = self.hass.data.get(DOMAIN, {}).get(DATA_ADAPTIVE)
                    if _ad:
                        # Derive floor of confirmed room
                        _conf_floor = None
                        if source_to_floor:
                            for _src, _area in source_to_area.items():
                                if _area == confirmed and _src in (source_to_floor or {}):
                                    _conf_floor = source_to_floor[_src]
                                    break
                        _ad.observe(confirmed, _conf_floor, dict(ema), source_to_area, source_to_floor or {})
                        # Record transitions
                        for _chg_key, _old, _new in self._pending_room_changes:
                            if _chg_key == key:
                                _ad.record_transition(_old, _new)
                        # Periodic save (every 20 observations, not every poll)
                        self._adaptive_save_counter += 1
                        if self._adaptive_save_counter >= 20:
                            self._adaptive_save_counter = 0
                            self.hass.async_create_task(_ad.async_save_periodic())
            except Exception as _obs_err:
                _LOGGER.warning("Adaptive observe error for %s: %s", key[:30], _obs_err, exc_info=True)

        return confirmed

    # ── Object state cleanup ─────────────────────────────────────────────

    def _evict_object(self, key: str) -> None:
        """Remove all cached state for a single object key.

        Called when an object has been stale longer than _STALE_EVICT_S, or
        explicitly via clear_object_state().  Cleans up Kalman, vote, k-NN,
        confidence, and alert state to prevent unbounded memory growth.
        """
        self._known_objs.pop(key, None)
        self._last_seen.pop(key, None)
        self._away_miss.pop(key, None)
        self._room_votes.pop(key, None)
        self._confirmed_room.pop(key, None)
        self._room_confidence.pop(key, None)
        self._rssi_margin_confidence.pop(key, None)
        self._knn_position.pop(key, None)
        self._smooth_xy.pop(key, None)
        self._spatial_position.pop(key, None)
        self._spatial_smooth_xy.pop(key, None)
        self._beacon_autocal_last.pop(key, None)
        self._adaptive_last_obs.pop(key, None)
        self._last_room_change_mono.pop(key, None)
        self._room_dwell_start.pop(key, None)
        self._floor_dwell_start.pop(key, None)
        self._device_floor.pop(key, None)
        self._alert_last_sent.pop(key, None)
        self._last_candidate.pop(key, None)
        self._ema_rssi.pop(key, None)
        self._kalman_p.pop(key, None)
        self._silence_miss.pop(key, None)
        # Kalman/silence state for plain ble objects is keyed by the bare
        # uppercase MAC, not the "ble:"-prefixed object key — popping only the
        # key above was a silent no-op for them, leaving one entry per MAC
        # ever seen (neighbours' devices included) for the process lifetime.
        if key.startswith("ble:"):
            _addr = key.split(":", 1)[1].upper()
            self._ema_rssi.pop(_addr, None)
            self._kalman_p.pop(_addr, None)
            self._silence_miss.pop(_addr, None)

    def clear_object_state(self, key: str) -> None:
        """Public API: clear all coordinator state for an object.

        Called when a beacon is removed from beacon tune or an object
        is unfollowed — ensures the object won't linger as stale.
        """
        self._evict_object(key)
        # Also try uppercase variant (keys may differ in case)
        ku = key.upper()
        if ku != key:
            self._evict_object(ku)
        _LOGGER.debug("Cleared coordinator state for %s", key)

    # ── PadSpan automations ─────────────────────────────────────────────────

    async def _run_automations(
        self, arrived: set[str], departed: set[str], result: dict[str, Any]
    ) -> None:
        """Fire HA events and execute PadSpan automation rules for arrive/depart."""
        # Build key→label lookup
        _obj_store = self.hass.data.get(DOMAIN, {}).get(DATA_OBJECTS)
        _key_labels: dict[str, str] = {}
        for k, obj in result.items():
            lbl = obj.get("user_label") or ""
            if lbl:
                _key_labels[k] = lbl
        if _obj_store:
            for k, entry in _obj_store.all().items():
                if isinstance(entry, dict) and entry.get("label"):
                    _key_labels[str(k)] = entry["label"]

        # ── Fire HA events for labelled arrive/depart ────────────────────
        # These events can be used as triggers in HA automations.  Only
        # labelled (user-tagged) devices fire: every rotating-MAC rotation in
        # a busy BLE environment registers as a "new" unlabelled arrival, and
        # firing those flooded the event bus until subscribers hit HA's
        # 4096-pending-message limit and were disconnected.  PadSpan's own
        # automation rules below match on the raw arrived/departed sets, so
        # rules keyed to an unlabelled device still run.
        for key in arrived:
            label = _key_labels.get(key, "")
            if not label:
                continue
            room = (result.get(key) or {}).get("room", "")
            self.hass.bus.async_fire("padspan_device_arrived", {
                "device_key": key, "label": label, "room": room,
            })
            _LOGGER.info("Device arrived: %s (%s) in %s", label, key[:30], room)
        for key in departed:
            label = _key_labels.get(key, "")
            if not label:
                continue
            self.hass.bus.async_fire("padspan_device_departed", {
                "device_key": key, "label": label,
            })
            _LOGGER.info("Device departed: %s (%s)", label, key[:30])

        # ── Execute PadSpan automation rules ─────────────────────────────
        try:
            _st = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            rules = (_st.data if _st else {}).get("padspan_automations") or []
        except Exception:
            return
        if not rules:
            return

        for rule in rules:
            if not isinstance(rule, dict) or not rule.get("enabled", True):
                continue
            trigger = rule.get("trigger")  # "arrive" or "depart"
            device_key = rule.get("device_key", "")
            device_label = rule.get("device_label", "")
            action = rule.get("action", "")  # "turn_on" or "turn_off"
            entity_id = rule.get("entity_id", "")
            if not trigger or not entity_id or not action:
                continue

            # Match by key or label
            _matched_keys: set[str] = set()
            if device_key:
                _matched_keys.add(device_key)
            if device_label:
                for k, lbl in _key_labels.items():
                    if lbl.upper() == device_label.upper():
                        _matched_keys.add(k)

            # Check trigger
            _fire = False
            if trigger == "arrive" and _matched_keys & arrived:
                _fire = True
            elif trigger == "depart" and _matched_keys & departed:
                _fire = True

            if _fire:
                parts = entity_id.split(".", 1)
                if len(parts) == 2:
                    svc_domain, _ = parts
                    try:
                        await self.hass.services.async_call(
                            svc_domain, action, {"entity_id": entity_id}
                        )
                        _LOGGER.info(
                            "PadSpan automation: %s %s → %s.%s(%s)",
                            trigger, device_label or device_key,
                            svc_domain, action, entity_id,
                        )
                    except Exception as _svc_err:
                        _LOGGER.warning(
                            "PadSpan automation failed: %s → %s",
                            rule, _svc_err,
                        )

    # ── Beacon auto-calibration ────────────────────────────────────────────

    async def _inject_beacon_calibration(
        self, now: float, pinned: dict[str, dict], result: dict[str, Any]
    ) -> None:
        """Auto-inject calibration points from pinned beacons that have live RSSI.

        Beacons with known map positions act as continuous calibration sources:
        since we know exactly where they are, their RSSI readings become new
        fingerprint data points.  Rate-limited to one injection per beacon per
        10 minutes to avoid flooding the calibration store.
        """
        try:
            _st = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            if _st:
                _auto_cal = _st.data.get("beacon_auto_calibrate", True)
                _adaptive = _st.data.get("adaptive_learning_enabled", False)
                # Auto-calibrate if either beacon_auto_calibrate or adaptive_learning is on
                if not _auto_cal and not _adaptive:
                    return
        except Exception:
            pass

        cal_store = self.hass.data.get(DOMAIN, {}).get(DATA_CALIBRATION)
        if not cal_store:
            return

        _AUTOCAL_INTERVAL = 600.0  # 10 minutes between injections per beacon

        for key, pin in pinned.items():
            obj = result.get(key)
            if not obj or obj.get("_stale"):
                continue
            # Rate limit: at most 1 injection per beacon per 10 minutes
            last_ts = self._beacon_autocal_last.get(key, 0.0)
            if now - last_ts < _AUTOCAL_INTERVAL:
                continue
            # Need smoothed per-source RSSI
            smoothed_rssi: dict[str, float] = obj.get("_source_rssi") or {}
            if not smoothed_rssi:
                continue
            self._beacon_autocal_last[key] = now
            try:
                await cal_store.async_add_point({
                    "map_id": "",
                    "x_frac": 0.5,
                    "y_frac": 0.5,
                    "x_m": pin.get("x_m"),
                    "y_m": pin.get("y_m"),
                    "floor_id": pin.get("floor_id", ""),
                    "room": pin.get("room", ""),
                    "label": f"[auto] {obj.get('user_label') or key}",
                    "device_id": key,
                    "duration_s": 10,
                    "scanner_readings": [
                        {"source": src, "rssi_samples": [rssi]}
                        for src, rssi in smoothed_rssi.items()
                    ],
                })
                await cal_store.async_prune_auto_points(max_per_beacon=50)
            except Exception:
                _LOGGER.debug("Beacon auto-cal injection failed for %s", key)

    async def inject_immediate_calibration(
        self, beacons: list[dict], map_id: str, floor_id: str, room_bounds: dict
    ) -> int:
        """Inject calibration points for beacons with live RSSI.

        Uses fabric beacon positions (metres) when available.
        Falls back to map fracs from beacon dict.
        """
        cal_store = self.hass.data.get(DOMAIN, {}).get(DATA_CALIBRATION)
        if not cal_store:
            return 0
        _model = self.hass.data.get(DOMAIN, {}).get(DATA_MODEL)

        injected = 0
        now = time.monotonic()
        for bk in beacons:
            key = bk.get("key", "")
            if not key:
                continue
            smoothed_rssi = dict(self._ema_rssi.get(key, {}))
            if not smoothed_rssi:
                smoothed_rssi = dict(self._ema_rssi.get(key.upper(), {}))
            if not smoothed_rssi:
                obj = self._known_objs.get(key) or {}
                smoothed_rssi = obj.get("_source_rssi") or {}
            if not smoothed_rssi:
                continue
            self._beacon_autocal_last[key] = now
            _pt: dict[str, Any] = {
                "floor_id": floor_id,
                "label": f"[auto] {(self._known_objs.get(key) or {}).get('user_label') or key}",
                "device_id": key,
                "duration_s": 10,
                "scanner_readings": [
                    {"source": src, "rssi_samples": [rssi]}
                    for src, rssi in smoothed_rssi.items()
                ],
            }
            # Fabric beacon position (metres, primary)
            _fb = (_model.beacon_positions_m().get(key) or {}) if _model else {}
            if _fb and _fb.get("x_m") is not None:
                _pt["x_m"] = _fb["x_m"]
                _pt["y_m"] = _fb["y_m"]
                _pt["room"] = _fb.get("room", "")
                _pt["x_frac"] = 0.5
                _pt["y_frac"] = 0.5
                _pt["map_id"] = ""
            elif bk.get("x") is not None:
                _pt["map_id"] = map_id
                _pt["x_frac"] = float(bk.get("x", 0))
                _pt["y_frac"] = float(bk.get("y", 0))
                _pt["room"] = _fb.get("room", "")
            else:
                continue
            try:
                await cal_store.async_add_point(_pt)
                await cal_store.async_prune_auto_points(max_per_beacon=50)
                injected += 1
            except Exception:
                _LOGGER.debug("Immediate beacon cal injection failed for %s", key)
        return injected

    # ── Follow-alert processing ────────────────────────────────────────────

    async def _process_room_alerts(
        self, now: float, result: dict[str, Any]
    ) -> None:
        """Send notifications for room changes based on Follow tab alert configs.

        Supports both legacy HA notify services (notify.{name}) and the newer
        entity-based notify (notify.send_message with entity_id).  Falls back
        to auto-detecting an available service, preferring email/SMTP ones.
        Rate-limited to one alert per device per 60 seconds.
        """
        from .const import DOMAIN, DATA_ALERTS

        alert_store = self.hass.data.get(DOMAIN, {}).get(DATA_ALERTS)
        if not alert_store:
            return

        for key, old_room, new_room in self._pending_room_changes:
            try:
                cfg = alert_store.get_config(key)
                if not cfg:
                    # UI saves alert config under address (e.g. "AA:BB:CC:DD:EE:FF")
                    # but key is prefixed (e.g. "ble:AA:BB:CC:DD:EE:FF"). Try address.
                    _obj = result.get(key) or self._known_objs.get(key) or {}
                    _addr = _obj.get("address") or ""
                    if _addr:
                        cfg = alert_store.get_config(_addr)
                if not cfg:
                    continue
                email = (cfg.get("email") or "").strip()
                if not email:
                    continue
                if not cfg.get("on_room_change"):
                    continue

                # Check watch_rooms filter (empty list = alert on all rooms)
                watch = cfg.get("watch_rooms") or []
                if watch and new_room not in watch:
                    continue

                # Rate limit: 60s cooldown per device
                last = self._alert_last_sent.get(key, 0.0)
                if now - last < 60:
                    _LOGGER.debug("Alert throttled for %s (%.0fs since last)", key, now - last)
                    continue

                # Get display label
                obj = result.get(key) or self._known_objs.get(key) or {}
                label = obj.get("user_label") or obj.get("name") or key

                # Find a notify service — prefer user-configured, fall back to first available
                # Supports both legacy notify.{name} and new HA 2024+ entity-based notify
                services = self.hass.services.async_services().get("notify", {})
                has_send_message = "send_message" in services
                entity_ids = [s.entity_id for s in self.hass.states.async_all("notify")]
                legacy = [k for k in services if k != "send_message"]

                if not services and not entity_ids:
                    _LOGGER.warning("Alert: no notify services available in HA")
                    continue

                preferred = cfg.get("notify_service") or ""

                message = (
                    f"{label} moved from {old_room or 'unknown'} to {new_room}"
                )
                alert_data: dict[str, Any] = {
                    "title": f"PadSpan: {label} moved",
                    "message": message,
                }
                sent = False
                # Try entity-based send_message first if applicable
                if preferred.startswith("notify.") and has_send_message:
                    try:
                        payload = {**alert_data, "entity_id": preferred}
                        if email:
                            payload["target"] = email
                        await self.hass.services.async_call("notify", "send_message", payload)
                        sent = True
                    except Exception:
                        # Fall through to legacy
                        pass
                if not sent and preferred and preferred in services:
                    try:
                        await self.hass.services.async_call(
                            "notify", preferred, {**alert_data, "target": email} if email else alert_data,
                        )
                        sent = True
                    except Exception:
                        try:
                            await self.hass.services.async_call("notify", preferred, alert_data)
                            sent = True
                        except Exception:
                            pass
                if not sent:
                    # Auto-pick: prefer entity with mail/smtp, then legacy, then first available
                    auto_targets: list[tuple[str, str, dict[str, Any]]] = []
                    for eid in entity_ids:
                        if has_send_message:
                            auto_targets.append(("send_message", eid, {**alert_data, "entity_id": eid}))
                    for svc in legacy:
                        auto_targets.append((svc, svc, alert_data))
                    # Sort: prefer mail/smtp
                    auto_targets.sort(key=lambda t: (0 if "mail" in t[1].lower() or "smtp" in t[1].lower() else 1))
                    for svc_name, _label, payload in auto_targets:
                        try:
                            await self.hass.services.async_call("notify", svc_name, payload)
                            sent = True
                            break
                        except Exception:
                            continue
                if sent:
                    self._alert_last_sent[key] = now
                    _LOGGER.info(
                        "Follow alert sent for %s: %s → %s (to %s via %s)",
                        label, old_room, new_room, email, preferred or "auto",
                    )
                else:
                    _LOGGER.warning("Follow alert: all send attempts failed for %s", label)
            except Exception as err:
                _LOGGER.warning("Follow alert failed for %s: %s", key, err)

    def clear_scanner(self, source: str) -> int:
        """Remove a scanner from all devices' Kalman filter state.

        Called when a scanner is removed or reset.  Without this, stale RSSI
        entries for the removed scanner would decay slowly via the silence
        mechanism, potentially biasing room scores during that window.
        Returns the number of device entries that were cleaned.
        """
        cleared = 0
        for addr in list(self._ema_rssi):
            if source in self._ema_rssi[addr]:
                del self._ema_rssi[addr][source]
                self._kalman_p.get(addr, {}).pop(source, None)
                cleared += 1
                if not self._ema_rssi[addr]:
                    del self._ema_rssi[addr]
                    self._kalman_p.pop(addr, None)
        return cleared

    async def _record_movement(self, result: dict[str, Any]) -> None:
        """Persist room transitions to the movement history store.

        Movement history powers the Follow tab's movement log and the
        Manage → History view.  Each transition is recorded with a timestamp,
        the object's display label, and the old/new room names.
        """
        from .const import DOMAIN, DATA_MOVEMENT, DATA_OBJECTS, DATA_DEVICE_REGISTRY
        try:
            mv_store = self.hass.data.get(DOMAIN, {}).get(DATA_MOVEMENT)
            if not mv_store:
                return
            obj_store = self.hass.data.get(DOMAIN, {}).get(DATA_OBJECTS)
            dev_reg = self.hass.data.get(DOMAIN, {}).get(DATA_DEVICE_REGISTRY)
            for key, old_room, new_room in self._pending_room_changes:
                label = None
                pid = None
                if dev_reg:
                    pid = dev_reg.resolve(key)
                    if pid:
                        label = dev_reg.get_label(pid)
                if not label and obj_store:
                    label = obj_store.get_label(key)
                await mv_store.record(key, old_room, new_room, label=label, padspan_id=pid)
        except Exception as err:
            _LOGGER.debug("Movement recording failed: %s", err)
